# Source and digital checks

The Cypress live files match the October 24 backup by SHA-256. The original DesignModeler STEP headers and local project revisions identify the source. Orion checked each STL for closure, orientation consistency and one connected solid, and reloaded the matching STEP to compare its solid count, dimensions and volume.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| display-template-v3.stl | `eae7679646e42ff5f4c600203be1d8dd3077a3ebb32e21c45d40a8c1299093e6` | `eae7679646e42ff5f4c600203be1d8dd3077a3ebb32e21c45d40a8c1299093e6` |
| display-template-v3.step | `b790e4a5f47fa860f226bc7bb1a39e4f24d2c0e3944b562411672a7ab202a14e` | `817a73b53d51b4e831212746c7e50db672d984be536bc73f7f801f23b448ad65` |

Workstation paths and account names were removed from the affected STEP headers. The geometry section was preserved byte for byte.

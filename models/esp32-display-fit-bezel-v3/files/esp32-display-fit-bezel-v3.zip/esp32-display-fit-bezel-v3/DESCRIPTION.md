A small display-frame prototype from the Cypress ESP32 Display project. The rectangular frame has four mounting holes and relief along its short edges. The outside size is approximately 59.6 × 95.4 mm with a 6 mm depth.

Use the supplied STEP to check the actual screen opening, screw centers, connector access and rear clearance against your module. Place the broad face on the bed where your slicer shows continuous first-layer contact.

This release contains the bezel by itself. Orion verified the STL as a closed solid and reloaded the matching STEP. The exact display SKU and physical fit remain unverified.

Licence CC BY-NC-SA 4.0. Credit Isaiah Dupree when sharing or remixing.

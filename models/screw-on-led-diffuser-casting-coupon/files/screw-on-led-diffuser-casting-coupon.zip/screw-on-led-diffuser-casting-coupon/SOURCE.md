# Source and digital checks

The paired coupon comes from the original Sour Sides graffiti R2 project. Its construction was checked in the Orion native geometry audit.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| screw-pattern-coupon-backing.stl | `ebd6f70976f29f28e81ee846bd1ed12876183f738f958ed256bb033ae8bea3b7` | `ebd6f70976f29f28e81ee846bd1ed12876183f738f958ed256bb033ae8bea3b7` |
| screw-pattern-coupon-backing.step | `f35e82cd5a3b75bf619b178f640ca5d079399888b91af675e7b0c2c247a9afc8` | `f35e82cd5a3b75bf619b178f640ca5d079399888b91af675e7b0c2c247a9afc8` |
| screw-pattern-coupon-silicone-mold.stl | `c6c90134ca5f7be80f296df59254c8bcbe6ef6399f9d7f5f8fd0fce39b344815` | `c6c90134ca5f7be80f296df59254c8bcbe6ef6399f9d7f5f8fd0fce39b344815` |
| screw-pattern-coupon-silicone-mold.step | `74dd0569e8d2e7d05087819956dd82df288d40f8d09e5b5a28ca3550408f6df4` | `74dd0569e8d2e7d05087819956dd82df288d40f8d09e5b5a28ca3550408f6df4` |
| screw-pattern-coupon-silicone.stl | `8cc512b8b8f2a107ad92739acf90e3a3948b6ff25e259010edc54411ec23cbfe` | `8cc512b8b8f2a107ad92739acf90e3a3948b6ff25e259010edc54411ec23cbfe` |
| screw-pattern-coupon-silicone.step | `f2d12be62f8aa238f722a900f761b81b0e67a15016d9462ea8c9edfca3a57754` | `f2d12be62f8aa238f722a900f761b81b0e67a15016d9462ea8c9edfca3a57754` |
| screw-pattern-coupon-washer-1.stl | `e260b08b15b9481a4edfe23fbad61c94cbd41f307220e039330d582bf4ec5297` | `e260b08b15b9481a4edfe23fbad61c94cbd41f307220e039330d582bf4ec5297` |
| screw-pattern-coupon-washer-1.step | `a22c470a2f3e946eb06ecfcba5903a798527970c933afc958a852cf234fa435d` | `a22c470a2f3e946eb06ecfcba5903a798527970c933afc958a852cf234fa435d` |
| screw-pattern-coupon-washer-2.stl | `5c7966a4f4880fd7f3ce26bc18ae9b7828a1d9294c5026a5b893e24a6e23265a` | `5c7966a4f4880fd7f3ce26bc18ae9b7828a1d9294c5026a5b893e24a6e23265a` |
| screw-pattern-coupon-washer-2.step | `7e63e816892e3c32e6645d60bff25fc9857e2c70b51b88a9b5f49aa8b5df2830` | `7e63e816892e3c32e6645d60bff25fc9857e2c70b51b88a9b5f49aa8b5df2830` |

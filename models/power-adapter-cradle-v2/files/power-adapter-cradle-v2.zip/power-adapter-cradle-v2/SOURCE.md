# Source and digital checks

The Cypress live files match the October 24 backup by SHA-256. The original DesignModeler STEP headers and local project revisions identify the source. Orion checked each STL for closure, orientation consistency and one connected solid, and reloaded the matching STEP to compare its solid count, dimensions and volume.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| charger-cradle-v2.stl | `44b72af9ecc124586e9debc9506205f31e515955f72a298b9c6fefd6422a37c4` | `44b72af9ecc124586e9debc9506205f31e515955f72a298b9c6fefd6422a37c4` |
| charger-cradle-v2.step | `036f82e4bd35c31bc93691141e9cbdf002e47fdbab65b8160165d37722e6786f` | `feebc8988bce8f75a3ff3492d93800a92d015553e67c40a06d41f21fc0bb682a` |

Workstation paths and account names were removed from the affected STEP headers. The geometry section was preserved byte for byte.

# Hood-flange V4 measurement worksheet

The photographs establish orientation and an approximate envelope only. Fill every
blank before changing this fit-study into a vehicle-installable part.

| Measurement | Provisional CAD value | Measured value |
| --- | ---: | --- |
| Bolt center distance | 50.53 mm slotted candidate | confirm with both contacts visible: ______ |
| Caliper Photo 1 endpoints | display 50.53 mm; endpoints not visible | ______ to ______ |
| Bolt flange / washer OD | photo display approximately 18.4x mm; not thread diameter | ______ |
| Caliper Photo 3 endpoints | display 132.92 mm; depth rod visibly free | ______ to ______ |
| Thread diameter and pitch | likely M8 x 1.25, unconfirmed | ______ |
| Original bolt length | unknown | ______ |
| Usable thread engagement / rear clearance | unknown | ______ |
| Left bolt-land stand-off from straightedge | unknown | ______ |
| Right bolt-land stand-off from straightedge | unknown | ______ |
| Bolt-pair midpoint right of enclosure center | 40.0 mm owner-directed fit candidate | ______ |
| Adapter crossbar to enclosure right edge | 9.15 mm | verify silhouette: ______ |
| Clear left from bolt midpoint | 132.5 mm candidate | ______ |
| Clear right from bolt midpoint | 52.5 mm candidate | ______ |
| Case top below bolt-head lower tangent | 3.0 mm | verify: ______ |
| Hood above bolt-head upper tangent | 5.0 mm resolved datum within reported 5-7 mm | verify across depth: ______ |
| Reported lower-clearance endpoints | 150.0 mm display/report; endpoints not photographed | ______ to ______ |
| Provisional lower datum used in CAD | bolt axis (conservative versus head lower tangent) | verify or replace: ______ |
| Remaining clearance below case | 49.0 mm | verify: ______ |
| Package projection, adapter rear to lid exterior | 79.5 mm | ______ |
| Projection including low-profile lid heads | 82.5 mm | ______ |
| Empty clearance-gauge depth | 84.0 mm | pass/fail: ______ |
| Other hood / hinge / strut sweeps away from the measured bolt-head datum | >= 20 mm target | ______ |
| Fixed-part and harness clearance | >= 10 mm target | ______ |
| Fuse-box lid and latch service sweep | unknown | ______ |
| Brake-reservoir cap and hand access | unknown | ______ |
| Four sensor-gland thread/body/nut sets | provisional Ø12.5 cutout / Ø16.0 reserve | HIGH pressure: ______; HIGH temp: ______; LOW pressure: ______; LOW temp: ______ |
| POWER source/cable architecture | no cap penetration and no fifth hole in this revision | resolve separately: ______ |
| Internal gland-tail to interface-PCB service gap | 10.4 mm modeled | verify with purchased hardware: ______ |
| Inline plug length and cable bend radius | 60 mm working witness after 5 mm heel | ______ |
| Vehicle-structure P-clamp locations and fasteners | not represented by adapter concept | ______ |
| Case-sleeve pattern center / bolt-pair eccentricity | X=84.9 / 47.6 mm | verify load path: ______ |
| Engine-side formed returns / remaining case gap | 8.0 / 4.0 mm reference | verify formed part and no rub: ______ |
| Lower anti-rock reaction support | required; location unknown | measure structure/contact and service travel: ______ |
| ESP32-S3 Arduino UNO PCB outline | 68.58 x 53.34 mm standard datum; verify clone | ______ x ______ |
| ESP32 installed positive-X DC-jack overhang | 2.52 mm photo estimate after 180-degree in-plane rotation | ______ |
| Arduino UNO hole 1 from raw PCB datum | 66.04, 7.62 mm standard axis | pass/fail: ______ |
| Arduino UNO hole 2 from raw PCB datum | 66.04, 35.56 mm standard axis | pass/fail: ______ |
| Arduino UNO hole 3 from raw PCB datum | 13.97, 2.54 mm standard axis | pass/fail: ______ |
| Arduino UNO hole 4 from raw PCB datum | 15.24, 50.80 mm standard axis | pass/fail: ______ |
| Raspberry Pi/HAT mount span | 58 x 49 mm; Ø2.9 carrier clearance | coupon pass/fail: ______ |
| Raspberry Pi/HAT full bench keepout | 85 x 40 x 62.464 mm at X/Z origin 4,4 | verify: ______ |
| ESP32 underside / tallest populated depth | 8 mm standoff + 18 mm board envelope reserved | ______ / ______ |
| ESP32 USB-C and barrel plug insertion/removal envelope | rotated toward aisle; lid-off service only; not installed during use | ______ |
| Interface PCB finished outline / populated depth | 37 x 48 x <=15 mm design contract | ______ x ______ x ______ |
| Interface-board connector positions and removal direction | provisional aisle-facing zone; endpoint still requires a measured connector | ______ |
| Inter-board conductor count / insulation / gauge | unknown | ______ |
| Finished inter-board bundle diameter | <= 6 mm reserved | ______ |
| Minimum inter-board bend radius | >= 15 mm reserved | ______ |
| Inter-board disconnect/service slack | 14 x 34 x 42 mm reserved aisle plus 8 mm face plenum; shown segmented sweep and tie envelopes are unqualified | ______ |
| M2.5 PCB screw/standoff exact SKU | M2.5 x 6 + 8 mm through-tapped female-female, round body Ø4.8 mm maximum and strictly below 5.0 mm (no generic 5 mm-AF hex); nominal Ø5 washer leaves only 0.04 mm UNO edge reserve; 1.1 mm nominal / 0.6 mm budgeted tip gap | ______ / ______ |
| M3 standard insert exact SKU / coupon pilot | CNC Kitchen M3 x 5.7; 3.8-4.2 mm ladder | ______ / ______ |
| M3 short insert exact SKU / coupon pilot | CNC Kitchen M3 x 3; stepped Ø7.2/Ø4.0 sample | ______ / ______ |
| M2.5 insert exact SKU / coupon pilot | CNC Kitchen M2.5 x 4; coupon only | ______ / ______ |
| Worst running temperature | unknown | ______ |
| 30-60 minute parked hot-soak temperature | unknown | ______ |
| Cowl water path | unknown | ______ |

## Safe fit sequence

1. Identify the OEM purpose and torque of both bolts. Confirm pitch by hand; never force a fastener.
2. Remeasure bolt pitch with both opposed contacts visible. Name both endpoints of the 132.92 mm setting.
3. Print and test vehicle_bolt_coupon.stl without driving or running the engine.
4. Print `arduino_uno_mount_coupon.stl`; verify all four round standard-UNO axes without force, then install the board with a true 180-degree in-plane rotation so USB-C/barrel service faces the center aisle. Print `raspberry_pi_hat_mount_coupon.stl` for the exact 58 x 49 mm Pi/HAT axes; it is bench-only and does not authorize the UPS underhood.
5. Print `branding_qr_process_coupon.stl`; contrast-fill and scan both module sizes to `https://github.com/IsaiahDupree/orion-control-plane`. Reject an unreadable code before printing the signed lid or base plates.
6. Print `m25_board_clearance_coupon.stl`, `m3_insert_fit_coupon.stl`, `m3_horizontal_insert_boss_coupon.stl`, and `m25_insert_fit_coupon.stl` in the final candidate material. Record the selected board clearance, insert pilot, and exact purchased hardware SKU; never substitute another insert or standoff family's dimensions.
7. Qualify the full-height painted support-on-model column and interface with standing_bridge_coupon.stl before either tall enclosure part; verify in the slicer preview that support reaches the roof.
8. Print slot_clearance_cage.stl. Install its open-ended down-hanging frame empty, with the planned rigid spacers. Confirm the shifted tab finishes near the physical right edge, not the left.
9. Place soft modeling clay or crushable foam at the cage corners. Close the hood slowly by hand; never slam it.
10. Exercise the fuse-box latch/lid, reservoir cap, hood hinge, and gas strut through their full service/swept paths.
11. Seat the witness's 5 mm heel on the right datum. Verify 60 mm working clearance, downward drip loops, and separately measured vehicle-structure P-clamps for all four sensor pigtails. Confirm there is no fifth cap hole. Check the formed-return envelope and lower anti-rock reaction zone without allowing either to rub wiring or stamped sheet metal.
12. Redesign and build a measured wire mock-up in the 14 x 34 x 42 mm carrier-to-face aisle and 8 mm front-face plenum. Include both connector bodies, a <=6 mm finished bundle, one continuous tangent path with >=15 mm *inside* bend radius, retainers that physically capture that path, and removal slack. The packaged half-torus/stubs and offset tie envelopes are visualization-only. Confirm all eight PCB standoffs and four corner backplane drivers remain clear.
13. Record underhood running and parked hot-soak temperatures before selecting material. Batteries and UPS boards remain prohibited underhood.

Do not run or drive the vehicle with a loose printed gauge. Remove all clay, foam,
tools, and temporary hardware before starting the engine.

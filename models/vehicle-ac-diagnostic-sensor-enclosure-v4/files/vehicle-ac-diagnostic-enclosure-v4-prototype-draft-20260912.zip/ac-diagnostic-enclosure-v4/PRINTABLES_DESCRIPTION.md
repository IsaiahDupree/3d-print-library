# Vehicle A/C Diagnostic Sensor Enclosure V4 — prototype fit study

This is an AI-assisted, original enclosure system by Isaiah Dupree for an ESP32-based vehicle A/C diagnostic logger. It packages a removable electronics backplane, a service lid, and a four-entry right-side sensor-pigtail cap into a narrow under-hood fit-study envelope.

This upload is a **prototype draft**, not a qualified permanent under-hood product. Print and test the included coupons and clearance cage before the enclosure. Do not install or drive with loose gauges, and do not treat the present dimensions as a universal vehicle fit.

## What is included

- standing-print enclosure body, front service lid, removable electronics backplane, and right pigtail cap;
- four dedicated sensor entries: HIGH pressure, HIGH temperature, LOW pressure, and LOW temperature;
- no fifth/power entry;
- Arduino UNO-pattern and Raspberry Pi/HAT-pattern mounting coupons;
- M2.5/M3 clearance and heat-set-insert coupons;
- vehicle bolt, hood-depth, right-I/O, bridge/support, gasket/branding-process, and clearance-cage test pieces;
- STEP sources, STL exports, FreeCAD assembly source, generator script, BOM, measurements, and detailed design/printing notes.

The vehicle mounting feature is a measurement-gated round-and-slotted two-hole candidate on approximately 50.53 mm centers, shifted toward the enclosure's right edge. It is a drill/fit template for a separate flat metal adapter; printed polymer must not be placed in the OEM bolt clamp stack.

## Safety boundaries

- No printed part contains refrigerant pressure. Hoses, fittings, tees, pressure transducers, and temperature probes remain external, pressure-rated hardware.
- No lithium cells or UPS board are approved inside the under-hood enclosure. The Pi/HAT battery plate is a separate bench-only part.
- PLA and PETG are fit-check materials only. ASA is still provisional until the actual vehicle's parked hot-soak temperature, water path, vibration, chemical exposure, hood sweep, and fastener load path are measured.
- The enclosure does not have an IP rating. Gasket geometry must pass leak, condensation, thermal-cycle, and vibration testing.

## Recommended test order

1. Print the bolt, board-hole, insert, gland, QR/branding, wall-hole, and bridge coupons.
2. Verify every purchased fastener, insert, gland body/nut, board revision, connector, and cable bend radius without forcing parts.
3. Print and install the empty `slot_clearance_cage.stl` with rigid spacers while the engine is off and cold.
4. Use soft clay or crushable foam and close the hood slowly by hand. Check the hood, hinge, gas strut, fuse-box lid/latch, reservoir access, and wiring sweeps.
5. Only after those checks pass, print the full enclosure parts.

## FLSUN V400 prototype slicing

The supplied STL files were geometry-validated and sliced individually with CuraEngine 5.9.0 for the FLSUN V400 at 0.20 mm layers, 100% infill, five walls (2.2 mm), and six top/bottom layers. The tested preparation package applies Klipper runtime factors `M220 S50` and `M221 S80`; these are machine-side speed and extrusion multipliers, not replacements for material calibration.

The body is supplied as `body_standing.stl` with its flat short side on the bed. The lid prints exterior-face down with the gasket groove up. The right cap prints upright. Inspect the full layer preview and painted supports before every print; the tall parts and bridge features are intentionally preceded by process coupons.

## Hardware and fitment status

The backplane uses a standard Arduino UNO four-hole datum for the photographed ESP32-S3 UNO-format board and reserves a separate custom interface-PCB zone plus a wiring aisle. The separate bench plate uses the standard Raspberry Pi/HAT 58 × 49 mm four-hole pattern. Exact board outlines, standoffs, insert SKUs, connectors, and service loops must still be measured with the physical parts.

The complete engineering notes and measurement worksheet are included in the download. Current public project mirror: https://github.com/IsaiahDupree/3d-print-library. Design requests: https://github.com/IsaiahDupree/3d-print-library/issues/new/choose.

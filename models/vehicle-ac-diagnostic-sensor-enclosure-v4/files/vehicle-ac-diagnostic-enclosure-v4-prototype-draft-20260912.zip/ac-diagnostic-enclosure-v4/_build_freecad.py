
import json, math, os
import FreeCAD as App
import Part
import MeshPart
from FreeCAD import Vector

P = {'case_width_mm': 185.0, 'case_height_mm': 88.0, 'case_depth_mm': 60.0, 'wall_mm': 3.2, 'back_wall_mm': 4.0, 'lid_thickness_mm': 5.0, 'mount_hole_spacing_mm': 50.53, 'mount_pair_offset_x_mm': 40.0, 'mount_hole_d_mm': 9.2, 'mount_slot_length_mm': 14.0, 'case_top_to_head_bottom_mm': 3.0, 'hood_clearance_above_head_mm': 5.0, 'reported_lower_clearance_mm': 150.0, 'adapter_gap_mm': 12.0, 'gasket_cord_d_mm': 2.5, 'pigtail_gland_d_mm': 12.5}
FIXED = {'right_recess_depth_mm': 12.0, 'right_panel_web_mm': 3.2, 'cap_receiver_length_mm': 8.0, 'cap_receiver_radius_mm': 6.3, 'cap_receiver_root_radius_mm': 4.5, 'cap_screw_clearance_d_mm': 3.6, 'm3_insert_pocket_d_mm': 4.0, 'm3_insert_length_mm': 5.7, 'm3_insert_max_od_mm': 4.6, 'm3_insert_depth_mm': 6.7, 'm3_insert_min_radial_wall_mm': 1.6, 'm3_insert_min_backing_mm': 1.5, 'cap_m3_insert_length_mm': 3.0, 'cap_m3_insert_min_bore_depth_mm': 4.0, 'cap_m3_insert_total_pocket_depth_mm': 5.7, 'cap_pilot_od_mm': 6.8, 'cap_pilot_length_mm': 1.5, 'cap_pilot_counterbore_d_mm': 7.2, 'cap_pilot_counterbore_depth_mm': 1.7, 'cap_driver_keepout_d_mm': 11.0, 'cap_seal_width_mm': 1.6, 'cap_seal_stock_thickness_mm': 1.0, 'cap_seal_depth_mm': 0.75, 'cap_seal_inset_mm': 1.6, 'front_right_seal_rail_mm': 3.2, 'backplane_thickness_mm': 3.0, 'backplane_standoff_mm': 8.2, 'backplane_boss_d_mm': 10.0, 'backplane_boss_length_mm': 8.2, 'backplane_insert_depth_mm': 6.7, 'backplane_mount_pad_d_mm': 10.0, 'backplane_mount_pad_extra_mm': 1.0, 'backplane_screw_clearance_d_mm': 3.6, 'backplane_driver_keepout_d_mm': 8.0, 'minimum_backplane_driver_component_clearance_mm': 1.0, 'backplane_driver_design_clearance_mm': 1.0, 'component_standoff_mm': 8.0, 'board_m25_screw_clearance_d_mm': 2.9, 'board_m25_standoff_length_mm': 8.0, 'board_m25_standoff_od_mm': 4.8, 'board_m25_washer_od_mm': 5.0, 'board_m25_hardware_max_corner_d_mm': 5.0, 'board_m25_washer_thickness_mm': 0.5, 'controller_candidate_pcb_thickness_mm': 1.6, 'interface_pcb_thickness_mm': 1.6, 'board_m25_minimum_thread_engagement_mm': 2.5, 'board_m25_minimum_worst_case_tip_gap_mm': 0.5, 'board_m25_axial_tolerance_budget_mm': 0.5, 'interboard_wiring_corridor_mm': 14.0, 'interboard_hardware_clearance_mm': 1.0, 'interface_pcb_edge_setback_from_wire_mm': 1.0, 'interboard_wire_keepout_vertical_margin_mm': 3.0, 'board_face_wiring_plenum_depth_mm': 8.0, 'gasket_groove_extra_width_mm': 0.8, 'gasket_land_extra_mm': 5.0, 'gland_keepout_d_mm': 16.0, 'gland_keepout_length_mm': 14.0, 'minimum_gland_component_clearance_mm': 1.0, 'minimum_gland_to_gland_clearance_mm': 3.0, 'minimum_gland_face_edge_clearance_mm': 5.0, 'minimum_gland_lid_boss_clearance_mm': 2.0, 'minimum_right_io_internal_service_gap_mm': 10.0, 'cable_tie_slot_width_mm': 3.2, 'cable_tie_slot_height_mm': 5.0, 'cable_tie_slot_edge_margin_mm': 1.5, 'cable_tie_strap_width_mm': 2.5, 'cable_tie_strap_thickness_mm': 1.2, 'cable_tie_head_x_mm': 6.0, 'cable_tie_head_y_mm': 4.0, 'cable_tie_head_z_mm': 4.0, 'wall_sacrificial_membrane_mm': 0.45, 'adapter_plate_thickness_mm': 2.5, 'adapter_crossbar_width_mm': 86.7, 'adapter_top_inset_mm': 1.0, 'adapter_tab_overlap_mm': 5.0, 'adapter_case_hole_d_mm': 4.5, 'adapter_case_pattern_width_mm': 90.0, 'adapter_case_pattern_height_mm': 58.0, 'adapter_spacer_d_mm': 10.0, 'adapter_body_passage_d_mm': 10.4, 'adapter_sleeve_proud_mm': 0.1, 'adapter_return_max_depth_mm': 8.0, 'adapter_return_min_case_gap_mm': 3.0, 'adapter_return_flange_count': 3, 'minimum_adapter_return_depth_mm': 5.0, 'minimum_adapter_crossbar_case_edge_margin_mm': 3.0, 'maximum_adapter_mount_eccentricity_mm': 50.0, 'minimum_sleeve_passage_ligament_mm': 8.0, 'minimum_mount_feature_clearance_mm': 2.0, 'vehicle_head_envelope_d_mm': 20.0, 'minimum_lower_clearance_reserve_mm': 20.0, 'rear_load_rib_width_mm': 3.2, 'rear_load_rib_depth_mm': 2.4, 'sleeve_collar_od_mm': 16.0, 'cap_lid_screw_edge_offset_mm': 3.5, 'minimum_lid_hole_ligament_mm': 1.5, 'lid_head_allowance_mm': 3.0, 'fit_cage_depth_margin_mm': 1.5, 'fit_cage_rail_mm': 5.0, 'fit_cage_brace_d_mm': 3.0, 'fit_static_clearance_mm': 10.0, 'fit_moving_clearance_mm': 20.0, 'external_pigtail_service_mm': 60.0, 'io_witness_datum_heel_mm': 5.0, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0, 'standing_body_brim_mm': 12.0, 'flat_part_brim_mm': 6.0}
FASTENERS = {'lid': {'fastener': 'M3 x 10 low-profile ISO 14580', 'quantity': 10, 'length_under_head_mm': 10.0, 'head_d_mm': 5.5, 'head_h_mm': 2.4, 'pitch_mm': 0.5, 'insert': 'structural_m3_standard', 'source': 'https://cnckitchen.store/products/schraube'}, 'cap': {'fastener': 'M3 x 8 low-profile ISO 14580', 'quantity': 4, 'length_under_head_mm': 8.0, 'head_d_mm': 5.5, 'head_h_mm': 2.4, 'pitch_mm': 0.5, 'insert': 'cap_m3_short', 'source': 'https://cnckitchen.store/products/schraube'}, 'backplane': {'fastener': 'M3 x 8 low-profile ISO 14580', 'quantity': 4, 'length_under_head_mm': 8.0, 'head_d_mm': 5.5, 'head_h_mm': 2.4, 'pitch_mm': 0.5, 'insert': 'structural_m3_standard', 'source': 'https://cnckitchen.store/products/schraube'}, 'controller': {'fastener': 'M2.5 x 6 low-profile with nylon washer', 'quantity': 8, 'thread_d_mm': 2.5, 'length_under_head_mm': 6.0, 'head_d_mm': 4.5, 'head_h_mm': 1.85, 'pitch_mm': 0.45, 'standoff': 'four 8 mm through-tapped female-female M2.5 metal standoffs', 'standoff_status': 'exact_sku_and_usable_thread_depth_pending_procurement', 'source': 'https://cnckitchen.store/products/m2-5-screw-stainless-steel-aisi-304-low-head'}, 'interface': {'fastener': 'M2.5 x 6 low-profile with nylon washer', 'quantity': 8, 'thread_d_mm': 2.5, 'length_under_head_mm': 6.0, 'head_d_mm': 4.5, 'head_h_mm': 1.85, 'pitch_mm': 0.45, 'standoff': 'four 8 mm through-tapped female-female M2.5 metal standoffs', 'standoff_status': 'exact_sku_and_usable_thread_depth_pending_procurement', 'source': 'https://cnckitchen.store/products/m2-5-screw-stainless-steel-aisi-304-low-head'}}
MECH = {'coordinate_system': {'origin': 'lower-left corner of enclosure rear face', 'x': 'positive toward fuse/relay boxes', 'y': 'positive toward engine/camera', 'z': 'positive toward cowl'}, 'body_cap_interface_x_mm': 169.8, 'right_panel_face_x_mm': 173.0, 'lid_width_mm': 185.0, 'mount_midpoint_xz_mm': [132.5, 101.0], 'case_center_x_mm': 92.5, 'mount_pair_offset_x_mm': 40.0, 'mount_centers_xz_mm': [[107.235, 101.0], [157.765, 101.0]], 'mount_features': ['round', 'horizontal_slot'], 'mount_midpoint_relative_envelope_mm': {'left': -132.5, 'right': 52.5, 'below': -101.0, 'above': 9.0}, 'bolt_head_envelope_mm': {'diameter': 20.0, 'lower_z': 91.0, 'upper_z': 111.0}, 'adapter_crossbar_x_mm': [89.15, 175.85], 'adapter_crossbar_case_edge_margins_mm': [89.15, 9.150000000000006], 'adapter_return_depth_mm': 8.0, 'adapter_return_to_case_gap_mm': 4.0, 'adapter_case_pattern_center_x_mm': 84.9, 'mount_to_case_pattern_eccentricity_x_mm': 47.599999999999994, 'adapter_top_z_mm': 110.0, 'bolt_plane_hood_datum_z_mm': 116.0, 'lower_obstruction_z_mm': -49.0, 'lower_clearance_datum': 'provisional bolt axis; reported 150 mm endpoints unresolved', 'case_drop_below_bolt_axis_mm': 101.0, 'lower_clearance_reserve_mm': 49.0, 'adapter_case_centers_xz_mm': [[39.900000000000006, 15.0], [129.9, 15.0], [39.900000000000006, 73.0], [129.9, 73.0]], 'face_flange_width_mm': 10.8, 'service_throat_xz_mm': [10.8, 166.60000000000002, 10.8, 77.2], 'cap_screw_centers_yz_mm': [[6.0, 6.0], [54.0, 6.0], [6.0, 82.0], [54.0, 82.0]], 'cap_seam_gasket': {'path': 'closed rectangle', 'seat_width_mm': 1.6, 'seat_depth_mm': 0.75, 'nominal_stock_thickness_mm': 1.0, 'target_compression_percent': 25.0}, 'backplane_origin_mm': [11.3, 12.2, 11.700000000000001], 'backplane_size_mm': [154.8, 3.0, 64.6], 'backplane_mount_centers_xz_mm': [[16.3, 16.700000000000003], [161.10000000000002, 16.700000000000003], [16.3, 71.3], [161.10000000000002, 71.3]], 'backplane_cable_tie_slot_centers_xz_mm': [[96.89999999999999, 41.0], [103.89999999999999, 41.0], [96.89999999999999, 50.0], [103.89999999999999, 50.0]], 'controller_envelope_origin_x_mm': 21.3, 'controller_mount_fixed_hole_envelope_bounds_xz_mm': {'x_min': 0.040000000000000036, 'x_max': 57.11, 'z_min': 0.040000000000000036, 'z_max': 53.3}, 'interboard_wiring_corridor_x_mm': [93.39999999999999, 107.39999999999999], 'gasket': {'cord_d_mm': 2.5, 'groove_width_mm': 3.3, 'groove_depth_mm': 1.875, 'land_inset_mm': 7.5, 'target_compression_percent': 25.0}, 'standing_footprint_mm': [60.0, 88.0], 'standing_body_height_mm': 169.8, 'right_cap_print_footprint_mm': [16.69999999999999, 60.0], 'standing_bridge_coupon_span_mm': 66.4, 'standing_bridge_coupon_support_height_mm': 166.60000000000002, 'full_case_width_mm': 185.0, 'v400_body_required_radius_mm': 65.2541078227774, 'installed_projection_mm': 79.5, 'installed_hardware_projection_mm': 82.5, 'fit_cage_envelope_mm': [185.0, 84.0, 110.0], 'photo_envelope_basis': 'owner-measured hood gap plus a reported 150 mm lower span whose endpoints remain unresolved; 50.53 mm remains a slotted bolt-pitch candidate and exact hood slope across depth remains gated'}
LAYOUT = {'owner_esp32_s3_uno_candidate': {'origin_mm': [21.3, 23.2, 17.33], 'size_mm': [71.1, 18.0, 53.34], 'tier': 'single_backplane', 'mount': '180-degree in-plane rotated candidate UNO pattern using 8 mm M2.5 commercial standoffs; pattern coupon required before carrier print'}, 'interface_pcb_reserved': {'origin_mm': [108.39999999999999, 23.2, 20.0], 'size_mm': [37.0, 15.0, 48.0], 'tier': 'single_backplane', 'mount': 'design-controlled four-hole M2.5 pattern on 8 mm commercial standoffs; custom PCB must retain its corridor-facing connector and integrate measured microSD/SHT40 footprints'}}
WIRE_SERVICE = {'origin_mm': [93.39999999999999, 15.2, 23.0], 'size_mm': [14.0, 34.0, 42.0], 'board_face_plenum': {'origin_mm': [21.3, 41.2, 17.33], 'size_mm': [124.09999999999998, 8.0, 53.34]}, 'bend_sweep': {'center_mm': [100.39999999999999, 45.2, 26.0], 'axis': 'positive_y', 'revolution_deg': 180.0, 'inside_radius_mm': 15.0, 'centerline_radius_mm': 18.0, 'bundle_radius_mm': 3.0, 'endpoint_centers_xz_mm': [[82.39999999999999, 26.0], [118.39999999999999, 26.0]]}, 'minimum_width_mm': 14.0, 'maximum_finished_bundle_od_mm': 6.0, 'minimum_static_inside_bend_radius_mm': 15.0, 'connector_intrusion_each_side_mm': 4.0, 'minimum_center_handoff_clearance_mm': 4.0, 'status': 'blocked_pending_measured_connectors_tangent_route_and_retention_redesign', 'policy': 'the aisle and face plenum reserve volume for a future measured jumper route; the shown half-torus, connector stubs, and tie envelopes are visualization-only and do not prove a continuous tangent bend or cable retention; rotated USB-C/barrel connectors remain lid-off service only'}
WIRE_ROUTE_SPEC = {'maximum_finished_bundle_od_mm': 6.0, 'minimum_static_inside_bend_radius_mm': 15.0, 'connector_intrusion_each_side_mm': 4.0, 'minimum_center_handoff_clearance_mm': 4.0, 'minimum_lid_facing_service_depth_mm': 8.0, 'minimum_service_loop_height_mm': 42.0, 'minimum_hardware_to_route_clearance_mm': 1.0, 'controller_endpoint_status': 'reserved_zone_pending_owner_board_header_measurement', 'interface_endpoint_status': 'provisional_custom_pcb_zone_pending_connector_definition', 'retention_status': 'blocked_tie_envelopes_do_not_capture_the_shown_front_face_loop', 'sweep_status': 'blocked_segment_transitions_are_not_a_continuous_tangent_bend', 'status': 'blocked_pending_measured_connectors_tangent_route_and_retention_redesign'}
INTERFACE_HOLES = [[3.5, 3.5], [33.5, 3.5], [3.5, 44.5], [33.5, 44.5]]
BRANDING = {'signature': 'ISAIAH DUPREE', 'repository_url': 'https://github.com/IsaiahDupree/orion-control-plane', 'qr_error_correction': 'Q', 'qr_version': 5, 'qr_data_modules': 37, 'qr_quiet_zone_modules': 4, 'process': 'recessed_square_cells_and_block_text_then_contrast_paint', 'maximum_row_isolation_gap_mm': 0.04, 'lid': {'coordinate_frame': 'installed_global_xz_mm', 'qr_module_mm': 1.0, 'qr_quiet_origin_xz_mm': [124.0, 21.5], 'signature_cell_mm': 1.1, 'signature_origin_xz_mm': [20.0, 40.15], 'recess_depth_mm': 0.55, 'minimum_residual_thickness_mm': 4.4}, 'backplane': {'coordinate_frame': 'installed_global_xz_mm', 'face': 'rear_service_face', 'qr_module_mm': 0.8, 'qr_quiet_origin_xz_mm': [34.0, 26.0], 'signature_cell_mm': 0.8, 'signature_origin_xz_mm': [82.0, 31.0], 'recess_depth_mm': 0.35, 'minimum_residual_thickness_mm': 2.6}, 'raspberry_pi_hat_bench_baseplate': {'coordinate_frame': 'plate_local_xz_mm', 'outline_xz_mm': [130.0, 70.0], 'board_origin_xz_mm': [4.0, 4.0], 'face': 'rear_service_face', 'qr_module_mm': 0.8, 'qr_quiet_origin_xz_mm': [90.0, 14.0], 'signature_cell_mm': 0.65, 'signature_origin_xz_mm': [10.0, 28.0], 'recess_depth_mm': 0.35, 'minimum_residual_thickness_mm': 2.6, 'status': 'bench_only_not_an_underhood_battery_release'}}
QR_MATRIX = ('FFFFFFFBBFBFBFFBFFFBFBFBFFBBFBFFFFFFF', 'FBBBBBFBFBBFFBFFBFFBFBBFFFBBFBFBBBBBF', 'FBFFFBFBFFFFFFFFBFBBBBFBBFBBFBFBFFFBF', 'FBFFFBFBBBFBFBBBBBBBFBFBBFBFBBFBFFFBF', 'FBFFFBFBBBFFFBBFFFFBBBFBFBFFBBFBFFFBF', 'FBBBBBFBBBFFBFFBFFBBFBBBBFBBBBFBBBBBF', 'FFFFFFFBFBFBFBFBFBFBFBFBFBFBFBFFFFFFF', 'BBBBBBBBBBFFBBFBFBBBFBFBFBBFFBBBBBBBB', 'BFFFBFFBBBBFFBBFFBBFBFBFFFBFFBBBBBFFB', 'FFBFFFBBFBFFBBBBBBFFBFFFBFFFFBBFBBFBB', 'BBFFFFFBFFFBFFBFFFBFFBFFBFBFBFBFFFBBB', 'BFBFFFBBFFBFFFBFBBFBBBFBFFFFBBBFBFFFB', 'FBFBBFFBBBFFFBFFFFBBBBFBFFFBBFFFFBFFF', 'BFFBFFBBBBBFFFBFBBFBFFFBFFFFFBFFFBFFF', 'BFBFBBFFFFFFBBFFFBBFFFBBBFBBBFFBFBFFB', 'FFBBBFBFBFBBBFBBBBBFFBBBBBFBFFBFFBBBB', 'FBBBFFFBFBBBFBBFFFBFBBFFBFBFBBBBBFFBF', 'BBBFBBBBFBBFFBBBBFFFBBFBFBBFBBBFBBFBF', 'FFFBBFFBFFFBFBBBFFBFFFFFFBFFFBFFBBFFF', 'FBBBFFBBFBFBFBFFFBFBFBFBFBBFBFFFBFBBF', 'BFBFFBFBBBBFFBBBBBBFFFBFBBFBFFBBFBBBB', 'BFFFFBBBBFBBBFFBBBFBBFBFBFBBBBBFBBBBB', 'BBFFFBFFFFBBFBBFBBFFBBBFFFBBBBFBFFBFB', 'BFBFBBBBBBFFBBFBBFFBBBFFFBBFFBFBBBFBB', 'FBBFBBFBBBBBFBBBBFBBBBFFFBFBBFFBFFFFB', 'BBFBFBBBFFBFFBBBFBFFFBFFFBFBBFFFFBBFF', 'BFBFFBFBBFFBFFBFBFBBBFFBBBFBBBBFBBFFB', 'FBBBBBBFFFBBFBBBFFFFBFBBFBFFFFBFFBBBB', 'BBBFBBFBBBFFFFFBBFFBBFFBFFBBFFFFFBFFB', 'BBBBBBBBFBFBFBFBBFFBFBFFFFBBFBBBFFFBF', 'FFFFFFFBBBFFBFBFBFBFBFBBBBBBFBFBFFBBF', 'FBBBBBFBFBFFFFBFFFFFFBFFBBBFFBBBFFBFF', 'FBFFFBFBBFFFBFBBFBFBBBFFFBFBFFFFFFBBB', 'FBFFFBFBFFBFFFBFBFBBFBFBFBBBBBFBFBFFB', 'FBFFFBFBFFBBFBBBBFFFFFFFFFFBFBFFFFFFB', 'FBBBBBFBFBFFBBBBFBFBFBBBBFFFBBFBFFFBB', 'FFFFFFFBBBBBFBBFBBFFBBFBFFFBBFFFFFFFF')
BLOCK_FONT = {'A': ('01110', '10001', '10001', '11111', '10001', '10001', '10001'), 'D': ('11110', '10001', '10001', '10001', '10001', '10001', '11110'), 'E': ('11111', '10000', '10000', '11110', '10000', '10000', '11111'), 'H': ('10001', '10001', '10001', '11111', '10001', '10001', '10001'), 'I': ('11111', '00100', '00100', '00100', '00100', '00100', '11111'), 'P': ('11110', '10001', '10001', '11110', '10000', '10000', '10000'), 'R': ('11110', '10001', '10001', '11110', '10100', '10010', '10001'), 'S': ('01111', '10000', '10000', '01110', '00001', '00001', '11110'), 'U': ('10001', '10001', '10001', '10001', '10001', '10001', '01110')}
IO = {'pigtail_glands': [{'id': 'HIGH_PRESSURE', 'circuit': 'high_side_pressure', 'center_yz_mm': [18.7, 64.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'HIGH_TEMPERATURE', 'circuit': 'high_side_temperature', 'center_yz_mm': [41.3, 64.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'LOW_PRESSURE', 'circuit': 'low_side_pressure', 'center_yz_mm': [18.7, 24.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'LOW_TEMPERATURE', 'circuit': 'low_side_temperature', 'center_yz_mm': [41.3, 24.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}], 'sensor_port_groups': {'HIGH': ['HIGH_PRESSURE', 'HIGH_TEMPERATURE'], 'LOW': ['LOW_PRESSURE', 'LOW_TEMPERATURE']}, 'power': {'installed_cutout': False, 'entry': 'no POWER penetration in this revision', 'requirement': 'power architecture remains unresolved; do not add or drill a fifth hole'}, 'vent': {'installed_cutout': False, 'reason': 'no penetration until a purchased membrane vent is measured and qualified'}, 'external_connector_policy': 'four individually labelled and keyed sensor pigtails; no POWER penetration; keyed inline disconnects outside enclosure; panel SP13 option requires separately measured doghouse'}
OUT = 'C:\\orion\\control\\modeling\\manual-slot-v4-four-sensor-branded-final5\\out'
os.makedirs(OUT, exist_ok=True)

def die(message):
    print("CAD_ERROR " + message, flush=True)
    raise RuntimeError(message)

def bbox(shape):
    b = shape.BoundBox
    return {
        "min_mm": [b.XMin, b.YMin, b.ZMin],
        "max_mm": [b.XMax, b.YMax, b.ZMax],
        "size_mm": [b.XLength, b.YLength, b.ZLength],
    }

def assert_single(name, shape):
    if shape.isNull() or not shape.isValid() or len(shape.Solids) != 1 or shape.Volume <= 0:
        die("%s is not one valid positive-volume solid (solids=%d)" %
            (name, len(shape.Solids)))

def assert_valid(name, shape):
    if shape.isNull() or not shape.isValid():
        die("%s is null or invalid" % name)

def export_pair(shape, stem):
    shape.exportStep(os.path.join(OUT, stem + ".step"))
    mesh = MeshPart.meshFromShape(
        Shape=shape, LinearDeflection=0.08,
        AngularDeflection=0.25, Relative=False,
    )
    mesh.write(os.path.join(OUT, stem + ".stl"))

def add_feature(doc, name, label, shape, color, transparency=0):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = shape
    try:
        obj.ViewObject.ShapeColor = color
        obj.ViewObject.Transparency = transparency
    except Exception:
        pass
    return obj

def bed_orient(shape, rotation):
    result = shape.copy()
    result.Placement = App.Placement(Vector(0, 0, 0), rotation)
    b = result.BoundBox
    result.translate(Vector(-b.XMin, -b.YMin, -b.ZMin))
    return result

def hole_y(cx, cz, diameter, y0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(cx, y0, cz), Vector(0, 1, 0)
    )

def hole_x(cy, cz, diameter, x0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(x0, cy, cz), Vector(1, 0, 0)
    )

def capsule_y(cx, cz, overall, diameter, y0, depth):
    travel = overall - diameter
    left = hole_y(cx - travel / 2.0, cz, diameter, y0, depth)
    right = hole_y(cx + travel / 2.0, cz, diameter, y0, depth)
    bridge = Part.makeBox(
        travel, depth, diameter,
        Vector(cx - travel / 2.0, y0, cz - diameter / 2.0),
    )
    return left.fuse(right).fuse(bridge).removeSplitter()

def capsule_y_angle(cx, cz, overall, diameter, angle_deg, y0, depth):
    travel = overall - diameter
    angle = math.radians(angle_deg)
    ux, uz = math.cos(angle), math.sin(angle)
    px, pz = -uz * diameter / 2.0, ux * diameter / 2.0
    x0, z0 = cx - ux * travel / 2.0, cz - uz * travel / 2.0
    x1, z1 = cx + ux * travel / 2.0, cz + uz * travel / 2.0
    polygon = Part.makePolygon([
        Vector(x0 + px, y0, z0 + pz),
        Vector(x1 + px, y0, z1 + pz),
        Vector(x1 - px, y0, z1 - pz),
        Vector(x0 - px, y0, z0 - pz),
        Vector(x0 + px, y0, z0 + pz),
    ])
    bridge = Part.Face(polygon).extrude(Vector(0, depth, 0))
    end0 = hole_y(x0, z0, diameter, y0, depth)
    end1 = hole_y(x1, z1, diameter, y0, depth)
    return bridge.fuse(end0).fuse(end1).removeSplitter()

def _run_boxes_y(cells, cell_mm, origin_x, origin_z, columns, rows, y_face,
                 depth, inward_sign, mirror_x=False):
    """Build row-run recess cutters on a Y-normal face."""
    boxes = []
    row_gap = min(BRANDING["maximum_row_isolation_gap_mm"], cell_mm * 0.05)
    by_row = {}
    for column, row in cells:
        mapped_column = columns - 1 - column if mirror_x else column
        by_row.setdefault(row, []).append(mapped_column)
    for row, row_columns in by_row.items():
        ordered = sorted(row_columns)
        starts = []
        run_start = ordered[0]
        previous = ordered[0]
        for column in ordered[1:]:
            if column != previous + 1:
                starts.append((run_start, previous))
                run_start = column
            previous = column
        starts.append((run_start, previous))
        for run_start, run_end in starts:
            x0 = origin_x + run_start * cell_mm
            z0 = origin_z + (rows - 1 - row) * cell_mm + row_gap / 2.0
            if inward_sign > 0:
                y0 = y_face - 0.1
            else:
                y0 = y_face - depth
            boxes.append(Part.makeBox(
                (run_end - run_start + 1) * cell_mm,
                depth + 0.1,
                cell_mm - row_gap,
                Vector(x0, y0, z0),
            ))
    return boxes

def qr_recess_y(matrix, quiet_origin_xz, module_mm, quiet_modules,
                y_face, depth, inward_sign, mirror_x=False):
    data_columns = len(matrix)
    cells = [
        (column + quiet_modules, row + quiet_modules)
        for row, line in enumerate(matrix)
        for column, value in enumerate(line)
        if value == "F"
    ]
    full_columns = data_columns + 2 * quiet_modules
    boxes = _run_boxes_y(
        cells, module_mm, quiet_origin_xz[0], quiet_origin_xz[1],
        full_columns, full_columns, y_face, depth, inward_sign, mirror_x,
    )
    row_gap = min(BRANDING["maximum_row_isolation_gap_mm"], module_mm * 0.05)
    expected_volume = len(cells) * module_mm * (module_mm - row_gap) * depth
    return Part.makeCompound(boxes), expected_volume, len(boxes)

def text_recess_y(text, origin_xz, cell_mm, y_face, depth, inward_sign,
                  mirror_x=False):
    cells = []
    cursor = 0
    width_cells = 0
    for character in text:
        if character == " ":
            cursor += 4
            continue
        glyph = BLOCK_FONT[character]
        for row, line in enumerate(glyph):
            for column, value in enumerate(line):
                if value == "1":
                    cells.append((cursor + column, row))
        width_cells = cursor + 5
        cursor += 6
    boxes = _run_boxes_y(
        cells, cell_mm, origin_xz[0], origin_xz[1], width_cells, 7,
        y_face, depth, inward_sign, mirror_x,
    )
    row_gap = min(BRANDING["maximum_row_isolation_gap_mm"], cell_mm * 0.05)
    expected_volume = len(cells) * cell_mm * (cell_mm - row_gap) * depth
    return Part.makeCompound(boxes), expected_volume, len(boxes)

def apply_recess(label, shape, cutter, expected_volume, tolerance=0.03):
    before = shape
    after = before.cut(cutter).removeSplitter()
    removed_volume = before.Volume - after.Volume
    passed = (
        after.isValid()
        and len(after.Solids) == 1
        and abs(removed_volume - expected_volume) <= tolerance
    )
    row = {
        "feature": label,
        "expected_removed_mm3": expected_volume,
        "actual_removed_mm3": removed_volume,
        "error_mm3": removed_volume - expected_volume,
        "valid": after.isValid(),
        "solids": len(after.Solids),
        "pass": passed,
    }
    if not passed:
        die("branding recess geometry drifted for %s: %r" % (label, row))
    return after, row

def audit_round_cut_y(part_name, feature_name, blank, cut_part, cutter,
                      expected_center_xz, expected_diameter):
    cutter_box = cutter.BoundBox
    margin = 0.5
    window = Part.makeBox(
        cutter_box.XLength + 2.0 * margin,
        cutter_box.YLength + 2.0 * margin,
        cutter_box.ZLength + 2.0 * margin,
        Vector(
            cutter_box.XMin - margin,
            cutter_box.YMin - margin,
            cutter_box.ZMin - margin,
        ),
    )
    actual = blank.cut(cut_part).common(window).removeSplitter()
    expected = blank.common(cutter).common(window).removeSplitter()
    extra = actual.cut(expected).Volume
    missing = expected.cut(actual).Volume
    actual_box = actual.BoundBox
    actual_center = [
        (actual_box.XMin + actual_box.XMax) / 2.0,
        (actual_box.ZMin + actual_box.ZMax) / 2.0,
    ]
    actual_size = [actual_box.XLength, actual_box.ZLength]
    passed = (
        not actual.isNull()
        and not expected.isNull()
        and extra <= 0.0001
        and missing <= 0.0001
        and max(abs(actual_center[index] - expected_center_xz[index])
                for index in range(2)) <= 0.001
        and max(abs(actual_size[index] - expected_diameter)
                for index in range(2)) <= 0.001
    )
    row = {
        "part": part_name,
        "feature": feature_name,
        "actual_center_xz_mm": actual_center,
        "expected_center_xz_mm": expected_center_xz,
        "actual_size_xz_mm": actual_size,
        "expected_diameter_mm": expected_diameter,
        "extra_removed_mm3": extra,
        "missing_removed_mm3": missing,
        "pass": passed,
    }
    if not passed:
        die("%s %s round mount-cut geometry drifted" % (part_name, feature_name))
    return row

def audit_blind_insert_bore_y(part_name, feature_name, removed_shape, before_shape,
                              cutter, expected_center_xz, expected_diameter,
                              expected_depth, boss_od, boss_axial, backing):
    cutter_box = cutter.BoundBox
    margin = 0.4
    window = Part.makeBox(
        cutter_box.XLength + 2.0 * margin,
        cutter_box.YLength + 2.0 * margin,
        cutter_box.ZLength + 2.0 * margin,
        Vector(
            cutter_box.XMin - margin,
            cutter_box.YMin - margin,
            cutter_box.ZMin - margin,
        ),
    )
    actual = removed_shape.common(window).removeSplitter()
    expected = before_shape.common(cutter).common(window).removeSplitter()
    actual_box = actual.BoundBox
    expected_box = expected.BoundBox
    center_xz = [
        (actual_box.XMin + actual_box.XMax) / 2.0,
        (actual_box.ZMin + actual_box.ZMax) / 2.0,
    ]
    size_xyz = [actual_box.XLength, actual_box.YLength, actual_box.ZLength]
    extra = actual.cut(expected).Volume
    missing = expected.cut(actual).Volume
    passed = (
        not actual.isNull()
        and not expected.isNull()
        and extra <= 0.0001
        and missing <= 0.0001
        and max(abs(center_xz[index] - expected_center_xz[index])
                for index in range(2)) <= 0.001
        and abs(size_xyz[0] - expected_diameter) <= 0.001
        and abs(size_xyz[2] - expected_diameter) <= 0.001
        and abs(size_xyz[1] - expected_depth) <= 0.001
        and abs(expected_box.YLength - expected_depth) <= 0.001
        and boss_od + 0.001 >= (
            expected_diameter + 2.0 * FIXED["m3_insert_min_radial_wall_mm"]
        )
        and boss_axial + 0.001 >= (
            expected_depth + FIXED["m3_insert_min_backing_mm"]
        )
        and backing + 0.001 >= FIXED["m3_insert_min_backing_mm"]
    )
    row = {
        "part": part_name,
        "feature": feature_name,
        "actual_center_xz_mm": center_xz,
        "expected_center_xz_mm": expected_center_xz,
        "actual_size_xyz_mm": size_xyz,
        "expected_diameter_mm": expected_diameter,
        "expected_depth_mm": expected_depth,
        "boss_od_mm": boss_od,
        "boss_axial_mm": boss_axial,
        "backing_mm": backing,
        "extra_removed_mm3": extra,
        "missing_removed_mm3": missing,
        "pass": passed,
    }
    if not passed:
        die("%s %s insert-bore geometry drifted: %r" % (
            part_name, feature_name, row
        ))
    return row

def cylinder_between(start, end, radius):
    direction = Vector(
        end[0] - start[0], end[1] - start[1], end[2] - start[2]
    )
    return Part.makeCylinder(radius, direction.Length, Vector(*start), direction)

def standing_open_frame(width, depth, height, rail, y0=0.0):
    # The X=max side is intentionally open.  After the -90 degree Y rotation,
    # this removes the otherwise unsupported long terminal bridge while the
    # two full-length X rails still mark the complete configured fit height.
    parts = [
        Part.makeBox(width, depth, rail, Vector(0, y0, 0)),
        Part.makeBox(width, depth, rail, Vector(0, y0, height - rail)),
        Part.makeBox(rail, depth, height - 2.0 * rail, Vector(0, y0, rail)),
    ]
    return parts[0].multiFuse(parts[1:]).removeSplitter()

L = P["case_width_mm"]
H = P["case_height_mm"]
D = P["case_depth_mm"]
WALL = P["wall_mm"]
BACK = P["back_wall_mm"]
LID_T = P["lid_thickness_mm"]
BODY_X = MECH["body_cap_interface_x_mm"]
PANEL_WEB = FIXED["right_panel_web_mm"]
PANEL_FACE_X = MECH["right_panel_face_x_mm"]
LID_W = MECH["lid_width_mm"]
LAND = MECH["gasket"]["land_inset_mm"]
GROOVE_W = MECH["gasket"]["groove_width_mm"]
GROOVE_D = MECH["gasket"]["groove_depth_mm"]
FACE_FLANGE = MECH["face_flange_width_mm"]
MEMBRANE = FIXED["wall_sacrificial_membrane_mm"]
insert_bore_geometry_checks = []

# Main shell: an X-constant U-channel with a flat left build face.  The front
# and right faces remain open during the standing print.
outer = Part.makeBox(BODY_X, D, H)
cavity = Part.makeBox(
    BODY_X - WALL + 2.0,
    D - BACK + 2.0,
    H - 2.0 * WALL,
    Vector(WALL, BACK, WALL),
)
body = outer.cut(cavity).removeSplitter()

# Widen the front top, bottom, and left lands to the OUTSIDE of the complete
# groove band.  A narrow full-height right rail supports the closed cap-seam
# gasket and leaves a measured service throat for the populated backplane.
rail_depth = FIXED["m3_insert_depth_mm"] + 2.0
front_y = D - rail_depth
front_bottom = Part.makeBox(BODY_X, rail_depth, FACE_FLANGE, Vector(0, front_y, 0))
front_top = Part.makeBox(
    BODY_X, rail_depth, FACE_FLANGE, Vector(0, front_y, H - FACE_FLANGE)
)
front_left = Part.makeBox(
    FACE_FLANGE, rail_depth, H - 2.0 * FACE_FLANGE,
    Vector(0, front_y, FACE_FLANGE)
)
front_right = Part.makeBox(
    FIXED["front_right_seal_rail_mm"], rail_depth, H,
    Vector(BODY_X - FIXED["front_right_seal_rail_mm"], front_y, 0),
)
body = body.multiFuse(
    [front_bottom, front_top, front_left, front_right]
).removeSplitter()

# Four axial receiver cones support the removable right cap.  Constant-X
# corner ribs connect every receiver to an existing wall so no receiver begins
# as a late, unsupported island in the V400 standing orientation.
cap_screws = MECH["cap_screw_centers_yz_mm"]
receiver_ribs = []
for cy, cz in cap_screws:
    rib_y0 = 0.0 if cy < D / 2.0 else cy
    rib_y1 = cy if cy < D / 2.0 else D
    receiver_ribs.append(Part.makeBox(
        BODY_X, rib_y1 - rib_y0, 3.0,
        Vector(0, rib_y0, cz - 1.5),
    ))
body = body.multiFuse(receiver_ribs).removeSplitter()

receiver_len = FIXED["cap_receiver_length_mm"]
receivers = []
receiver_pockets = []
pilot_counterbores = []
for cy, cz in cap_screws:
    receiver = Part.makeCone(
        FIXED["cap_receiver_root_radius_mm"],
        FIXED["cap_receiver_radius_mm"],
        receiver_len,
        Vector(BODY_X - receiver_len, cy, cz),
        Vector(1, 0, 0),
    )
    receiver_clip = Part.makeBox(
        receiver_len + 0.2, D, H,
        Vector(BODY_X - receiver_len - 0.1, 0, 0),
    )
    receivers.append(receiver.common(receiver_clip).removeSplitter())
    receiver_pockets.append(Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["cap_m3_insert_total_pocket_depth_mm"] + 0.25,
        Vector(BODY_X - FIXED["cap_m3_insert_total_pocket_depth_mm"], cy, cz),
        Vector(1, 0, 0),
    ))
    pilot_counterbores.append(Part.makeCylinder(
        FIXED["cap_pilot_counterbore_d_mm"] / 2.0,
        FIXED["cap_pilot_counterbore_depth_mm"] + 0.1,
        Vector(BODY_X - FIXED["cap_pilot_counterbore_depth_mm"], cy, cz),
        Vector(1, 0, 0),
    ))
body = body.multiFuse(receivers).removeSplitter()
body = body.cut(
    Part.makeCompound(receiver_pockets + pilot_counterbores)
).removeSplitter()

# Eight body-side lid insert pockets enter from the front.  Two more cap-side
# screws are added below so all four sides of the full-width face seal clamp.
body_lid_screws = [
    [30.0, 4.0], [85.0, 4.0], [140.0, 4.0],
    [30.0, H - 4.0], [85.0, H - 4.0], [140.0, H - 4.0],
    [4.0, 30.0], [4.0, H - 30.0],
]
lid_insert_cuts = [
    hole_y(cx, cz, FIXED["m3_insert_pocket_d_mm"],
           D - FIXED["m3_insert_depth_mm"], FIXED["m3_insert_depth_mm"] + 0.25)
    for cx, cz in body_lid_screws
]
body = body.cut(Part.makeCompound(lid_insert_cuts)).removeSplitter()

# A shallow rear load-path grid ties all four sleeve nodes into the shell walls
# before the passages are cut.  Annular collars spread local bearing load; the
# grid stays behind the removable backplane and is aligned with the standing
# print rather than appearing as isolated late-layer features.
rear_rib_w = FIXED["rear_load_rib_width_mm"]
rear_rib_d = FIXED["rear_load_rib_depth_mm"]
rear_rib_y = BACK - 0.1
sleeve_nodes = MECH["adapter_case_centers_xz_mm"]
rear_load_ribs = []
for z_level in sorted(set(cz for _, cz in sleeve_nodes)):
    rear_load_ribs.append(Part.makeBox(
        BODY_X, rear_rib_d, rear_rib_w,
        Vector(0, rear_rib_y, z_level - rear_rib_w / 2.0),
    ))
for x_level in sorted(set(cx for cx, _ in sleeve_nodes)):
    rear_load_ribs.append(Part.makeBox(
        rear_rib_w, rear_rib_d, H,
        Vector(x_level - rear_rib_w / 2.0, rear_rib_y, 0),
    ))
sleeve_collars = [
    Part.makeCylinder(
        FIXED["sleeve_collar_od_mm"] / 2.0,
        rear_rib_d,
        Vector(cx, rear_rib_y, cz), Vector(0, 1, 0),
    )
    for cx, cz in sleeve_nodes
]
body = body.multiFuse(rear_load_ribs + sleeve_collars).removeSplitter()

# Four oversized rear passages let the metal compression sleeves continue
# through the complete polymer back wall and reinforced collars.  The M4 clamp
# load is metal-to-metal.
adapter_holes = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_holes.append(hole_y(
        cx, cz, FIXED["adapter_body_passage_d_mm"], -0.5,
        BACK + rear_rib_d + 1.0,
    ))
body = body.cut(Part.makeCompound(adapter_holes)).removeSplitter()

# Matching bosses make the single electronics backplane a real screwed
# interface rather than a floating reference.  Inserts open from the front;
# the remaining 1.5 mm root stays joined to the rear wall.
bp_y = MECH["backplane_origin_mm"][1]
backplane_mounts = MECH["backplane_mount_centers_xz_mm"]
backplane_bosses = [
    Part.makeCylinder(
        FIXED["backplane_boss_d_mm"] / 2.0,
        FIXED["backplane_boss_length_mm"] + 0.2,
        Vector(cx, BACK - 0.2, cz), Vector(0, 1, 0),
    )
    for cx, cz in backplane_mounts
]
backplane_boss_gussets = [
    Part.makeBox(
        FIXED["backplane_boss_d_mm"] + 4.0,
        rear_rib_d,
        3.0,
        Vector(
            cx - (FIXED["backplane_boss_d_mm"] + 4.0) / 2.0,
            rear_rib_y,
            cz - FIXED["backplane_boss_d_mm"] / 2.0,
        ),
    )
    for cx, cz in backplane_mounts
]
body = body.multiFuse(backplane_bosses + backplane_boss_gussets).removeSplitter()
backplane_insert_cuts = [
    Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["backplane_insert_depth_mm"] + 0.1,
        Vector(cx, bp_y + 0.1, cz), Vector(0, -1, 0),
    )
    for cx, cz in backplane_mounts
]
body_before_backplane_insert_cuts = body
body = body.cut(Part.makeCompound(backplane_insert_cuts)).removeSplitter()
removed_backplane_insert_bores = body_before_backplane_insert_cuts.cut(
    body
).removeSplitter()
for index, (center, cutter) in enumerate(zip(backplane_mounts, backplane_insert_cuts)):
    insert_bore_geometry_checks.append(audit_blind_insert_bore_y(
        "production_backplane_boss",
        "bore_%d" % (index + 1),
        removed_backplane_insert_bores,
        body_before_backplane_insert_cuts,
        cutter,
        center,
        FIXED["m3_insert_pocket_d_mm"],
        FIXED["backplane_insert_depth_mm"],
        FIXED["backplane_boss_d_mm"],
        FIXED["backplane_boss_length_mm"],
        FIXED["backplane_boss_length_mm"] - FIXED["backplane_insert_depth_mm"],
    ))

# Two broad floor shelves carry the backplane's weight while the four rear M3
# screws retain it against vibration.  The board can still slide straight out
# toward +Y after its screws and pigtails are removed; a bottom-only cantilever
# is deliberately avoided.
bp_z = MECH["backplane_origin_mm"][2]
bp_t = MECH["backplane_size_mm"][1]
floor_shelf_y0 = BACK - 0.1
floor_shelf_depth = bp_y + bp_t - floor_shelf_y0
floor_shelf_z0 = WALL - 0.1
floor_shelves = [
    Part.makeBox(
        20.0,
        floor_shelf_depth,
        bp_z - floor_shelf_z0,
        Vector(cx - 10.0, floor_shelf_y0, floor_shelf_z0),
    )
    for cx in (60.0, 100.0)
]
body = body.multiFuse(floor_shelves).removeSplitter()

# Recessed right cap.  The small pigtail glands replace bulky SP13 panel
# barrels inside this constrained shell.  The open recess drains downward.
cap_web = Part.makeBox(PANEL_WEB, D, H, Vector(BODY_X, 0, 0))
recess_x = PANEL_FACE_X
recess_depth = FIXED["right_recess_depth_mm"]
rim = [
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, 0, 0)),
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, D - WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, H - WALL)),
]
cap = cap_web.multiFuse(rim).removeSplitter()

# Two cap-side face-lid bosses finish the ten-point compression pattern.  They
# are local to the removable cap and do not bridge into the main body.
cap_lid_screws = [
    [L - FIXED["cap_lid_screw_edge_offset_mm"], 30.0],
    [L - FIXED["cap_lid_screw_edge_offset_mm"], H - 30.0],
]
cap_clip = Part.makeBox(L - BODY_X, D, H, Vector(BODY_X, 0, 0))
cap_lid_bosses = [
    Part.makeCylinder(
        5.0, rail_depth,
        Vector(cx, D - rail_depth, cz), Vector(0, 1, 0),
    ).common(cap_clip).removeSplitter()
    for cx, cz in cap_lid_screws
]
cap = cap.multiFuse(cap_lid_bosses).removeSplitter()

# A closed, shallow gasket seat seals the removable cap-to-body seam.  Its
# rear/front and lower/upper legs are supported by the body walls and the
# dedicated front-right rail.  Qualification still requires physical leak and
# thermal-cycle tests; this geometry makes no IP claim.
cap_seal_w = FIXED["cap_seal_width_mm"]
cap_seal_d = FIXED["cap_seal_depth_mm"]
cap_seal_inset = FIXED["cap_seal_inset_mm"]
cap_seal_outer = Part.makeBox(
    cap_seal_d + 0.1,
    D - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.1,
        cap_seal_inset - cap_seal_w / 2.0,
        cap_seal_inset - cap_seal_w / 2.0,
    ),
)
cap_seal_inner = Part.makeBox(
    cap_seal_d + 0.3,
    D - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.2,
        cap_seal_inset + cap_seal_w / 2.0,
        cap_seal_inset + cap_seal_w / 2.0,
    ),
)
cap_seal_groove = cap_seal_outer.cut(cap_seal_inner).removeSplitter()
cap = cap.cut(cap_seal_groove).removeSplitter()

# Annular pilots register the cap with diametral and axial clearance in the
# matching body counterbores.  The old overlapping box tabs are intentionally
# absent.
cap_pilots = []
for cy, cz in cap_screws:
    pilot_outer = Part.makeCylinder(
        FIXED["cap_pilot_od_mm"] / 2.0,
        FIXED["cap_pilot_length_mm"] + 0.1,
        Vector(BODY_X - FIXED["cap_pilot_length_mm"], cy, cz),
        Vector(1, 0, 0),
    )
    pilot_bore = Part.makeCylinder(
        FIXED["cap_screw_clearance_d_mm"] / 2.0,
        FIXED["cap_pilot_length_mm"] + 0.3,
        Vector(BODY_X - FIXED["cap_pilot_length_mm"] - 0.1, cy, cz),
        Vector(1, 0, 0),
    )
    cap_pilots.append(pilot_outer.cut(pilot_bore).removeSplitter())
cap = cap.multiFuse(cap_pilots).removeSplitter()

gland_holes = []
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_holes.append(hole_x(
        cy, cz, gland["cutout_d_mm"], BODY_X - 0.5,
        PANEL_WEB + 0.5 - MEMBRANE,
    ))
cap_holes = [
    hole_x(cy, cz, FIXED["cap_screw_clearance_d_mm"],
           BODY_X - FIXED["cap_pilot_length_mm"] - 0.2,
           PANEL_WEB + FIXED["cap_pilot_length_mm"] + 0.4)
    for cy, cz in cap_screws
]
cap_lid_insert_cuts = [
    hole_y(
        cx, cz, FIXED["m3_insert_pocket_d_mm"],
        D - FIXED["m3_insert_depth_mm"], FIXED["m3_insert_depth_mm"] + 0.25,
    )
    for cx, cz in cap_lid_screws
]
cap_before_penetrations = cap
cap = cap.cut(
    Part.makeCompound(gland_holes + cap_holes + cap_lid_insert_cuts)
).removeSplitter()

# Prove that each requested right-side penetration was materially cut at its
# own Y/Z center.  The intended cutter intentionally stops 0.45 mm short of
# the outside face so the printable cap retains a sacrificial membrane.
gland_feature_geometry_checks = []
for gland, cutter in zip(IO["pigtail_glands"], gland_holes):
    cutter_box = cutter.BoundBox
    margin = 0.8
    window = Part.makeBox(
        PANEL_WEB + 2.0,
        cutter_box.YLength + 2.0 * margin,
        cutter_box.ZLength + 2.0 * margin,
        Vector(
            BODY_X - 1.0,
            cutter_box.YMin - margin,
            cutter_box.ZMin - margin,
        ),
    )
    actual = cap_before_penetrations.cut(cap).common(window).removeSplitter()
    expected = cap_before_penetrations.common(cutter).common(window).removeSplitter()
    extra = actual.cut(expected).Volume
    missing = expected.cut(actual).Volume
    actual_box = actual.BoundBox
    expected_box = expected.BoundBox
    actual_center = [
        (actual_box.YMin + actual_box.YMax) / 2.0,
        (actual_box.ZMin + actual_box.ZMax) / 2.0,
    ]
    expected_center = [
        (expected_box.YMin + expected_box.YMax) / 2.0,
        (expected_box.ZMin + expected_box.ZMax) / 2.0,
    ]
    actual_size = [actual_box.YLength, actual_box.ZLength]
    expected_size = [expected_box.YLength, expected_box.ZLength]
    passed = (
        not actual.isNull()
        and not expected.isNull()
        and extra <= 0.0001
        and missing <= 0.0001
        and max(
            abs(actual_center[index] - expected_center[index])
            for index in range(2)
        ) <= 0.001
        and max(
            abs(actual_size[index] - expected_size[index])
            for index in range(2)
        ) <= 0.001
    )
    row = {
        "id": gland["id"],
        "actual_center_yz_mm": actual_center,
        "expected_center_yz_mm": expected_center,
        "actual_size_yz_mm": actual_size,
        "expected_size_yz_mm": expected_size,
        "extra_removed_mm3": extra,
        "missing_removed_mm3": missing,
        "membrane_mm": MEMBRANE,
        "pass": passed,
    }
    gland_feature_geometry_checks.append(row)
    if not passed:
        die("right-cap gland penetration geometry drifted for %s" % gland["id"])
# Corner scallops preserve an Ø11 mm driver path to the four cap screws.  They
# affect only the drained outer eyebrow/rims; the closed seam gasket remains on
# the protected body-facing web.
driver_reliefs = [
    Part.makeCylinder(
        FIXED["cap_driver_keepout_d_mm"] / 2.0 + 0.2,
        recess_depth + 0.2,
        Vector(PANEL_FACE_X - 0.1, cy, cz), Vector(1, 0, 0),
    )
    for cy, cz in cap_screws
]
cap = cap.cut(Part.makeCompound(driver_reliefs)).removeSplitter()
drain_slot = Part.makeBox(
    recess_depth + 1.0, 12.0, WALL + 1.0,
    Vector(recess_x - 0.5, D - 18.0, -0.5),
)
cap = cap.cut(drain_slot).removeSplitter()

# Front service lid.  Its installed position is in front of the body.  The
# compact face gland uses a square-bottom groove and 25 percent target squeeze.
lid_blank = Part.makeBox(LID_W, LID_T, H, Vector(0, D, 0))
lid_installed = lid_blank.copy()
groove_outer = Part.makeBox(
    LID_W - 2.0 * LAND, GROOVE_D + 0.1, H - 2.0 * LAND,
    Vector(LAND, D - 0.1, LAND),
)
groove_inner = Part.makeBox(
    LID_W - 2.0 * (LAND + GROOVE_W),
    GROOVE_D + 0.3,
    H - 2.0 * (LAND + GROOVE_W),
    Vector(LAND + GROOVE_W, D - 0.2, LAND + GROOVE_W),
)
groove = groove_outer.cut(groove_inner).removeSplitter()
groove_plan_area = (
    (LID_W - 2.0 * LAND) * (H - 2.0 * LAND)
    - (LID_W - 2.0 * (LAND + GROOVE_W))
    * (H - 2.0 * (LAND + GROOVE_W))
)
actual_front_groove_depth = lid_blank.common(groove).Volume / groove_plan_area
if abs(actual_front_groove_depth - GROOVE_D) > 0.01:
    die("front gasket groove actual depth differs from its declaration")
lid_installed = lid_installed.cut(groove).removeSplitter()
lid_screws = body_lid_screws + cap_lid_screws
lid_clearance_holes = [
    hole_y(cx, cz, FIXED["cap_screw_clearance_d_mm"], D - 0.5, LID_T + 1.0)
    for cx, cz in lid_screws
]
lid_installed = lid_installed.cut(
    Part.makeCompound(lid_clearance_holes)
).removeSplitter()

# Recess the owner signature and repository QR into the lid's exterior face.
# The four-module quiet field remains unmarked; only black QR modules are cut.
# This exterior face is bed-facing in the production transform, so the paired
# QR process coupon is a mandatory first print rather than a decorative extra.
branding_geometry_checks = []
lid_brand = BRANDING["lid"]
lid_qr_cutter, lid_qr_expected, lid_qr_runs = qr_recess_y(
    QR_MATRIX,
    lid_brand["qr_quiet_origin_xz_mm"],
    lid_brand["qr_module_mm"],
    BRANDING["qr_quiet_zone_modules"],
    D + LID_T,
    lid_brand["recess_depth_mm"],
    -1,
    False,
)
lid_installed, row = apply_recess(
    "lid_repository_qr", lid_installed, lid_qr_cutter, lid_qr_expected
)
row["cutter_run_count"] = lid_qr_runs
branding_geometry_checks.append(row)
lid_text_cutter, lid_text_expected, lid_text_runs = text_recess_y(
    BRANDING["signature"],
    lid_brand["signature_origin_xz_mm"],
    lid_brand["signature_cell_mm"],
    D + LID_T,
    lid_brand["recess_depth_mm"],
    -1,
    False,
)
lid_installed, row = apply_recess(
    "lid_owner_signature", lid_installed, lid_text_cutter, lid_text_expected
)
row["cutter_run_count"] = lid_text_runs
branding_geometry_checks.append(row)

# One removable vertical backplane.  Four accessible low-profile M3 heads sit at
# laterally spread carrier corners, outside the inter-board wire aisle, and match
# the four reinforced shell insert bosses.  The
# photographed ESP32-S3 UNO is assigned the user-directed standard Arduino UNO
# asymmetric four-round-hole reference geometry with commercial M2.5
# standoffs; the physical clone board still has to pass its coupon. No guessed
# printed PCB posts are fused to this plate. Cable-tie slots flank the reserved
# wire route.
bp = MECH["backplane_origin_mm"]
bs = MECH["backplane_size_mm"]
backplane_installed = Part.makeBox(bs[0], bs[1], bs[2], Vector(*bp))
backplane_mount_pads = [
    Part.makeCylinder(
        FIXED["backplane_mount_pad_d_mm"] / 2.0,
        FIXED["backplane_mount_pad_extra_mm"] + 0.1,
        Vector(cx, bp[1] + bs[1] - 0.1, cz), Vector(0, 1, 0),
    )
    for cx, cz in backplane_mounts
]
backplane_installed = backplane_installed.multiFuse(
    backplane_mount_pads
).removeSplitter()

esp = LAYOUT["owner_esp32_s3_uno_candidate"]["origin_mm"]
controller_mounts = [
    [esp[0] + local_x, esp[2] + local_z]
    for local_x, local_z in [[2.54, 45.72], [2.54, 17.78], [54.61, 50.8], [53.34, 2.54]]
]
interface_origin = LAYOUT["interface_pcb_reserved"]["origin_mm"]
interface_mounts = [
    [interface_origin[0] + local_x, interface_origin[2] + local_z]
    for local_x, local_z in INTERFACE_HOLES
]
bp_cuts = [
    hole_y(
        cx, cz, FIXED["backplane_screw_clearance_d_mm"],
        bp[1] - 0.2,
        bs[1] + FIXED["backplane_mount_pad_extra_mm"] + 0.5,
    )
    for cx, cz in backplane_mounts
]
controller_mount_cutters = [
    hole_y(
        cx, cz, FIXED["board_m25_screw_clearance_d_mm"],
        bp[1] - 0.2, bs[1] + 0.4,
    )
    for cx, cz in controller_mounts
]
bp_cuts.extend(controller_mount_cutters)
for cx, cz in interface_mounts:
    bp_cuts.append(hole_y(
        cx, cz, FIXED["board_m25_screw_clearance_d_mm"],
        bp[1] - 0.2, bs[1] + 0.4,
    ))
for cx, cz in MECH["backplane_cable_tie_slot_centers_xz_mm"]:
    bp_cuts.append(Part.makeBox(
        FIXED["cable_tie_slot_width_mm"], bs[1] + 0.4,
        FIXED["cable_tie_slot_height_mm"],
        Vector(
            cx - FIXED["cable_tie_slot_width_mm"] / 2.0,
            bp[1] - 0.2,
            cz - FIXED["cable_tie_slot_height_mm"] / 2.0,
        ),
    ))
backplane_before_cuts = backplane_installed
backplane_installed = backplane_installed.cut(
    Part.makeCompound(bp_cuts)
).removeSplitter()
pcb_mount_feature_geometry_checks = [
    audit_round_cut_y(
        "electronics_backplane",
        "arduino_uno_hole_%d" % (index + 1),
        backplane_before_cuts,
        backplane_installed,
        cutter,
        center,
        FIXED["board_m25_screw_clearance_d_mm"],
    )
    for index, (center, cutter) in enumerate(zip(
        controller_mounts, controller_mount_cutters
    ))
]

# The signed repository mark lives on the backplane's global-coordinate rear
# service face.  Mirroring the cells in X makes the matrix and text readable
# when that -Y face is viewed from outside the plate.
backplane_brand = BRANDING["backplane"]
backplane_qr_cutter, backplane_qr_expected, backplane_qr_runs = qr_recess_y(
    QR_MATRIX,
    backplane_brand["qr_quiet_origin_xz_mm"],
    backplane_brand["qr_module_mm"],
    BRANDING["qr_quiet_zone_modules"],
    bp[1],
    backplane_brand["recess_depth_mm"],
    1,
    True,
)
backplane_installed, row = apply_recess(
    "backplane_repository_qr",
    backplane_installed,
    backplane_qr_cutter,
    backplane_qr_expected,
)
row["cutter_run_count"] = backplane_qr_runs
branding_geometry_checks.append(row)
backplane_text_cutter, backplane_text_expected, backplane_text_runs = text_recess_y(
    BRANDING["signature"],
    backplane_brand["signature_origin_xz_mm"],
    backplane_brand["signature_cell_mm"],
    bp[1],
    backplane_brand["recess_depth_mm"],
    1,
    True,
)
backplane_installed, row = apply_recess(
    "backplane_owner_signature",
    backplane_installed,
    backplane_text_cutter,
    backplane_text_expected,
)
row["cutter_run_count"] = backplane_text_runs
branding_geometry_checks.append(row)

# Reference hardware for both PCB mounts.  Through-tapped 8 mm female-female
# M2.5 standoffs sit between carrier and PCB.  Washers are above each PCB, under
# the front heads.  All sixteen screw shanks are explicit so the opposed-tip
# clearance is modeled rather than inferred from head-only geometry.
m25_head_r = FASTENERS["controller"]["head_d_mm"] / 2.0
m25_head_h = FASTENERS["controller"]["head_h_mm"]
m25_shank_r = FASTENERS["controller"]["thread_d_mm"] / 2.0
m25_screw_length = FASTENERS["controller"]["length_under_head_mm"]

def make_board_hardware(mounts, board_y, pcb_thickness):
    standoffs = [
        Part.makeCylinder(
            FIXED["board_m25_standoff_od_mm"] / 2.0,
            FIXED["board_m25_standoff_length_mm"],
            Vector(cx, bp[1] + bs[1], cz), Vector(0, 1, 0),
        )
        for cx, cz in mounts
    ]
    rear_heads = [
        Part.makeCylinder(
            m25_head_r, m25_head_h,
            Vector(cx, bp[1] - m25_head_h, cz), Vector(0, 1, 0),
        )
        for cx, cz in mounts
    ]
    rear_shanks = [
        Part.makeCylinder(
            m25_shank_r, m25_screw_length,
            Vector(cx, bp[1], cz), Vector(0, 1, 0),
        )
        for cx, cz in mounts
    ]
    washers = [
        Part.makeCylinder(
            FIXED["board_m25_washer_od_mm"] / 2.0,
            FIXED["board_m25_washer_thickness_mm"],
            Vector(cx, board_y + pcb_thickness, cz), Vector(0, 1, 0),
        )
        for cx, cz in mounts
    ]
    front_heads = [
        Part.makeCylinder(
            m25_head_r, m25_head_h,
            Vector(
                cx,
                board_y + pcb_thickness
                + FIXED["board_m25_washer_thickness_mm"],
                cz,
            ),
            Vector(0, 1, 0),
        )
        for cx, cz in mounts
    ]
    front_shanks = [
        Part.makeCylinder(
            m25_shank_r, m25_screw_length,
            Vector(
                cx,
                board_y + pcb_thickness
                + FIXED["board_m25_washer_thickness_mm"],
                cz,
            ),
            Vector(0, -1, 0),
        )
        for cx, cz in mounts
    ]
    compound = Part.makeCompound(
        standoffs + rear_heads + rear_shanks
        + washers + front_heads + front_shanks
    )
    return {
        "compound": compound,
        "standoffs": standoffs,
        "rear_heads": rear_heads,
        "rear_shanks": rear_shanks,
        "washers": washers,
        "front_heads": front_heads,
        "front_shanks": front_shanks,
    }

controller_hardware = make_board_hardware(
    controller_mounts, esp[1], FIXED["controller_candidate_pcb_thickness_mm"]
)
interface_hardware = make_board_hardware(
    interface_mounts, interface_origin[1], FIXED["interface_pcb_thickness_mm"]
)
controller_mount_hardware = controller_hardware["compound"]
interface_mount_hardware = interface_hardware["compound"]

# Model the largest local hardware diameter at each of the four fixed UNO axes.
hardware_envelope_d = max(
    FIXED["board_m25_standoff_od_mm"],
    FIXED["board_m25_washer_od_mm"],
    FIXED["board_m25_hardware_max_corner_d_mm"],
    FASTENERS["controller"]["head_d_mm"],
)
hardware_y0 = bp[1] - m25_head_h
hardware_y1 = (
    esp[1] + FIXED["controller_candidate_pcb_thickness_mm"]
    + FIXED["board_m25_washer_thickness_mm"] + m25_head_h
)
controller_hardware_envelopes = []
for cx, cz in controller_mounts:
    envelope = hole_y(
        cx, cz, hardware_envelope_d, hardware_y0, hardware_y1 - hardware_y0
    )
    controller_hardware_envelopes.append(envelope)
controller_mount_fixed_hole_envelopes = Part.makeCompound(controller_hardware_envelopes)

# Component, inter-board wiring, driver, and gland reference envelopes.
component_shapes = {}
for name, item in LAYOUT.items():
    component_shapes[name] = Part.makeBox(
        item["size_mm"][0], item["size_mm"][1], item["size_mm"][2],
        Vector(*item["origin_mm"]),
    )
wire_service_keepout = Part.makeBox(
    WIRE_SERVICE["size_mm"][0],
    WIRE_SERVICE["size_mm"][1],
    WIRE_SERVICE["size_mm"][2],
    Vector(*WIRE_SERVICE["origin_mm"]),
)
face_plenum_spec = WIRE_SERVICE["board_face_plenum"]
board_face_wiring_plenum = Part.makeBox(
    face_plenum_spec["size_mm"][0],
    face_plenum_spec["size_mm"][1],
    face_plenum_spec["size_mm"][2],
    Vector(*face_plenum_spec["origin_mm"]),
)
bend_spec = WIRE_SERVICE["bend_sweep"]
bend_center = Vector(*bend_spec["center_mm"])
bend_r = bend_spec["centerline_radius_mm"]
bundle_r = bend_spec["bundle_radius_mm"]
wire_torus = Part.makeTorus(
    bend_r, bundle_r, bend_center, Vector(0, 1, 0)
)
torus_clip = Part.makeBox(
    2.0 * (bend_r + bundle_r) + 2.0,
    2.0 * bundle_r + 2.0,
    bend_r + bundle_r + 1.0,
    Vector(
        bend_center.x - bend_r - bundle_r - 1.0,
        bend_center.y - bundle_r - 1.0,
        bend_center.z,
    ),
)
wire_half_torus = wire_torus.common(torus_clip).removeSplitter()
wire_connector_stubs = []
for index, (endpoint_x, endpoint_z) in enumerate(
    bend_spec["endpoint_centers_xz_mm"]
):
    component_name = (
        "owner_esp32_s3_uno_candidate" if index == 0
        else "interface_pcb_reserved"
    )
    component = LAYOUT[component_name]
    component_front = component["origin_mm"][1] + component["size_mm"][1]
    wire_connector_stubs.append(Part.makeCylinder(
        bundle_r,
        bend_center.y - component_front,
        Vector(endpoint_x, component_front, endpoint_z),
        Vector(0, 1, 0),
    ))
wire_bend_sweep = Part.makeCompound([wire_half_torus] + wire_connector_stubs)

# Two illustrative small-tie envelopes include front/rear straps, through-slot
# legs, and a low-profile head.  They reserve hardware volume only.  Their
# current Y position does not capture the front-face loop, so they must not be
# treated as a qualified retention path.
tie_keepouts = []
tie_slots = MECH["backplane_cable_tie_slot_centers_xz_mm"]
for row in range(2):
    left_slot = tie_slots[row * 2]
    right_slot = tie_slots[row * 2 + 1]
    zc = left_slot[1]
    strap_x0 = left_slot[0] - FIXED["cable_tie_strap_width_mm"] / 2.0
    strap_x1 = right_slot[0] + FIXED["cable_tie_strap_width_mm"] / 2.0
    strap_span = strap_x1 - strap_x0
    rear_strap = Part.makeBox(
        strap_span,
        FIXED["cable_tie_strap_thickness_mm"],
        FIXED["cable_tie_strap_width_mm"],
        Vector(
            strap_x0,
            bp[1] - FIXED["cable_tie_strap_thickness_mm"],
            zc - FIXED["cable_tie_strap_width_mm"] / 2.0,
        ),
    )
    front_strap = Part.makeBox(
        strap_span,
        FIXED["cable_tie_head_y_mm"],
        FIXED["cable_tie_strap_width_mm"],
        Vector(
            strap_x0,
            bp[1] + bs[1],
            zc - FIXED["cable_tie_strap_width_mm"] / 2.0,
        ),
    )
    legs = [
        Part.makeBox(
            FIXED["cable_tie_strap_width_mm"],
            bs[1] + FIXED["cable_tie_head_y_mm"]
            + FIXED["cable_tie_strap_thickness_mm"],
            FIXED["cable_tie_strap_width_mm"],
            Vector(
                slot[0] - FIXED["cable_tie_strap_width_mm"] / 2.0,
                bp[1] - FIXED["cable_tie_strap_thickness_mm"],
                zc - FIXED["cable_tie_strap_width_mm"] / 2.0,
            ),
        )
        for slot in (left_slot, right_slot)
    ]
    tie_head = Part.makeBox(
        FIXED["cable_tie_head_x_mm"],
        FIXED["cable_tie_head_y_mm"],
        FIXED["cable_tie_head_z_mm"],
        Vector(
            (left_slot[0] + right_slot[0]) / 2.0
            - FIXED["cable_tie_head_x_mm"] / 2.0,
            bp[1] + bs[1] + FIXED["cable_tie_head_y_mm"],
            zc - FIXED["cable_tie_head_z_mm"] / 2.0,
        ),
    )
    tie_keepouts.append(Part.makeCompound(
        [rear_strap, front_strap, tie_head] + legs
    ))
interboard_tie_keepouts = Part.makeCompound(tie_keepouts)
backplane_driver_keepouts = [
    Part.makeCylinder(
        FIXED["backplane_driver_keepout_d_mm"] / 2.0,
        25.0,
        Vector(cx, bp[1] + bs[1], cz), Vector(0, 1, 0),
    )
    for cx, cz in backplane_mounts
]
gland_keepouts = {}
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_keepouts[gland["id"]] = Part.makeCylinder(
        FIXED["gland_keepout_d_mm"] / 2.0,
        FIXED["gland_keepout_length_mm"],
        Vector(BODY_X - FIXED["gland_keepout_length_mm"], cy, cz),
        Vector(1, 0, 0),
    )

# External nut and driver cylinders verify that the recessed cap remains
# wrenchable without clipping its eyebrow/rims.
external_gland_keepouts = {}
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    external_gland_keepouts[gland["id"]] = Part.makeCylinder(
        FIXED["gland_keepout_d_mm"] / 2.0,
        FIXED["right_recess_depth_mm"],
        Vector(PANEL_FACE_X, cy, cz), Vector(1, 0, 0),
    )
cap_driver_keepouts = {}
for index, (cy, cz) in enumerate(cap_screws, start=1):
    cap_driver_keepouts["CAP_%d" % index] = Part.makeCylinder(
        FIXED["cap_driver_keepout_d_mm"] / 2.0,
        FIXED["right_recess_depth_mm"],
        Vector(PANEL_FACE_X, cy, cz), Vector(1, 0, 0),
    )

# Thin contact probes are analytic audit geometry, not exported seals.  The
# face probe must be supported by body+cap; the cap probe must be supported by
# the body rear/top/bottom/front-right rails.
face_probe_outer = Part.makeBox(
    LID_W - 2.0 * LAND, 0.1, H - 2.0 * LAND,
    Vector(LAND, D - 0.1, LAND),
)
face_probe_inner = Part.makeBox(
    LID_W - 2.0 * FACE_FLANGE, 0.2, H - 2.0 * FACE_FLANGE,
    Vector(FACE_FLANGE, D - 0.15, FACE_FLANGE),
)
face_seal_probe = face_probe_outer.cut(face_probe_inner).removeSplitter()
cap_probe_outer = Part.makeBox(
    0.1,
    D - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.1,
        cap_seal_inset - cap_seal_w / 2.0,
        cap_seal_inset - cap_seal_w / 2.0,
    ),
)
cap_probe_inner = Part.makeBox(
    0.2,
    D - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.15,
        cap_seal_inset + cap_seal_w / 2.0,
        cap_seal_inset + cap_seal_w / 2.0,
    ),
)
cap_seal_probe = cap_probe_outer.cut(cap_probe_inner).removeSplitter()

# Unreleased load-path concept with a planar vehicle-facing T plate. The broad
# lower plane carries the four case sleeves while a narrow V1-style upper flange
# reaches only to the bolt-head silhouette. Engine-side formed-return references
# are added below; production bend geometry, material, land fit, and lower
# reaction still require direct measurement. The printable template is never a
# load path.
adapter_t = FIXED["adapter_plate_thickness_mm"]
adapter_y = -P["adapter_gap_mm"] - adapter_t
adapter_tab_x0, adapter_tab_x1 = MECH["adapter_crossbar_x_mm"]
adapter_tab_z0 = H - FIXED["adapter_tab_overlap_mm"]
adapter_lower = Part.makeBox(L, adapter_t, H, Vector(0, adapter_y, 0))
adapter_tab = Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    adapter_t,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, adapter_y, adapter_tab_z0),
)
adapter_blank = adapter_lower.fuse(adapter_tab).removeSplitter()
mounts = MECH["mount_centers_xz_mm"]
adapter_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"],
           adapter_y - 0.5, adapter_t + 1.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_cutters.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"],
        adapter_y - 0.5, adapter_t + 1.0,
    ))
adapter_plate = adapter_blank.cut(Part.makeCompound(adapter_cutters)).removeSplitter()
# The firewall-facing sheet remains planar.  Three formed returns project only
# toward the enclosure, inside the measured spacer gap, turning the broad lower
# plate into a shallow channel without adding height above the bolt-head datum.
# This is still an unreleased stiffness/clearance reference: bend radius,
# material, tooling, and stamped-panel contact all remain measurement gates.
adapter_return_depth = MECH["adapter_return_depth_mm"]
adapter_return_y = adapter_y + adapter_t
adapter_return_flanges = [
    Part.makeBox(
        adapter_t, adapter_return_depth, H,
        Vector(0, adapter_return_y, 0),
    ),
    Part.makeBox(
        adapter_t, adapter_return_depth, H,
        Vector(L - adapter_t, adapter_return_y, 0),
    ),
    Part.makeBox(
        L, adapter_return_depth, adapter_t,
        Vector(0, adapter_return_y, 0),
    ),
]
adapter_structure = adapter_plate.multiFuse(
    adapter_return_flanges
).removeSplitter()
spacers = []
adapter_head_keepouts = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    sleeve_length = (
        P["adapter_gap_mm"] + BACK + FIXED["adapter_sleeve_proud_mm"]
    )
    sleeve = Part.makeCylinder(
        FIXED["adapter_spacer_d_mm"] / 2.0,
        sleeve_length,
        Vector(cx, -P["adapter_gap_mm"], cz),
        Vector(0, 1, 0),
    )
    bore = Part.makeCylinder(
        FIXED["adapter_case_hole_d_mm"] / 2.0,
        sleeve_length + 0.2,
        Vector(cx, -P["adapter_gap_mm"] - 0.1, cz),
        Vector(0, 1, 0),
    )
    spacers.append(sleeve.cut(bore).removeSplitter())
    adapter_head_keepouts.append(Part.makeCylinder(
        4.0, FIXED["lid_head_allowance_mm"],
        Vector(cx, BACK + FIXED["adapter_sleeve_proud_mm"], cz),
        Vector(0, 1, 0),
    ))
adapter_reference = Part.makeCompound([adapter_structure] + spacers)

# Measurement-gated reference geometry.  These are inspection STEP shapes, not
# print parts.  Bolt heads use a conservative envelope.  The thin hood datum is
# confined to the bolt plane because the hood slope across case depth remains
# unknown; the lower plane provisionally interprets the reported span from the
# bolt axis because its actual endpoints remain unresolved.
vehicle_bolt_head_keepouts = [
    Part.makeCylinder(
        FIXED["vehicle_head_envelope_d_mm"] / 2.0,
        min(P["adapter_gap_mm"], 8.0),
        Vector(mx, adapter_y + adapter_t, mz), Vector(0, 1, 0),
    )
    for mx, mz in mounts
]
bolt_head_reference = Part.makeCompound(vehicle_bolt_head_keepouts)
bolt_plane_hood_datum = Part.makeBox(
    L,
    adapter_t,
    3.0,
    Vector(0, adapter_y, MECH["bolt_plane_hood_datum_z_mm"]),
)
lower_obstruction_keepout = Part.makeBox(
    L,
    MECH["fit_cage_envelope_mm"][1],
    3.0,
    Vector(0, adapter_y, MECH["lower_obstruction_z_mm"] - 3.0),
)

# Flat printed drill template uses the exact adapter holes, but is explicitly
# too thin and too creep-prone to become a vehicle bracket.
adapter_template_blank = Part.makeBox(L, 3.0, H)
adapter_template_blank = adapter_template_blank.fuse(Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    3.0,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, 0, adapter_tab_z0),
)).removeSplitter()
template_cuts = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    template_cuts.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"], -0.5, 4.0
    ))
adapter_template = adapter_template_blank.cut(
    Part.makeCompound(template_cuts)
).removeSplitter()

# Low-material installed-envelope cage.  Its default depth includes the
# adapter-back-to-lid package span, low-profile lid heads, and an extra fit margin.
cage_depth = MECH["fit_cage_envelope_mm"][1]
rail = FIXED["fit_cage_rail_mm"]
rear_frame = standing_open_frame(L, 3.0, H, rail, 0.0)
front_frame = standing_open_frame(L, 3.0, H, rail, cage_depth - 3.0)
long_rails = [
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, 0)),
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, H - rail)),
]
cage_brace_r = FIXED["fit_cage_brace_d_mm"] / 2.0
cage_x0 = rail / 2.0
cage_x1 = L - rail / 2.0
cage_y0 = 1.5
cage_y1 = cage_depth - 1.5
cage_braces = [
    cylinder_between(
        [cage_x0, cage_y0, rail / 2.0],
        [cage_x1, cage_y1, rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y1, rail / 2.0],
        [cage_x1, cage_y0, rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y0, H - rail / 2.0],
        [cage_x1, cage_y1, H - rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y1, H - rail / 2.0],
        [cage_x1, cage_y0, H - rail / 2.0],
        cage_brace_r,
    ),
]
crossbar = Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    3.0,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, 0, adapter_tab_z0),
)
fit_cage_blank = rear_frame.multiFuse(
    [front_frame, crossbar] + long_rails + cage_braces
).removeSplitter()
fit_cage = fit_cage_blank.cut(Part.makeCompound([
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
])).removeSplitter()
cage_terminal_probe = Part.makeBox(
    1.0,
    cage_depth - 2.0 * rail,
    H - 2.0 * rail,
    Vector(L - 0.5, rail, rail),
)
cage_terminal_overlap = fit_cage.common(cage_terminal_probe).Volume
if cage_terminal_overlap > 0.01:
    die("fit cage terminal opening is obstructed")

# Compact bolt coupon with the same round + horizontal-slot datum.
coupon_w = 90.0
coupon_h = 32.0
coupon_center = coupon_w / 2.0
coupon_left_x = coupon_center - P["mount_hole_spacing_mm"] / 2.0
coupon_right_x = coupon_center + P["mount_hole_spacing_mm"] / 2.0
bolt_coupon_blank = Part.makeBox(coupon_w, 4.0, coupon_h)
bolt_coupon = bolt_coupon_blank.cut(Part.makeCompound([
    hole_y(coupon_left_x, coupon_h / 2.0, P["mount_hole_d_mm"], -0.5, 5.0),
    capsule_y(coupon_right_x, coupon_h / 2.0, P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 5.0),
])).removeSplitter()

# Materially inspect the mount cuts after each Boolean operation.  Comparing
# the actual material removed from the blank against the intended cutter catches
# a missing, shifted, undersized, or oversized round/slot cut instead of merely
# echoing the requested parameters into the result report.
mount_feature_geometry_checks = []
def check_mount_feature(part_name, feature_name, blank, cut_part, cutter):
    cutter_box = cutter.BoundBox
    blank_box = blank.BoundBox
    margin = 1.0
    window = Part.makeBox(
        cutter_box.XLength + 2.0 * margin,
        blank_box.YLength + 2.0,
        cutter_box.ZLength + 2.0 * margin,
        Vector(
            cutter_box.XMin - margin,
            blank_box.YMin - 1.0,
            cutter_box.ZMin - margin,
        ),
    )
    actual = blank.cut(cut_part).common(window).removeSplitter()
    expected = blank.common(cutter).common(window).removeSplitter()
    extra = actual.cut(expected).Volume
    missing = expected.cut(actual).Volume
    actual_box = actual.BoundBox
    expected_box = expected.BoundBox
    actual_center = [
        (actual_box.XMin + actual_box.XMax) / 2.0,
        (actual_box.ZMin + actual_box.ZMax) / 2.0,
    ]
    expected_center = [
        (expected_box.XMin + expected_box.XMax) / 2.0,
        (expected_box.ZMin + expected_box.ZMax) / 2.0,
    ]
    actual_size = [actual_box.XLength, actual_box.ZLength]
    expected_size = [expected_box.XLength, expected_box.ZLength]
    max_center_error = max(
        abs(actual_center[index] - expected_center[index]) for index in range(2)
    )
    max_size_error = max(
        abs(actual_size[index] - expected_size[index]) for index in range(2)
    )
    passed = (
        not actual.isNull()
        and not expected.isNull()
        and extra <= 0.0001
        and missing <= 0.0001
        and max_center_error <= 0.001
        and max_size_error <= 0.001
    )
    row = {
        "part": part_name,
        "feature": feature_name,
        "actual_center_xz_mm": actual_center,
        "expected_center_xz_mm": expected_center,
        "actual_size_xz_mm": actual_size,
        "expected_size_xz_mm": expected_size,
        "extra_removed_mm3": extra,
        "missing_removed_mm3": missing,
        "pass": passed,
    }
    mount_feature_geometry_checks.append(row)
    if not passed:
        die("%s %s mount-cut geometry drifted" % (part_name, feature_name))

installed_mount_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"], P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
]
template_mount_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"], P["mount_hole_d_mm"], -0.5, 4.0),
]
coupon_mount_cutters = [
    hole_y(coupon_left_x, coupon_h / 2.0, P["mount_hole_d_mm"], -0.5, 5.0),
    capsule_y(coupon_right_x, coupon_h / 2.0, P["mount_slot_length_mm"], P["mount_hole_d_mm"], -0.5, 5.0),
]
for part_name, blank, cut_part, cutters in (
    ("metal_adapter_concept", adapter_blank, adapter_plate, installed_mount_cutters),
    ("adapter_drill_template", adapter_template_blank, adapter_template, template_mount_cutters),
    ("slot_clearance_cage", fit_cage_blank, fit_cage, template_mount_cutters),
    ("vehicle_bolt_coupon", bolt_coupon_blank, bolt_coupon, coupon_mount_cutters),
):
    check_mount_feature(part_name, "round", blank, cut_part, cutters[0])
    check_mount_feature(part_name, "horizontal_slot", blank, cut_part, cutters[1])

# 45/55/65 mm comb for measuring depth at several points on the stamped
# firewall.  The connected heel keeps it one printable solid.
depth_comb = Part.makeBox(32.0, 5.0, 5.0)
for index, length in enumerate((45.0, 55.0, 65.0)):
    depth_comb = depth_comb.fuse(
        Part.makeBox(6.0, length, 6.0, Vector(2.0 + index * 11.0, 0, 0))
    )
depth_comb = depth_comb.removeSplitter()

# A 5 mm datum heel plus 60 mm exposed arm makes the right-side pigtail and
# inline-connector service zone measurable during the static fit test.
io_witness_overall = (
    FIXED["io_witness_datum_heel_mm"] + FIXED["external_pigtail_service_mm"]
)
io_witness = Part.makeBox(io_witness_overall, 8.0, 8.0)
io_witness = io_witness.fuse(
    Part.makeBox(FIXED["io_witness_datum_heel_mm"], 24.0, 8.0, Vector(0, 0, 0))
).removeSplitter()

# Conservative full-height support-process coupon for both standing parts.  Its
# 12 mm-deep, 3.2 mm-thick roof spans the body's larger terminal-rail opening
# at the same height, qualifying both the support column and interface.  The
# shorter cap rim is bounded by the same settings.
bridge_span = MECH["standing_bridge_coupon_span_mm"]
bridge_pier = 5.0
bridge_depth = 12.0
bridge_height = MECH["standing_bridge_coupon_support_height_mm"]
bridge_coupon_width = bridge_span + 2.0 * bridge_pier
bridge_coupon = Part.makeBox(bridge_coupon_width, bridge_depth, 3.0)
bridge_coupon = bridge_coupon.multiFuse([
    Part.makeBox(bridge_pier, bridge_depth, bridge_height),
    Part.makeBox(
        bridge_pier, bridge_depth, bridge_height,
        Vector(bridge_pier + bridge_span, 0, 0),
    ),
    Part.makeBox(
        bridge_coupon_width, bridge_depth, FIXED["front_right_seal_rail_mm"],
        Vector(0, 0, bridge_height),
    ),
]).removeSplitter()

# Exact web-thickness coupons for purchased gland measurement and for the
# standing shell's horizontal-hole membrane process.
gland_coupon = Part.makeBox(72.0, PANEL_WEB, 30.0)
coupon_features = []
for index, delta in enumerate((0.0, 0.2, 0.4)):
    cx = 14.0 + 22.0 * index
    diameter = P["pigtail_gland_d_mm"] + delta
    gland_coupon = gland_coupon.cut(hole_y(
        cx, 15.0, diameter, -0.5, PANEL_WEB + 1.0
    ))
    coupon_features.append({"x_mm": cx, "diameter_mm": diameter})
wall_coupon = Part.makeBox(30.0, 12.0, 28.0)
wall_hole = hole_y(
    15.0, 14.0, P["pigtail_gland_d_mm"],
    MEMBRANE, 12.0 - MEMBRANE + 1.0,
)
wall_coupon = wall_coupon.cut(wall_hole).removeSplitter()

# Board-pattern coupons use the exact user-directed standard reference axes;
# each pictured board remains dimensionally unconfirmed until its coupon fits.
# The Arduino UNO pattern is asymmetric and may be rotated but never mirrored.
# The Raspberry Pi/HAT pattern is exactly 58 x 49 mm. The UPS/cell assembly is
# still bench-only; matching screw holes do not authorize it underhood.
controller_outline = [68.58, 53.34]
controller_holes_local = [[66.04, 7.62], [66.04, 35.56], [13.97, 2.54], [15.24, 50.8]]
controller_coupon_blank = Part.makeBox(
    controller_outline[0], 3.0, controller_outline[1]
)
controller_coupon_cuts = [
    hole_y(
        local[0], local[1],
        FIXED["board_m25_screw_clearance_d_mm"], -0.5, 4.0,
    )
    for local in controller_holes_local
]
controller_pattern_coupon = controller_coupon_blank.cut(
    Part.makeCompound(controller_coupon_cuts)
).removeSplitter()
for index, (center, cutter) in enumerate(zip(
    controller_holes_local, controller_coupon_cuts
)):
    pcb_mount_feature_geometry_checks.append(audit_round_cut_y(
        "arduino_uno_mount_coupon",
        "hole_%d" % (index + 1),
        controller_coupon_blank,
        controller_pattern_coupon,
        cutter,
        center,
        FIXED["board_m25_screw_clearance_d_mm"],
    ))

ups_outline = [85.0, 56.0]
ups_holes_local = [[3.5, 3.5], [3.5, 52.5], [61.5, 3.5], [61.5, 52.5]]
ups_coupon_blank = Part.makeBox(ups_outline[0], 3.0, ups_outline[1])
ups_coupon_cuts = [
    hole_y(
        local[0], local[1], FIXED["board_m25_screw_clearance_d_mm"],
        -0.5, 4.0,
    )
    for local in ups_holes_local
]
ups_mount_coupon = ups_coupon_blank.cut(
    Part.makeCompound(ups_coupon_cuts)
).removeSplitter()
for index, (center, cutter) in enumerate(zip(ups_holes_local, ups_coupon_cuts)):
    pcb_mount_feature_geometry_checks.append(audit_round_cut_y(
        "raspberry_pi_hat_mount_coupon",
        "hole_%d" % (index + 1),
        ups_coupon_blank,
        ups_mount_coupon,
        cutter,
        center,
        FIXED["board_m25_screw_clearance_d_mm"],
    ))

# A signed bench-only plate carries the same exact Pi/HAT axes. Its expanded
# right field keeps the QR fully outside the 85 x 56 mm board outline. It is a
# packaging aid only and is deliberately not part of the underhood assembly.
pi_plate_spec = BRANDING["raspberry_pi_hat_bench_baseplate"]
pi_plate_outline = pi_plate_spec["outline_xz_mm"]
pi_board_origin = pi_plate_spec["board_origin_xz_mm"]
pi_plate_blank = Part.makeBox(pi_plate_outline[0], 3.0, pi_plate_outline[1])
pi_plate_hole_centers = [
    [pi_board_origin[0] + local[0], pi_board_origin[1] + local[1]]
    for local in ups_holes_local
]
pi_plate_cutters = [
    hole_y(
        center[0], center[1], FIXED["board_m25_screw_clearance_d_mm"],
        -0.5, 4.0,
    )
    for center in pi_plate_hole_centers
]
pi_bench_baseplate = pi_plate_blank.cut(
    Part.makeCompound(pi_plate_cutters)
).removeSplitter()
for index, (center, cutter) in enumerate(zip(pi_plate_hole_centers, pi_plate_cutters)):
    pcb_mount_feature_geometry_checks.append(audit_round_cut_y(
        "raspberry_pi_hat_bench_baseplate",
        "hole_%d" % (index + 1),
        pi_plate_blank,
        pi_bench_baseplate,
        cutter,
        center,
        FIXED["board_m25_screw_clearance_d_mm"],
    ))
pi_qr_cutter, pi_qr_expected, pi_qr_runs = qr_recess_y(
    QR_MATRIX,
    pi_plate_spec["qr_quiet_origin_xz_mm"],
    pi_plate_spec["qr_module_mm"],
    BRANDING["qr_quiet_zone_modules"],
    0.0,
    pi_plate_spec["recess_depth_mm"],
    1,
    True,
)
pi_bench_baseplate, row = apply_recess(
    "raspberry_pi_hat_baseplate_repository_qr",
    pi_bench_baseplate,
    pi_qr_cutter,
    pi_qr_expected,
)
row["cutter_run_count"] = pi_qr_runs
branding_geometry_checks.append(row)
pi_text_cutter, pi_text_expected, pi_text_runs = text_recess_y(
    BRANDING["signature"],
    pi_plate_spec["signature_origin_xz_mm"],
    pi_plate_spec["signature_cell_mm"],
    0.0,
    pi_plate_spec["recess_depth_mm"],
    1,
    True,
)
pi_bench_baseplate, row = apply_recess(
    "raspberry_pi_hat_baseplate_owner_signature",
    pi_bench_baseplate,
    pi_text_cutter,
    pi_text_expected,
)
row["cutter_run_count"] = pi_text_runs
branding_geometry_checks.append(row)

pi_plate_thickness = 3.0
pi_board_y = pi_plate_thickness + FIXED["board_m25_standoff_length_mm"]
pi_standoffs = [
    Part.makeCylinder(
        FIXED["board_m25_standoff_od_mm"] / 2.0,
        FIXED["board_m25_standoff_length_mm"],
        Vector(center[0], pi_plate_thickness, center[1]), Vector(0, 1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_rear_heads = [
    Part.makeCylinder(
        m25_head_r, m25_head_h,
        Vector(center[0], -m25_head_h, center[1]), Vector(0, 1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_rear_shanks = [
    Part.makeCylinder(
        m25_shank_r, m25_screw_length,
        Vector(center[0], 0.0, center[1]), Vector(0, 1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_washers = [
    Part.makeCylinder(
        FIXED["board_m25_washer_od_mm"] / 2.0,
        FIXED["board_m25_washer_thickness_mm"],
        Vector(center[0], pi_board_y + 1.6, center[1]),
        Vector(0, 1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_front_heads = [
    Part.makeCylinder(
        m25_head_r, m25_head_h,
        Vector(
            center[0],
            pi_board_y + 1.6
            + FIXED["board_m25_washer_thickness_mm"],
            center[1],
        ),
        Vector(0, 1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_front_shanks = [
    Part.makeCylinder(
        m25_shank_r, m25_screw_length,
        Vector(
            center[0],
            pi_board_y + 1.6
            + FIXED["board_m25_washer_thickness_mm"],
            center[1],
        ),
        Vector(0, -1, 0),
    )
    for center in pi_plate_hole_centers
]
pi_bench_mount_hardware = Part.makeCompound(
    pi_standoffs + pi_rear_heads + pi_rear_shanks
    + pi_washers + pi_front_heads + pi_front_shanks
)
pi_keepout = [85.0, 40.0, 62.464]
pi_bench_assembly_keepout = Part.makeBox(
    pi_keepout[0], pi_keepout[1], pi_keepout[2],
    Vector(pi_board_origin[0], pi_board_y, pi_board_origin[1]),
)
if pi_bench_assembly_keepout.BoundBox.ZMax > pi_plate_outline[1] + 0.001:
    die("Raspberry Pi/HAT assembly keepout escapes the bench baseplate height")

# Two QR sizes and all three signature cell sizes on one thin coupon qualify the
# bed-facing recess process before committing to the lid or either base plate.
# Paint-fill and scan both codes, and reject illegible lettering.
branding_coupon_blank = Part.makeBox(150.0, 3.0, 70.0)
branding_qr_process_coupon = branding_coupon_blank
for label, origin, module, depth in (
    ("coupon_lid_qr_1p0", [2.5, 2.5], 1.0, 0.55),
    ("coupon_backplane_qr_0p8", [55.0, 7.0], 0.8, 0.35),
):
    cutter, expected, runs = qr_recess_y(
        QR_MATRIX, origin, module, BRANDING["qr_quiet_zone_modules"],
        0.0, depth, 1, True,
    )
    branding_qr_process_coupon, row = apply_recess(
        label, branding_qr_process_coupon, cutter, expected
    )
    row["cutter_run_count"] = runs
    branding_geometry_checks.append(row)
for label, origin, cell, depth in (
    ("coupon_lid_signature_1p1", [2.5, 56.0], 1.1, 0.55),
    ("coupon_backplane_signature_0p8", [88.0, 56.0], 0.8, 0.35),
    ("coupon_pi_signature_0p65", [98.0, 45.0], 0.65, 0.35),
):
    cutter, expected, runs = text_recess_y(
        BRANDING["signature"], origin, cell, 0.0, depth, 1, True,
    )
    branding_qr_process_coupon, row = apply_recess(
        label, branding_qr_process_coupon, cutter, expected,
    )
    row["cutter_run_count"] = runs
    branding_geometry_checks.append(row)

# Insert-fit ladders reproduce the selected blind depths and leave at least
# 1.5 mm backing.  The final M3 position also reproduces the cap's stepped
# Ø7.2/Ø4.0 receiver seat.  Print these in the final enclosure material and
# orientation before heat-setting any production insert.
insert_pilot_ladder = [3.8, 3.9, 4.0, 4.1, 4.2]
m3_coupon_height = (
    FIXED["backplane_insert_depth_mm"] + FIXED["m3_insert_min_backing_mm"]
)
m3_coupon_bosses = [
    Part.makeCylinder(5.0, m3_coupon_height, Vector(7.0 + 12.0 * index, 6.0, 0))
    for index in range(5)
]
m3_cap_boss = Part.makeCylinder(
    5.0, FIXED["cap_receiver_length_mm"], Vector(67.0, 6.0, 0)
)
m3_insert_coupon = Part.makeBox(74.0, 4.0, FIXED["m3_insert_min_backing_mm"])
m3_insert_coupon = m3_insert_coupon.multiFuse(
    m3_coupon_bosses + [m3_cap_boss]
).removeSplitter()
m3_coupon_cuts = [
    Part.makeCylinder(
        diameter / 2.0,
        FIXED["backplane_insert_depth_mm"] + 0.1,
        Vector(7.0 + 12.0 * index, 6.0, m3_coupon_height + 0.05),
        Vector(0, 0, -1),
    )
    for index, diameter in enumerate(insert_pilot_ladder)
]
m3_coupon_cuts.extend([
    Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["cap_m3_insert_total_pocket_depth_mm"] + 0.1,
        Vector(67.0, 6.0, FIXED["cap_receiver_length_mm"] + 0.05),
        Vector(0, 0, -1),
    ),
    Part.makeCylinder(
        FIXED["cap_pilot_counterbore_d_mm"] / 2.0,
        FIXED["cap_pilot_counterbore_depth_mm"] + 0.1,
        Vector(67.0, 6.0, FIXED["cap_receiver_length_mm"] + 0.05),
        Vector(0, 0, -1),
    ),
])
m3_insert_coupon = m3_insert_coupon.cut(
    Part.makeCompound(m3_coupon_cuts)
).removeSplitter()

m25_insert_depth = 5.0
m25_coupon_height = m25_insert_depth + FIXED["m3_insert_min_backing_mm"]
m25_coupon_bosses = [
    Part.makeCylinder(4.0, m25_coupon_height, Vector(6.0 + 10.0 * index, 6.0, 0))
    for index in range(5)
]
m25_insert_coupon = Part.makeBox(
    52.0, 4.0, FIXED["m3_insert_min_backing_mm"]
).multiFuse(m25_coupon_bosses).removeSplitter()
m25_insert_coupon = m25_insert_coupon.cut(Part.makeCompound([
    Part.makeCylinder(
        diameter / 2.0,
        m25_insert_depth + 0.1,
        Vector(6.0 + 10.0 * index, 6.0, m25_coupon_height + 0.05),
        Vector(0, 0, -1),
    )
    for index, diameter in enumerate(insert_pilot_ladder)
])).removeSplitter()

# Build-Z M2.5 board-clearance ladder. It uses the same plate orientation as
# the Arduino, interface, and Pi/HAT carriers so FDM shrink is qualified before
# selecting the production clearance diameter.
board_clearance_ladder = [2.8, 2.9, 3.0, 3.1, 3.2, 3.3]
m25_board_clearance_blank = Part.makeBox(72.0, 3.0, 16.0)
m25_board_clearance_coupon = m25_board_clearance_blank.cut(Part.makeCompound([
    hole_y(6.0 + 12.0 * index, 8.0, diameter, -0.5, 4.0)
    for index, diameter in enumerate(board_clearance_ladder)
])).removeSplitter()

# Exact horizontal-bore structural-insert coupon for the standing shell. Five
# Ø10 x 8.2 bosses, root gussets, 6.7 mm blind depths, and 1.5 mm backing copy
# the production load path while testing the 3.8-4.2 mm pilot ladder.
horizontal_coupon_wall = Part.makeBox(70.0, 4.0, 24.0)
horizontal_coupon_bosses = []
horizontal_coupon_gussets = []
horizontal_coupon_cuts = []
for index, diameter in enumerate(insert_pilot_ladder):
    cx = 7.0 + 14.0 * index
    horizontal_coupon_bosses.append(Part.makeCylinder(
        FIXED["backplane_boss_d_mm"] / 2.0,
        FIXED["backplane_boss_length_mm"] + 0.2,
        Vector(cx, 3.8, 12.0), Vector(0, 1, 0),
    ))
    horizontal_coupon_gussets.append(Part.makeBox(
        12.0, FIXED["rear_load_rib_depth_mm"], FIXED["rear_load_rib_width_mm"],
        Vector(cx - 6.0, 3.8, 12.0 - FIXED["rear_load_rib_width_mm"] / 2.0),
    ))
    horizontal_coupon_cuts.append(Part.makeCylinder(
        diameter / 2.0,
        FIXED["backplane_insert_depth_mm"] + 0.1,
        Vector(cx, 12.3, 12.0), Vector(0, -1, 0),
    ))
horizontal_coupon_uncut = horizontal_coupon_wall.multiFuse(
    horizontal_coupon_bosses + horizontal_coupon_gussets
).removeSplitter()
m3_horizontal_insert_boss_coupon = horizontal_coupon_uncut.cut(
    Part.makeCompound(horizontal_coupon_cuts)
).removeSplitter()
removed_horizontal_coupon_bores = horizontal_coupon_uncut.cut(
    m3_horizontal_insert_boss_coupon
).removeSplitter()
for index, (diameter, cutter) in enumerate(zip(
    insert_pilot_ladder, horizontal_coupon_cuts
)):
    center = [7.0 + 14.0 * index, 12.0]
    insert_bore_geometry_checks.append(audit_blind_insert_bore_y(
        "m3_horizontal_insert_boss_coupon",
        "pilot_%.1f_mm" % diameter,
        removed_horizontal_coupon_bores,
        horizontal_coupon_uncut,
        cutter,
        center,
        diameter,
        FIXED["backplane_insert_depth_mm"],
        FIXED["backplane_boss_d_mm"],
        FIXED["backplane_boss_length_mm"],
        FIXED["backplane_boss_length_mm"] - FIXED["backplane_insert_depth_mm"],
    ))

# Production print transforms.
body_standing = bed_orient(
    body, App.Rotation(Vector(0, 1, 0), -90.0)
)
cap_print = bed_orient(
    cap, App.Rotation(Vector(0, 0, 1), 0.0)
)
lid_print = bed_orient(
    lid_installed, App.Rotation(Vector(1, 0, 0), -90.0)
)
backplane_print = bed_orient(
    backplane_installed, App.Rotation(Vector(1, 0, 0), 90.0)
)
adapter_template_print = bed_orient(
    adapter_template, App.Rotation(Vector(1, 0, 0), 90.0)
)
bolt_coupon_print = bed_orient(
    bolt_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
fit_cage_standing = bed_orient(
    fit_cage, App.Rotation(Vector(0, 1, 0), -90.0)
)
gland_coupon_print = bed_orient(
    gland_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
controller_pattern_coupon_print = bed_orient(
    controller_pattern_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
ups_mount_coupon_print = bed_orient(
    ups_mount_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
pi_bench_baseplate_print = bed_orient(
    pi_bench_baseplate, App.Rotation(Vector(1, 0, 0), 90.0)
)
branding_qr_process_coupon_print = bed_orient(
    branding_qr_process_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
m25_board_clearance_coupon_print = bed_orient(
    m25_board_clearance_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)

if abs(cap_print.BoundBox.ZLength - H) > 0.01:
    die("right cap is not upright on its installed Z-bottom print face")
if abs(lid_print.BoundBox.ZLength - LID_T) > 0.01:
    die("front lid is not exterior-face-down with the gasket groove opening up")

shapes = {
    "body": body,
    "body_standing": body_standing,
    "right_pigtail_cap": cap,
    "right_pigtail_cap_print": cap_print,
    "front_lid": lid_print,
    "electronics_backplane": backplane_print,
    "slot_clearance_cage": fit_cage_standing,
    "vehicle_bolt_coupon": bolt_coupon_print,
    "adapter_drill_template": adapter_template_print,
    "depth_feeler_45_55_65": depth_comb,
    "right_io_60mm_witness": io_witness,
    "pigtail_gland_coupon": gland_coupon_print,
    "standing_wall_hole_coupon": wall_coupon,
    "standing_bridge_coupon": bridge_coupon,
    "arduino_uno_mount_coupon": controller_pattern_coupon_print,
    "raspberry_pi_hat_mount_coupon": ups_mount_coupon_print,
    "raspberry_pi_hat_bench_baseplate": pi_bench_baseplate_print,
    "branding_qr_process_coupon": branding_qr_process_coupon_print,
    "m25_board_clearance_coupon": m25_board_clearance_coupon_print,
    "m3_horizontal_insert_boss_coupon": m3_horizontal_insert_boss_coupon,
    "m25_insert_fit_coupon": m25_insert_coupon,
    "m3_insert_fit_coupon": m3_insert_coupon,
    "reference_right_pigtail_cap_installed": cap,
    "reference_front_lid_installed": lid_installed,
    "reference_electronics_backplane_installed": backplane_installed,
    "reference_raspberry_pi_hat_bench_baseplate": pi_bench_baseplate,
}
for name, shape in shapes.items():
    assert_single(name, shape)
    export_pair(shape, name)
for name, shape in component_shapes.items():
    assert_single("reference_" + name, shape)
    export_pair(shape, "reference_" + name)
assert_single("reference_interboard_wiring_keepout", wire_service_keepout)
export_pair(wire_service_keepout, "reference_interboard_wiring_keepout")
assert_single("reference_board_face_wiring_plenum", board_face_wiring_plenum)
export_pair(board_face_wiring_plenum, "reference_board_face_wiring_plenum")
assert_valid("reference_wire_bend_sweep", wire_bend_sweep)
export_pair(wire_bend_sweep, "reference_wire_bend_sweep")
assert_valid("reference_interboard_tie_keepouts", interboard_tie_keepouts)
export_pair(interboard_tie_keepouts, "reference_interboard_tie_keepouts")
backplane_driver_keepout_reference = Part.makeCompound(backplane_driver_keepouts)
assert_valid("reference_backplane_driver_keepouts", backplane_driver_keepout_reference)
export_pair(backplane_driver_keepout_reference, "reference_backplane_driver_keepouts")
assert_valid("reference_controller_mount_hardware", controller_mount_hardware)
export_pair(controller_mount_hardware, "reference_controller_mount_hardware")
assert_valid("reference_interface_mount_hardware", interface_mount_hardware)
export_pair(interface_mount_hardware, "reference_interface_mount_hardware")
assert_valid(
    "reference_raspberry_pi_hat_bench_mount_hardware",
    pi_bench_mount_hardware,
)
export_pair(
    pi_bench_mount_hardware,
    "reference_raspberry_pi_hat_bench_mount_hardware",
)
assert_single(
    "reference_raspberry_pi_hat_bench_assembly_keepout",
    pi_bench_assembly_keepout,
)
export_pair(
    pi_bench_assembly_keepout,
    "reference_raspberry_pi_hat_bench_assembly_keepout",
)
assert_valid(
    "reference_controller_mount_fixed_hole_envelopes",
    controller_mount_fixed_hole_envelopes,
)
export_pair(
    controller_mount_fixed_hole_envelopes,
    "reference_controller_mount_fixed_hole_envelopes",
)
for name, shape in gland_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_gland_keepout")
for name, shape in external_gland_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_gland_tool_keepout")
for name, shape in cap_driver_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_driver_keepout")

assert_valid("adapter_reference", adapter_reference)
export_pair(adapter_reference, "reference_adapter_concept")
assert_valid("bolt_head_reference", bolt_head_reference)
bolt_head_reference.exportStep(os.path.join(OUT, "reference_bolt_head_keepouts.step"))
assert_single("bolt_plane_hood_datum", bolt_plane_hood_datum)
bolt_plane_hood_datum.exportStep(
    os.path.join(OUT, "reference_bolt_plane_hood_datum.step")
)
assert_single("lower_obstruction_keepout", lower_obstruction_keepout)
lower_obstruction_keepout.exportStep(
    os.path.join(OUT, "reference_lower_obstruction_keepout.step")
)

assembly_parts = [
    body, cap, lid_installed, backplane_installed,
] + list(component_shapes.values()) + [
    wire_service_keepout, board_face_wiring_plenum, wire_bend_sweep,
    interboard_tie_keepouts, controller_mount_hardware,
    interface_mount_hardware, adapter_reference,
]
assembly = Part.makeCompound(assembly_parts)
assert_valid("assembly", assembly)
if abs(assembly.BoundBox.YLength - MECH["installed_projection_mm"]) > 0.01:
    die("assembly Y span does not equal the adapter-back-to-lid package projection")
if abs(fit_cage.BoundBox.YLength - MECH["fit_cage_envelope_mm"][1]) > 0.01:
    die("fit-cage Y span does not equal its conservative clearance envelope")
if (
    assembly.BoundBox.XLength > L + 0.01
    or assembly.BoundBox.ZMin < -0.01
    or assembly.BoundBox.ZMax > MECH["adapter_top_z_mm"] + 0.01
):
    die("assembly exceeds the declared X/Z vehicle envelope")
assembly.exportStep(os.path.join(OUT, "assembly.step"))
assembly_mesh = MeshPart.meshFromShape(
    Shape=assembly, LinearDeflection=0.08,
    AngularDeflection=0.25, Relative=False,
)
assembly_mesh.write(os.path.join(OUT, "assembly.stl"))

collision_checks = []
def no_overlap(left_name, left_shape, right_name, right_shape, limit=0.01):
    volume = left_shape.common(right_shape).Volume
    row = {
        "left": left_name, "right": right_name,
        "overlap_mm3": volume, "limit_mm3": limit,
        "pass": volume <= limit,
    }
    collision_checks.append(row)
    if not row["pass"]:
        die("%s overlaps %s by %.6f mm^3" % (left_name, right_name, volume))

# Core removable-interface and structural-load-path checks.
no_overlap("body", body, "right_cap", cap)
no_overlap("body", body, "front_lid", lid_installed)
no_overlap("right_cap", cap, "front_lid", lid_installed)
no_overlap("body", body, "metal_adapter", adapter_reference)
for index, head in enumerate(vehicle_bolt_head_keepouts, start=1):
    no_overlap("body", body, "vehicle_bolt_head_%d" % index, head)
no_overlap("body", body, "bolt_plane_hood_datum", bolt_plane_hood_datum)
no_overlap(
    "metal_adapter", adapter_reference,
    "bolt_plane_hood_datum", bolt_plane_hood_datum,
)
no_overlap("body", body, "lower_obstruction_keepout", lower_obstruction_keepout)
no_overlap("body", body, "electronics_backplane", backplane_installed)
no_overlap("right_cap", cap, "electronics_backplane", backplane_installed)
no_overlap("body", body, "interboard_wiring_keepout", wire_service_keepout)
no_overlap("right_cap", cap, "interboard_wiring_keepout", wire_service_keepout)
no_overlap("front_lid", lid_installed, "interboard_wiring_keepout", wire_service_keepout)
for shell_name, shell_shape in (
    ("body", body), ("right_cap", cap), ("front_lid", lid_installed)
):
    no_overlap(shell_name, shell_shape, "board_face_wiring_plenum", board_face_wiring_plenum)
    no_overlap(shell_name, shell_shape, "wire_bend_sweep", wire_bend_sweep)
    no_overlap(shell_name, shell_shape, "interboard_tie_keepouts", interboard_tie_keepouts)
no_overlap(
    "controller_mount_hardware", controller_mount_hardware,
    "interboard_wiring_keepout", wire_service_keepout,
)
no_overlap("controller_mount_hardware", controller_mount_hardware, "body", body)
no_overlap("controller_mount_hardware", controller_mount_hardware, "right_cap", cap)
no_overlap("controller_mount_hardware", controller_mount_hardware, "front_lid", lid_installed)
no_overlap(
    "controller_mount_hardware", controller_mount_hardware,
    "interface_pcb_reserved", component_shapes["interface_pcb_reserved"],
)
no_overlap(
    "controller_mount_fixed_hole_envelopes", controller_mount_fixed_hole_envelopes,
    "interboard_wiring_keepout", wire_service_keepout,
)
for shell_name, shell_shape in (
    ("body", body), ("right_cap", cap), ("front_lid", lid_installed)
):
    no_overlap(
        "controller_mount_fixed_hole_envelopes",
        controller_mount_fixed_hole_envelopes,
        shell_name,
        shell_shape,
    )
no_overlap(
    "controller_mount_fixed_hole_envelopes", controller_mount_fixed_hole_envelopes,
    "interface_pcb_reserved", component_shapes["interface_pcb_reserved"],
)
no_overlap(
    "interface_mount_hardware", interface_mount_hardware,
    "interboard_wiring_keepout", wire_service_keepout,
)
no_overlap("interface_mount_hardware", interface_mount_hardware, "body", body)
no_overlap("interface_mount_hardware", interface_mount_hardware, "right_cap", cap)
no_overlap("interface_mount_hardware", interface_mount_hardware, "front_lid", lid_installed)
no_overlap(
    "interface_mount_hardware", interface_mount_hardware,
    "owner_esp32_s3_uno_candidate",
    component_shapes["owner_esp32_s3_uno_candidate"],
)
no_overlap(
    "interboard_wiring_keepout", wire_service_keepout,
    "backplane_driver_keepouts", backplane_driver_keepout_reference,
)
no_overlap(
    "board_face_wiring_plenum", board_face_wiring_plenum,
    "backplane_driver_keepouts", backplane_driver_keepout_reference,
)
no_overlap(
    "interboard_tie_keepouts", interboard_tie_keepouts,
    "backplane_driver_keepouts", backplane_driver_keepout_reference,
)
for index, head in enumerate(adapter_head_keepouts, start=1):
    no_overlap(
        "adapter_head_%d" % index, head,
        "electronics_backplane", backplane_installed,
    )
for name, keepout in external_gland_keepouts.items():
    no_overlap(name + "_gland_tool_keepout", keepout, "right_cap", cap)
gland_names = list(gland_keepouts)
for index, left_name in enumerate(gland_names):
    for right_name in gland_names[index + 1:]:
        no_overlap(
            left_name + "_gland_keepout", gland_keepouts[left_name],
            right_name + "_gland_keepout", gland_keepouts[right_name],
        )
        no_overlap(
            left_name + "_gland_tool_keepout", external_gland_keepouts[left_name],
            right_name + "_gland_tool_keepout", external_gland_keepouts[right_name],
        )
for name, keepout in cap_driver_keepouts.items():
    no_overlap(name + "_driver_keepout", keepout, "right_cap", cap)

support_checks = []
shell_without_lid = body.fuse(cap)
for support_name, probe, support in (
    ("front_face_gasket", face_seal_probe, shell_without_lid),
    ("closed_cap_seam_gasket", cap_seal_probe, body),
):
    supported = probe.common(support).Volume
    coverage = supported / probe.Volume if probe.Volume else 0.0
    row = {
        "interface": support_name,
        "probe_mm3": probe.Volume,
        "supported_mm3": supported,
        "coverage_percent": 100.0 * coverage,
        "minimum_percent": 99.9,
        "pass": coverage >= 0.999,
    }
    support_checks.append(row)
    if not row["pass"]:
        die("%s support coverage is %.5f percent" %
            (support_name, row["coverage_percent"]))

# Verify service removal as actual solids at 1 mm increments.  The complete
# populated backplane must pass the face throat.  With the lid
# removed, the cap must withdraw toward +X.
service_sweep_checks = []
loaded_backplane = Part.makeCompound([
    backplane_installed,
    *component_shapes.values(),
    wire_service_keepout,
    board_face_wiring_plenum,
    wire_bend_sweep,
    interboard_tie_keepouts,
    controller_mount_hardware,
    interface_mount_hardware,
])
for travel in range(1, int(D + 6.0)):
    moving = loaded_backplane.copy()
    moving.translate(Vector(0, float(travel), 0))
    overlap = moving.common(shell_without_lid).Volume
    service_sweep_checks.append({
        "interface": "loaded_backplane_+Y",
        "travel_mm": travel,
        "overlap_mm3": overlap,
        "pass": overlap <= 0.01,
    })
    if overlap > 0.01:
        die("loaded backplane removal collides at +Y=%d mm" % travel)
for travel in range(1, 21):
    moving = cap.copy()
    moving.translate(Vector(float(travel), 0, 0))
    overlap = moving.common(body).Volume
    service_sweep_checks.append({
        "interface": "right_cap_+X",
        "travel_mm": travel,
        "overlap_mm3": overlap,
        "pass": overlap <= 0.01,
    })
    if overlap > 0.01:
        die("right cap removal collides at +X=%d mm" % travel)

component_names = list(component_shapes)
for index, left_name in enumerate(component_names):
    for right_name in component_names[index + 1:]:
        no_overlap(
            left_name, component_shapes[left_name],
            right_name, component_shapes[right_name],
        )
for name, shape in component_shapes.items():
    no_overlap(name, shape, "body", body)
    no_overlap(name, shape, "right_cap", cap)
    no_overlap(name, shape, "front_lid", lid_installed)
    no_overlap(name, shape, "electronics_backplane", backplane_installed)
    for gland_name, gland_shape in gland_keepouts.items():
        no_overlap(name, shape, gland_name + "_gland_keepout", gland_shape)
    no_overlap(name, shape, "interboard_wiring_keepout", wire_service_keepout)
    no_overlap(name, shape, "board_face_wiring_plenum", board_face_wiring_plenum)
    no_overlap(name, shape, "wire_bend_sweep", wire_bend_sweep)
    no_overlap(name, shape, "interboard_tie_keepouts", interboard_tie_keepouts)
    for index, driver in enumerate(backplane_driver_keepouts, start=1):
        no_overlap(name, shape, "backplane_driver_%d" % index, driver)
for gland_name, gland_shape in gland_keepouts.items():
    no_overlap(
        "interboard_wiring_keepout", wire_service_keepout,
        gland_name + "_gland_keepout", gland_shape,
    )

doc = App.newDocument("AC_Diagnostic_Enclosure_Hood_Flange_V4")
add_feature(doc, "Body", "Standing-print compact shell", body, (0.10, 0.28, 0.52))
add_feature(doc, "RightPigtailCap", "Recessed right pigtail cap", cap, (0.18, 0.46, 0.72))
add_feature(doc, "FrontLid", "Engine-facing service lid", lid_installed, (0.92, 0.34, 0.08), 12)
add_feature(doc, "Backplane", "Vertical electronics backplane", backplane_installed, (0.72, 0.72, 0.76), 15)
add_feature(doc, "MetalAdapterConcept", "UNRELEASED adapter measurement concept", adapter_reference, (0.58, 0.60, 0.64), 10)
add_feature(doc, "BoltHeadKeepouts", "Conservative bolt-head envelopes", bolt_head_reference, (0.75, 0.75, 0.78), 55)
add_feature(
    doc, "BoltPlaneHoodDatum",
    "Reported hood datum at bolt plane; full-depth slope unknown",
    bolt_plane_hood_datum, (0.88, 0.10, 0.10), 82,
)
add_feature(
    doc, "LowerObstructionKeepout",
    (
        "Provisional %.1f mm lower obstruction plane from bolt axis; "
        "measurement endpoints unresolved"
    ) % P["reported_lower_clearance_mm"],
    lower_obstruction_keepout, (0.95, 0.55, 0.05), 85,
)
palette = [
    (0.12, 0.62, 0.24), (0.65, 0.22, 0.75),
    (0.06, 0.52, 0.84), (0.91, 0.62, 0.06), (0.08, 0.72, 0.68),
]
for index, (name, shape) in enumerate(component_shapes.items()):
    add_feature(doc, "Reference_" + name, name, shape, palette[index], 50)
add_feature(
    doc, "InterboardWiringKeepout",
    "Reserved inter-board wiring/service corridor",
    wire_service_keepout, (0.10, 0.82, 0.88), 72,
)
add_feature(
    doc, "BoardFaceWiringPlenum",
    "Reserved lid-side harness plenum across both board faces",
    board_face_wiring_plenum, (0.12, 0.66, 0.95), 84,
)
add_feature(
    doc, "WireBendSweep",
    "Six-millimetre bundle sweep with fifteen-millimetre inside radius",
    wire_bend_sweep, (0.96, 0.35, 0.08), 32,
)
add_feature(
    doc, "InterboardTieKeepouts",
    "Two unqualified cable-tie hardware envelopes",
    interboard_tie_keepouts, (0.96, 0.72, 0.08), 38,
)
add_feature(
    doc, "BackplaneDriverKeepouts",
    "Four backplane screw-driver service paths",
    backplane_driver_keepout_reference, (0.96, 0.72, 0.08), 82,
)
add_feature(
    doc, "ControllerMountHardware",
    "Controller: eight M2.5 screws/shanks, four 8 mm standoffs, four washers",
    controller_mount_hardware, (0.72, 0.72, 0.76), 35,
)
add_feature(
    doc, "InterfaceMountHardware",
    "Interface PCB: eight M2.5 screws/shanks, four 8 mm standoffs, four washers",
    interface_mount_hardware, (0.62, 0.68, 0.76), 35,
)
add_feature(
    doc, "ControllerMountFixedHoleEnvelopes",
    "Reserved controller hardware envelopes at all four exact UNO axes",
    controller_mount_fixed_hole_envelopes, (0.95, 0.24, 0.12), 82,
)
for name, shape in gland_keepouts.items():
    add_feature(doc, "Keepout_" + name, name + " gland keepout", shape, (0.9, 0.1, 0.1), 82)
for name, shape in external_gland_keepouts.items():
    add_feature(doc, "ToolKeepout_" + name, name + " gland tool keepout", shape, (0.95, 0.35, 0.08), 82)
for name, shape in cap_driver_keepouts.items():
    add_feature(doc, "DriverKeepout_" + name, name + " cap driver keepout", shape, (0.96, 0.72, 0.08), 82)
doc.recompute()
doc.saveAs(os.path.join(OUT, "assembly.FCStd"))

shape_validation = {}
for name, shape in shapes.items():
    shape_validation[name] = {
        "valid": shape.isValid(),
        "solids": len(shape.Solids),
        "volume_mm3": shape.Volume,
        "bbox": bbox(shape),
    }
shape_validation["assembly"] = {
    "valid": assembly.isValid(),
    "solids": len(assembly.Solids),
    "bbox": bbox(assembly),
}

print_brims = {
    "body_standing": 12.0,
    "right_pigtail_cap_print": 8.0,
    "front_lid": 6.0,
    "electronics_backplane": 6.0,
    "slot_clearance_cage": 12.0,
    "vehicle_bolt_coupon": 6.0,
    "adapter_drill_template": 6.0,
    "depth_feeler_45_55_65": 6.0,
    "right_io_60mm_witness": 6.0,
    "pigtail_gland_coupon": 6.0,
    "standing_wall_hole_coupon": 6.0,
    "standing_bridge_coupon": 6.0,
    "arduino_uno_mount_coupon": 6.0,
    "raspberry_pi_hat_mount_coupon": 6.0,
    "raspberry_pi_hat_bench_baseplate": 6.0,
    "branding_qr_process_coupon": 6.0,
    "m25_board_clearance_coupon": 6.0,
    "m3_horizontal_insert_boss_coupon": 6.0,
    "m25_insert_fit_coupon": 6.0,
    "m3_insert_fit_coupon": 6.0,
}
print_volume_checks = []
for name, brim in print_brims.items():
    b = shapes[name].BoundBox
    required_radius = math.hypot(b.XLength, b.YLength) / 2.0 + brim
    passed = (
        abs(b.ZMin) <= 0.01
        and required_radius <= FIXED["v400_bed_diameter_mm"] / 2.0 + 0.01
        and b.ZLength <= FIXED["v400_height_mm"] + 0.01
        and shapes[name].isValid()
        and len(shapes[name].Solids) == 1
        and shapes[name].Volume > 0.0
    )
    row = {
        "part": name,
        "footprint_mm": [b.XLength, b.YLength],
        "height_mm": b.ZLength,
        "brim_mm": brim,
        "required_radius_mm": required_radius,
        "bed_seated_zmin_mm": b.ZMin,
        "pass": passed,
    }
    print_volume_checks.append(row)
    if not passed:
        die("%s exceeds the declared FLSUN V400 print gate" % name)

result = {
    "freecad_version": App.Version(),
    "shape_validation": shape_validation,
    "collision_checks": collision_checks,
    "seal_support_checks": support_checks,
    "service_sweep_checks": service_sweep_checks,
    "print_volume_checks": print_volume_checks,
    "mount_feature_geometry_checks": mount_feature_geometry_checks,
    "pcb_mount_feature_geometry_checks": pcb_mount_feature_geometry_checks,
    "branding_geometry_checks": branding_geometry_checks,
    "insert_bore_geometry_checks": insert_bore_geometry_checks,
    "right_io_feature_geometry_checks": gland_feature_geometry_checks,
    "actual_front_groove_depth_mm": actual_front_groove_depth,
    "cap_pilot_annular_wall_mm": (
        FIXED["cap_pilot_od_mm"] - FIXED["cap_screw_clearance_d_mm"]
    ) / 2.0,
    "cap_insert_effective_seat_depth_mm": (
        FIXED["cap_m3_insert_total_pocket_depth_mm"]
        - FIXED["cap_pilot_counterbore_depth_mm"]
    ),
    "cap_fastener_count": len(cap_screws),
    "controller_mount_feature_centers_xz_mm": controller_mounts,
    "controller_mount_feature_types": ["round"] * len(controller_mounts),
    "raspberry_pi_hat_bench_hole_centers_xz_mm": pi_plate_hole_centers,
    "interface_mount_feature_centers_xz_mm": interface_mounts,
    "backplane_mount_centers_xz_mm": backplane_mounts,
    "backplane_driver_keepout_count": len(backplane_driver_keepouts),
    "controller_mount_hardware": {
        "standoff_count": len(controller_hardware["standoffs"]),
        "rear_head_count": len(controller_hardware["rear_heads"]),
        "rear_shank_count": len(controller_hardware["rear_shanks"]),
        "front_head_count": len(controller_hardware["front_heads"]),
        "front_shank_count": len(controller_hardware["front_shanks"]),
        "washer_count": len(controller_hardware["washers"]),
        "fixed_hole_envelope_count": len(controller_hardware_envelopes),
    },
    "interface_mount_hardware": {
        "standoff_count": len(interface_hardware["standoffs"]),
        "rear_head_count": len(interface_hardware["rear_heads"]),
        "rear_shank_count": len(interface_hardware["rear_shanks"]),
        "front_head_count": len(interface_hardware["front_heads"]),
        "front_shank_count": len(interface_hardware["front_shanks"]),
        "washer_count": len(interface_hardware["washers"]),
    },
    "raspberry_pi_hat_bench_mount_hardware": {
        "standoff_count": len(pi_standoffs),
        "rear_head_count": len(pi_rear_heads),
        "rear_shank_count": len(pi_rear_shanks),
        "front_head_count": len(pi_front_heads),
        "front_shank_count": len(pi_front_shanks),
        "washer_count": len(pi_washers),
        "standoff_length_mm": FIXED["board_m25_standoff_length_mm"],
        "plate_thickness_mm": pi_plate_thickness,
        "board_plane_y_mm": pi_board_y,
    },
    "raspberry_pi_hat_bench_assembly_keepout": {
        "size_xyz_mm": pi_keepout,
        "bbox": bbox(pi_bench_assembly_keepout),
        "plate_edge_reserve_z_mm": (
            pi_plate_outline[1] - pi_bench_assembly_keepout.BoundBox.ZMax
        ),
        "status": "bench_only_prohibited_underhood",
        "pcb_thickness_mm": 1.6,
        "pcb_thickness_status": 'nominal_pending_physical_measurement',
        "service_envelope_status": 'blocked_pending_usb_plugs_switch_access_bend_radius_and_cell_retention',
    },
    "wire_retention": {
        "tie_keepout_count": len(tie_keepouts),
        "connector_stub_count": len(wire_connector_stubs),
        "inside_bend_radius_mm": bend_spec["inside_radius_mm"],
        "bundle_diameter_mm": 2.0 * bend_spec["bundle_radius_mm"],
        "status": WIRE_ROUTE_SPEC["retention_status"],
        "sweep_status": WIRE_ROUTE_SPEC["sweep_status"],
    },
    "controller_opposed_screw_tip_gap_mm": (
        esp[1] + FIXED["controller_candidate_pcb_thickness_mm"]
        + FIXED["board_m25_washer_thickness_mm"] - m25_screw_length
        - (bp[1] + m25_screw_length)
    ),
    "insert_mounts": {
        "structural_m3": {
            "pilot_d_mm": FIXED["m3_insert_pocket_d_mm"],
            "pocket_depth_mm": FIXED["backplane_insert_depth_mm"],
            "boss_od_mm": FIXED["backplane_boss_d_mm"],
            "boss_axial_mm": FIXED["backplane_boss_length_mm"],
            "backing_mm": (
                FIXED["backplane_boss_length_mm"]
                - FIXED["backplane_insert_depth_mm"]
            ),
        },
        "cap_m3_short": {
            "pilot_d_mm": FIXED["m3_insert_pocket_d_mm"],
            "total_pocket_depth_mm": FIXED["cap_m3_insert_total_pocket_depth_mm"],
            "effective_seat_depth_mm": (
                FIXED["cap_m3_insert_total_pocket_depth_mm"]
                - FIXED["cap_pilot_counterbore_depth_mm"]
            ),
            "backing_mm": (
                FIXED["cap_receiver_length_mm"]
                - FIXED["cap_m3_insert_total_pocket_depth_mm"]
            ),
        },
        "pilot_ladder_mm": insert_pilot_ladder,
        "m25_board_clearance_ladder_mm": board_clearance_ladder,
        "horizontal_structural_m3_coupon": {
            "boss_count": len(horizontal_coupon_bosses),
            "boss_od_mm": FIXED["backplane_boss_d_mm"],
            "boss_axial_mm": FIXED["backplane_boss_length_mm"],
            "blind_bore_depth_mm": FIXED["backplane_insert_depth_mm"],
            "backing_mm": (
                FIXED["backplane_boss_length_mm"]
                - FIXED["backplane_insert_depth_mm"]
            ),
            "root_gusset_count": len(horizontal_coupon_gussets),
        },
    },
    "wiring": {
        "interboard_keepout": WIRE_SERVICE,
        "tie_slot_centers_xz_mm": MECH["backplane_cable_tie_slot_centers_xz_mm"],
        "installed_usb_or_barrel_plug": False,
    },
    "right_io": {
        "entry_count": len(IO["pigtail_glands"]),
        "sensor_entry_count": sum(
            len(entries) for entries in IO["sensor_port_groups"].values()
        ),
        "power_entry_count": 0,
        "ids": [entry["id"] for entry in IO["pigtail_glands"]],
        "centers_yz_mm": {
            entry["id"]: entry["center_yz_mm"]
            for entry in IO["pigtail_glands"]
        },
        "sensor_groups": IO["sensor_port_groups"],
        "cutout_d_mm": P["pigtail_gland_d_mm"],
        "reserved_keepout_d_mm": FIXED["gland_keepout_d_mm"],
        "power_hardware_status": "absent_unresolved_no_fifth_hole",
    },
    "mount": {
        "datum": "vehicle-feature midpoint shifted right of enclosure centerline per owner markup",
        "pair_offset_x_mm": P["mount_pair_offset_x_mm"],
        "centers_xz_mm": mounts,
        "round_d_mm": P["mount_hole_d_mm"],
        "slot_overall_mm": [P["mount_slot_length_mm"], P["mount_hole_d_mm"]],
        "adapter_material": "measurement-gated metal fabrication concept; material and bends not released",
        "vehicle_facing_plate": "planar",
        "engine_side_formed_returns": {
            "count": len(adapter_return_flanges),
            "depth_mm": adapter_return_depth,
            "minimum_case_gap_mm": MECH["adapter_return_to_case_gap_mm"],
            "status": "stiffness-and-clearance-reference-only",
        },
        "case_pattern_center_x_mm": MECH["adapter_case_pattern_center_x_mm"],
        "pair_to_case_pattern_eccentricity_x_mm": MECH[
            "mount_to_case_pattern_eccentricity_x_mm"
        ],
        "crossbar_case_edge_margins_mm": MECH[
            "adapter_crossbar_case_edge_margins_mm"
        ],
        "printed_template_load_bearing": False,
        "case_top_to_head_bottom_mm": P["case_top_to_head_bottom_mm"],
        "head_lower_upper_z_mm": [
            MECH["bolt_head_envelope_mm"]["lower_z"],
            MECH["bolt_head_envelope_mm"]["upper_z"],
        ],
        "adapter_top_z_mm": MECH["adapter_top_z_mm"],
        "bolt_plane_hood_datum_z_mm": MECH["bolt_plane_hood_datum_z_mm"],
        "reported_lower_clearance_mm": P["reported_lower_clearance_mm"],
        "lower_clearance_datum": MECH["lower_clearance_datum"],
        "case_drop_below_bolt_axis_mm": MECH[
            "case_drop_below_bolt_axis_mm"
        ],
        "lower_obstruction_z_mm": MECH["lower_obstruction_z_mm"],
        "lower_clearance_reserve_mm": MECH["lower_clearance_reserve_mm"],
    },
    "fit_cage": {
        "envelope_mm": MECH["fit_cage_envelope_mm"],
        "package_projection_mm": MECH["installed_projection_mm"],
        "hardware_projection_mm": MECH["installed_hardware_projection_mm"],
        "static_use_only": True,
        "engine_off": True,
        "hood_close_instruction": "close slowly with soft clay/foam witnesses; never slam",
        "standing_terminal_bridge": cage_terminal_overlap > 0.01,
        "terminal_opening_probe_overlap_mm3": cage_terminal_overlap,
        "terminal_opening_mm": [
            cage_depth - 2.0 * rail,
            H - 2.0 * rail,
        ],
        "anti_sway_diagonal_braces": len(cage_braces),
    },
    "standing_print": {
        "body_footprint_mm": MECH["standing_footprint_mm"],
        "body_height_mm": MECH["standing_body_height_mm"],
        "body_required_radius_with_brim_mm": MECH["v400_body_required_radius_mm"],
        "v400_bed_radius_mm": FIXED["v400_bed_diameter_mm"] / 2.0,
        "v400_height_mm": FIXED["v400_height_mm"],
        "right_cap_orientation": "installed Z-bottom; no late-layer locator tabs",
        "front_lid_orientation": "solid exterior face down; gasket groove opens upward",
        "localized_support_required_for": [
            "body terminal service-throat rail",
            "right-cap top rim and horizontal gland openings",
        ],
        "required_support_mode": (
            "support-everywhere/support-on-model, painted only beneath the "
            "listed roofs; protect gasket seats with blockers"
        ),
        "slicer_preview_gate": (
            "support must visibly reach every painted roof before printing"
        ),
        "support_coupon_span_mm": MECH["standing_bridge_coupon_span_mm"],
        "support_coupon_height_mm": (
            MECH["standing_bridge_coupon_support_height_mm"]
            + FIXED["front_right_seal_rail_mm"]
        ),
    },
    "gland_coupon": {
        "panel_web_mm": PANEL_WEB,
        "sacrificial_membrane_mm": MEMBRANE,
        "features": coupon_features,
    },
    "service": {
        "lid_direction": "+Y toward engine",
        "backplane_direction": "+Y after disconnecting all four sensor pigtails",
        "battery_installation": (
            "prohibited underhood; no UPS board or loose cell is installed in the "
            "underhood assembly; separate bench-only reference geometry is excluded"
        ),
        "structural_harness_relief": (
            "required external rubber-lined metal-backed P-clamps on separately "
            "verified vehicle-structure points; locations remain pending measurements"
        ),
        "backplane_mount": (
            "four M3 x 8 low-profile screws into four CNC Kitchen M3 x 5.7 "
            "insert bosses; corner heads and driver paths remain outside the "
            "inter-board wire aisle"
        ),
        "backplane_floor_support": "two broad printed shelves; rear screws provide retention",
        "component_mount": (
            "ESP32-S3 UNO and custom interface PCB each use four commercial "
            "8 mm through-tapped M2.5 standoffs, eight M2.5 x 6 screws, and "
            "four under-head washers; the exact rotated UNO pattern remains coupon-gated"
        ),
        "interboard_wiring": WIRE_SERVICE,
        "adapter_load_path": (
            "planar vehicle-facing plate with three engine-side return-flange "
            "references; OD10 metal sleeves continue through the polymer rear wall"
        ),
        "rear_load_path_reinforcement": {
            "sleeve_collars": len(sleeve_collars),
            "grid_ribs": len(rear_load_ribs),
            "backplane_boss_gussets": len(backplane_boss_gussets),
            "backplane_floor_shelves": len(floor_shelves),
        },
        "right_io_witness": {
            "working_length_mm": FIXED["external_pigtail_service_mm"],
            "datum_heel_mm": FIXED["io_witness_datum_heel_mm"],
            "overall_length_mm": io_witness_overall,
        },
    },
}
with open(os.path.join(OUT, "freecad_result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, indent=2, sort_keys=True)
print(
    "CAD_OK firewall_hood_flange_v4 body=%.3f cap=%.3f checks=%d" %
    (body.Volume, cap.Volume, len(collision_checks)),
    flush=True,
)

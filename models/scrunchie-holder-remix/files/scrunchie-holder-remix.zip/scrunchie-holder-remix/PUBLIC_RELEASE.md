# Scrunchie Tree — Tall Four-Peg Remix

A tall scrunchie and hair-tie tree by Isaiah Dupree, remixed from MattMo3D's twisted-post scrunchie holder. The original holds scrunchies on a single twisted post; this version uses a round base, a central post, and four angled twisted pegs so more scrunchies stay visible and easy to grab.

## Credits

Remixed from [Scrunchie holder](https://www.printables.com/model/281155) by **MattMo3D** — CC BY-NC 4.0. This remix is released under CC BY-NC-SA 4.0.

## Parts

- `scrunchie_holder.stl` — one piece, about 193 × 180 × 395 mm tall.
- `scrunchie_holder.stp` — STEP export for editing.

## Printing

- At 395 mm tall, this needs a printer with at least about 400 mm of Z height, such as a large delta. Scale it down for smaller printers.
- Print standing on its base. The angled pegs overhang, so preview supports in your slicer.
- Use a wide brim or mouse ears; a tall, narrow print benefits from extra bed adhesion.
- Low infill is fine for a light-duty organizer. Add weight to the base if the tree tips when loaded.

## Status

Print settings and a completed print are not documented in this release.

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International. See [LICENSE.md](LICENSE.md).

Full source mirror and future revisions: https://github.com/IsaiahDupree/3d-print-library

Design requests: https://github.com/IsaiahDupree/3d-print-library/issues/new/choose

## Isaiah Dupree brand + GitHub QR coupon

`isaiah-dupree-github-qr-branding.stl` is an optional, separately printable process coupon. It carries the ISAIAH DUPREE block signature and a deterministic QR code for https://github.com/IsaiahDupree/3d-print-library. Keep it separate from fitted or load-bearing model surfaces; contrast-fill the recessed cells and verify the code scans before display.

Three parts from the Cypress workbench lighting project. The kit includes a small screw block, a long strip carrier and a shaped corner support. These are mounting and layout prototypes. Use the editable STEP files to compare the channels and fastener holes with your bench and LED strip.

The block is about 21.5 × 21.0 × 20.5 mm, the long carrier spans 236.5 mm, and the corner support is roughly 78.4 × 97.4 × 25.0 mm. Leave room for adhesion and supports on the long part. Check the finished print near any warm LEDs or aluminum channel before installing it.

The renders show the original parts. Orion checked the STL meshes and reloaded the matching STEP files. Hardware fit, thermal performance and long-term mounting strength remain unverified.

Licence CC BY-NC-SA 4.0. Credit Isaiah Dupree when sharing or remixing.

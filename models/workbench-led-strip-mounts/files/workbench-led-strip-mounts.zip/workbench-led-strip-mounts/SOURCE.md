# Source and digital checks

The Cypress live files match the October 24 backup by SHA-256. The original DesignModeler STEP headers and local project revisions identify the source. Orion checked each STL for closure, orientation consistency and one connected solid, and reloaded the matching STEP to compare its solid count, dimensions and volume.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| led-strip-connector-v2.stl | `f475dc3b075509a2c629fe71da003bf48d56047c6105d0679c20d57adad31b99` | `f475dc3b075509a2c629fe71da003bf48d56047c6105d0679c20d57adad31b99` |
| led-strip-connector-v2.step | `525ae5d430429123a05b8af31c7de63a6a76e4dc6f1b85c2b0f6910ca3f3fb3f` | `1dd8094acd2bbeac87d56437ee550cc426b67dc72a788f04f9426ba6fe06b8ab` |
| led-strip-block-v2.stl | `109715f265634bb132664f086632202163f8ff052435b0f722a40c05052846b2` | `109715f265634bb132664f086632202163f8ff052435b0f722a40c05052846b2` |
| led-strip-block-v2.step | `f4ab578df09d361afefee600749d05e0fcb3f57bfc3cce93488567a3d92c7817` | `d2dbf3e82f8748e5d8564f8b2d40f2c454f1e5773e2aec5980c331c3a1f5e221` |
| led-strip-corner.stl | `61471c7bf4cba505d461b9e26d8d3aa31faae198c337cee66fb7ab140b25c890` | `61471c7bf4cba505d461b9e26d8d3aa31faae198c337cee66fb7ab140b25c890` |
| led-strip-corner.step | `415dd666a6d03e8ea80b811a97e84d277777b8dc5e2547bd31850e47d7a141fb` | `0bb9258fc86eb02f7aba28711df24a6c994ea87d8a457a3a0b2d80668fe937a9` |

Workstation paths and account names were removed from the affected STEP headers. The geometry section was preserved byte for byte.

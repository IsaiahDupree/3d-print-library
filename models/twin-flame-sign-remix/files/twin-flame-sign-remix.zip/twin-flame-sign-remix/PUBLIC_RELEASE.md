# Twin Flame Desk Sign — Remix

A four-part standing flame sign by Isaiah Dupree, remixed from two flame designs on Printables. The flame artwork is theirs; the layered frame-and-insert construction, round base, and upright connector are new.

## Credits

- Flame outline: [Just Fire](https://www.printables.com/model/994911) by **ozan** — CC BY 4.0.
- Flame artwork reference: [Flame wall art](https://www.printables.com/model/760426) by **Moriel** — CC BY-NC-SA 4.0.

Because one source is NonCommercial-ShareAlike, this remix is released under CC BY-NC-SA 4.0.

## Parts

- `out.stl` — 187 × 154.8 × 13 mm outer flame frame.
- `in.stl` — 187 × 154.8 × 6.6 mm flame insert with a recessed channel following the outline.
- `base.stl` — Ø230 × 7 mm round base.
- `connector.stl` — 73.7 × 73.9 × 165.5 mm upright L-bracket that joins the sign to the base.
- `connector_with_screw_holes.stl` — the same bracket with four screw holes in the foot.
- STEP files for the frame, insert, and base.

## Printing

- Print the frame, insert, and base flat.
- Use two contrasting colors for the frame and insert, or a translucent insert if you plan to add lighting.
- Print the connector standing on its foot and check the bend region in your slicer.

The insert's channel can hold a thin LED strip, but no lighting, wiring, or power design is included. If you add LEDs, use a low-voltage supply and keep wiring away from heat.

## Status

Assembly fit between the connector, base, and sign panels is not documented in this release. Dry-fit the parts before gluing or fastening.

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International. See [LICENSE.md](LICENSE.md).

Full source mirror and future revisions: https://github.com/IsaiahDupree/3d-print-library

Design requests: https://github.com/IsaiahDupree/3d-print-library/issues/new/choose

## Isaiah Dupree brand + GitHub QR coupon

`isaiah-dupree-github-qr-branding.stl` is an optional, separately printable process coupon. It carries the ISAIAH DUPREE block signature and a deterministic QR code for https://github.com/IsaiahDupree/3d-print-library. Keep it separate from fitted or load-bearing model surfaces; contrast-fill the recessed cells and verify the code scans before display.

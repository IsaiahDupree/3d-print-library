# Printed parts and build envelope

| File | XYZ extents in mm | Centered circular footprint in mm |
| --- | --- | --- |
| reservoir_print.stl | 292.2 × 292.2 × 270.0 | 289.3 |
| front_pump_drawer_print.stl | 126.0 × 63.8 × 106.0 | 141.2 |
| dry_front_body_print.stl | 196.0 × 115.2 × 300.0 | 227.3 |
| display_front_hood_print.stl | 200.0 × 150.0 × 36.2 | 250.0 |
| button_battery_front_print.stl | 196.0 × 69.2 × 4.4 | 207.9 |
| front_electronics_cassette_print.stl | 185.0 × 84.1 × 180.0 | 203.2 |
| front_battery_drawer_print.stl | 149.0 × 71.8 × 14.5 | 165.4 |
| valve_bank_left_print.stl | 132.0 × 108.0 × 300.0 | 170.6 |
| zone_front_left_lower_print.stl | 132.0 × 149.6 × 4.4 | 199.5 |
| zone_front_left_upper_print.stl | 132.0 × 149.6 × 4.4 | 199.5 |
| front_valve_tray_left_1_print.stl | 120.6 × 93.8 × 16.0 | 152.8 |
| front_valve_tray_left_2_print.stl | 120.6 × 93.8 × 16.0 | 152.8 |
| valve_bank_right_print.stl | 132.0 × 108.0 × 358.0 | 170.6 |
| zone_front_right_lower_print.stl | 132.0 × 149.6 × 4.4 | 199.5 |
| zone_front_right_upper_print.stl | 132.0 × 149.6 × 4.4 | 199.5 |
| front_valve_tray_right_1_print.stl | 120.6 × 93.8 × 16.0 | 152.8 |
| front_valve_tray_right_2_print.stl | 120.6 × 93.8 × 16.0 | 152.8 |
| bank_link_left_80_print.stl | 38.0 × 10.0 × 3.0 | 39.3 |
| bank_link_left_270_print.stl | 38.0 × 10.0 × 3.0 | 39.3 |
| bank_link_right_80_print.stl | 38.0 × 10.0 × 3.0 | 39.3 |
| bank_link_right_270_print.stl | 38.0 × 10.0 × 3.0 | 39.3 |
| camera_front_base_print.stl | 28.0 × 52.0 × 3.0 | 59.1 |
| camera_lower_arm_print.stl | 14.0 × 12.0 × 110.0 | 18.4 |
| camera_upper_cradle_print.stl | 50.5 × 32.4 × 117.6 | 60.0 |
| camera_front_weather_cap_print.stl | 44.2 × 46.4 × 20.2 | 64.0 |
| solar_lid_print.stl | 276.0 × 276.0 × 10.0 | 276.0 |
| hinge_dock_print.stl | 80.0 × 27.8 × 42.0 | 84.7 |
| lid_hinge_link_print.stl | 56.0 × 35.0 × 14.2 | 66.0 |
| solar_bar_-88_print.stl | 230.0 × 14.0 × 10.0 | 230.4 |
| solar_bar_88_print.stl | 230.0 × 14.0 × 10.0 | 230.4 |

# Assembly and service notes

The drawers pull forward. The solar lid hinges upward. Work with the power isolated and the reservoir drained when removing wet components.

| Assembly | Service sequence | Nominal fasteners |
| --- | --- | --- |
| Electronics | Remove both center covers, disconnect the wiring, and withdraw the cassette | Four M3 × 8 |
| Battery | Remove the electronics first, disconnect the battery, and slide its drawer forward | Two M3 × 8 |
| Valve trays | Remove each zone cover, disconnect hoses and leads, and lift out the tray | Two M3 × 8 per tray |
| Pump | Drain the tank, disconnect the pump and hose, and withdraw the wet drawer | Four M3 × 10 |
| Complete dry pod | Remove the electronics, battery and bank links, then pull the pod forward | Three M3 × 12 and M3 × 8 link screws |
| Camera | Remove the weather cap to reach the camera. Remove the lower arm before approaching the base screws | Four M3 × 8 cap screws and three M3 × 8 base screws |
| Solar dock | Support and remove the lid and panel, withdraw the transverse pin, and approach the dock fasteners from above | M3 × 8 dock screws and an M4 hinge pin |

Check M3 insert seating, drawer travel, bend radius, the actual glands and wet-part seals on separate specimens before assembling the enclosure. The pictured battery, valves, pump, camera, cable glands and solar panel are illustrative of the intended hardware. Size real components to the exported mounting geometry.

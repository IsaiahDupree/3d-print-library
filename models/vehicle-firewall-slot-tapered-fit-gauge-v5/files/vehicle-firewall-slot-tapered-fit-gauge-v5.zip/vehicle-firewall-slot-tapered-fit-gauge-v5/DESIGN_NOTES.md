# AC diagnostic enclosure V5 — tapered fit-gauge notes

## Outcome

This package translates the owner's red markup into a portrait, firewall-plane
tapered *clearance cage*. It deliberately does not design the final enclosure.
The shoulder is 126 mm wide, the lower end is
76 mm wide, the drop is 135 mm,
and the depth witness is capped at 60 mm.

The marked diagonals were interpreted as a taper in the firewall plane. They were
not treated as proof that the enclosure pitches outward toward the engine. A
side measurement can change that interpretation before full enclosure geometry
is started.

## Safety and scope

- `NONSTRUCTURAL ALL-POLYMER FIT/DRILL TEMPLATE ONLY; never use as the vehicle load path`
- Engine-bay release: `blocked_pending_direct_vehicle_measurements_fit_gauge_material_hood_slope_vibration_and_temperature_tests`
- No electronics, battery, UPS, wiring, glands, or PCB mounts are modeled.
- The 92 × 34 mm plate is a polymer drill/fit outline and a reference-only metal-adapter envelope. It is not a material or fabrication release.
- Clamp load must ultimately remain metal-to-metal through an engineered adapter/spacer stack. Polymer must not enter the permanent OEM-bolt clamp path.
- A permanent load path must use a directly measured formed or gusseted metal adapter with metal compression sleeves and engineering review. The four printed bridge gussets only keep this sacrificial gauge intact during handling.
- No lower anti-rock hard foot is printed: the candidate X=0 lower reaction zone remains pending the stamped-panel gap/profile and compliant-isolator compression measurements. An inferred rigid contact could preload sheet metal or transfer vibration load.
- The broad hood surface is only the reported 5–7 mm bolt-plane datum extrapolated for visualization. Actual hood slope across 60 mm is unknown.

## Fit information encoded

- One round Ø9.2 mm feature and one horizontal 14.0 × 9.2 mm slot.
- In installed body coordinates the feature centers are X=+6.735 and +57.265 mm. They remain 50.53 mm apart and mirror about the shifted pair/adapter midpoint X=+32.0 mm; the tapered body stays centered at X=0.
- The selected +32.0 mm default relationship is the owner-directed horizontal mirror of the prior approximately 32 mm left-offset render, pending direct vehicle confirmation.
- At this setting the slot center is 5.735 mm inside the upper-body right edge. Its far edge has -1.265 mm body clearance (negative is overhang), while the shifted adapter retains 13.735 mm of outer ligament. Keeping the entire slot inside the body would cap the midpoint at X=+30.735 mm; that threshold and the bounded override range are not structural or fit releases.
- The standalone drill template is intentionally pair-local about X=0; because it has no body datum, translating it would not alter the printed plate. All installed/reference relationship artifacts retain the resolved X=+32.0 mm shift.
- Straight sides continue from 24 to 66 mm below the bolt axis.
- Front and rear perimeter frames, six depth rails, intermediate crossbars, and four side-plane diagonals create a low-material depth witness.
- The rear frame begins at 9.0 mm and the cage body spans 51.0 mm to the 60.0 mm panel-datum depth cap; four sacrificial bridges keep this a single printable gauge.
- Breakaway feelers cover 45/50/55/60 mm depth.
- Indicator coupons cover -10/0/+10 mm lateral options.
- Integrated/coupon whiskers have CAD-BRep outward extents of exactly 5 mm static and 10 mm moving-loom from their named body/profile or coupon-base datum planes. Their embedded roots extend only behind those datums, so root attachment does not add hidden length; printed parts still require caliper verification.
- Those selected whisker lengths are fit-study witnesses, not permission to reduce the release criteria: static clearance remains ≥5.0 mm and moving-loom clearance remains ≥10.0 mm.
- `reference_right_io_reservation` marks a candidate zone on the straight upper-right side. It is not a hole, gland model, collision pass, or wire-bend qualification.

## Generated checks

- FreeCAD: `pass`
- Installed maximum polymer Z: 9.000 mm; conservative bolt-head upper tangent is +10.000 mm.
- Nominal lower reserve: 15.0 mm.
- Previews: `{"artifacts": ["preview_tapered_fit_gauge.png", "preview_front_profile.png", "preview_side_depth.png", "preview_print_parts.png", "workbench.blend"], "available": true, "exit_code": 0, "requested": true}`

Use `MEASUREMENT_WORKSHEET.md` as the gate for the next full enclosure revision.

# V5 tapered firewall fit-gauge measurement worksheet

Release status: `blocked_pending_direct_vehicle_measurements_fit_gauge_material_hood_slope_vibration_and_temperature_tests`

This all-polymer package is a temporary fit/drill template. It is not a vehicle
bracket, electronics enclosure, or safe underhood installation. Remove it before
driving or closing the hood unless a controlled witness test specifically calls
for that step.

## Mandatory fit-use constraints

- Work only with the engine cold and switched off and the vehicle stationary on a stable surface.
- Independently support the hood before entering the engine bay; do not rely on the gauge or the nearby bodywork as support.
- Install temporary matching hardware hand-snug only. Apply no clamp torque to this polymer gauge.
- Keep the gauge under direct operator supervision for the entire stationary fit check.
- Remove the gauge before starting the engine or driving the vehicle.
- Keep the gauge empty: no electronics, UPS hardware, batteries, wiring, cable glands or cable penetrations, pressure sensors/transducers, refrigerant hoses/fittings, or other pressure hardware.

## Encoded provisional geometry

- Bolt axes in body coordinates: X = +6.735 / +57.265 mm (50.53 mm pitch)
- Pair/adapter midpoint: X = +32.0 mm, mirrored about its own midpoint; tapered-body center remains X = 0
- The selected X=+32.0 mm default is the owner-directed horizontal mirror of the prior approximately 32 mm left-offset relationship.
- Right slot center: X = +57.265 mm, 5.735 mm inside the upper-body right edge
- Slot far edge: X = +64.265 mm; body-edge clearance -1.265 mm (negative means adapter-supported overhang); adapter edge ligament 13.735 mm
- Pair offset that would keep the complete slot inside the body: X ≤ 30.735 mm. This is a geometry threshold, not a safety approval; the 20–42 mm override range is only for physical fit studies.
- The separate flat drill-template STL is pair-local (midpoint X=0) because it contains no body datum; the installed cage, adapter reference, SVG, and previews carry the X=+32.0 mm relationship.
- Left feature: round Ø9.2 mm
- Right feature: horizontal 14.0 × 9.2 mm slot
- Flat outline reference: 92 × 34 mm
- Shoulder: 126 mm wide
- Straight side region: 24 through 66 mm below bolt axis
- Lower end: 76 mm wide at 135 mm drop
- Depth witness: 60 mm maximum; selected rear standoff 9.0 mm; cage body 51.0 mm
- Nominal lower reserve against the reported 150 mm datum: 15.0 mm
- Rear-standoff comparison set: 6/9/12 mm; selected reference 9.0 mm
- Breakaway depth feelers: 45/50/55/60 mm
- Clearance-whisker length is the outermost solid extent normal to its named datum plane: 5.0 mm from the static-side body/profile or coupon-base datum and 10.0 mm from the moving-loom body/profile or coupon-base datum. Embedded roots sit behind the datums and do not add to those calibrated outward extents.

## Record before any enclosure or metal-adapter design

| Check | Measurement / result | Required evidence |
|---|---|---|
| 150 mm datum begins at bolt axis or head bottom | __________ | Photo with ruler/caliper endpoints visible |
| Bolt center pitch | __________ mm | Both contacts seated on defined centers/edges |
| OEM thread, pitch, usable depth | __________ | Thread gauge / known fastener; never force |
| Existing head OD and installed height | __________ mm | Hood-safe low-profile stack |
| Firewall bolt seats coplanar | pass / fail | Straightedge + feeler gauges |
| Candidate lower anti-rock reaction at X=0, Z=-132.0 mm | __________ | Measure panel gap/profile and compliant isolator compression; no hard foot is printed |
| Full-depth hood gap at rear/mid/front, through 60 mm | __________ | Modeling clay or removable witness, hood lowered by hand |
| Taper occurs in firewall plane only | yes / no | Orthogonal side photo / physical gauge |
| Left loom clearance at top/mid/bottom | __________ mm | Static and gently displaced positions |
| Left loom movement/hot/vibration allowance | __________ mm | Selected witness is 10.0 mm. Selected 10.0 mm whisker is a fit probe; the moving-loom release minimum remains ≥10.0 mm even when a smaller legal fit-trial override is printed—do not lower it |
| Right fuse/relay-box clearance | __________ mm | Selected witness is 5.0 mm. Selected 5.0 mm whisker is a fit probe; the static obstacle release minimum remains ≥5.0 mm even when a smaller legal fit-trial override is printed—do not lower it |
| Right-side I/O reservation and connector/tool sweep | __________ | Measure purchased glands, tails, nuts, tools, bend radius |
| Service access/tool sweep | pass / fail | Fuse lids, connectors, and bolt tool |
| Gauge at offsets -10/0/+10 | best: ______ | Photograph each viable position |
| Gauge at rear spacing 6/9/12 mm | best: ______ | Check stamped embossment and depth |

## Controlled fit sequence

1. Print the profile, whisker, and depth-feeler coupons first. Measure each whisker from the coupon base's Y=10 mm outer edge to its outermost tip; verify 5.0/10.0 mm after printer-process compensation.
2. Hold the flat drill template against the panel without tightening; confirm round/slot alignment.
3. With the engine cold, install the light cage only for a stationary fit check. Do not use it as a clamp spacer or structural bracket.
4. Check the entire 60 mm depth against hood, loom, fuse box, harnesses, and service motions.
5. Photograph front, side, top, and bottom views with a scale in frame.
6. Remove the gauge before driving. Record any clipped whisker or witness contact.

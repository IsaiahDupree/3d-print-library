
import json, math, os
import FreeCAD as App
import Part
import MeshPart
from FreeCAD import Vector

P = {'mount_hole_spacing_mm': 50.53, 'mount_hole_d_mm': 9.2, 'mount_slot_length_mm': 14.0, 'mount_pair_offset_x_mm': 32.0, 'adapter_outline_width_mm': 92.0, 'adapter_outline_height_mm': 34.0, 'upper_width_mm': 126.0, 'upper_straight_drop_mm': 66.0, 'lower_width_mm': 76.0, 'total_drop_mm': 135.0, 'maximum_depth_mm': 60.0, 'rear_standoff_mm': 9.0, 'cage_rail_mm': 6.0, 'static_clearance_whisker_mm': 5.0, 'loom_clearance_whisker_mm': 10.0, 'lateral_offset_indicator_mm': 10.0}
FIXED = {'bolt_axis_z_mm': 0.0, 'vehicle_head_envelope_d_mm': 20.0, 'adapter_top_z_mm': 9.0, 'body_top_drop_mm': 24.0, 'adapter_template_thickness_mm': 2.4, 'adapter_reference_thickness_mm': 2.5, 'profile_coupon_thickness_mm': 2.4, 'depth_feeler_thickness_mm': 2.4, 'depth_feeler_width_mm': 5.0, 'breakaway_neck_width_mm': 1.2, 'breakaway_neck_length_mm': 4.0, 'whisker_d_mm': 2.0, 'whisker_root_overlap_mm': 0.4, 'whisker_root_embed_mm': 1.6, 'whisker_geometry_tolerance_mm': 0.01, 'offset_indicator_thickness_mm': 2.4, 'measured_clearance_below_bolt_axis_mm': 150.0, 'minimum_nominal_lower_reserve_mm': 10.0, 'minimum_static_clearance_release_mm': 5.0, 'minimum_moving_loom_clearance_release_mm': 10.0, 'hood_clearance_above_head_min_mm': 5.0, 'hood_clearance_above_head_max_mm': 7.0, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0, 'cage_brim_mm': 12.0, 'flat_part_brim_mm': 6.0, 'depth_feeler_lengths_mm': [45.0, 50.0, 55.0, 60.0], 'interpretation': 'portrait tapered body in the firewall plane; fore/aft pitch is not encoded and must be measured separately', 'material_status': 'unselected; coupon and slicer trials required', 'structural_status': 'NONSTRUCTURAL ALL-POLYMER FIT/DRILL TEMPLATE ONLY; never use as the vehicle load path'}
MECH = {'coordinate_system': {'x': 'vehicle left/right; centerline X=0', 'y': 'away from firewall; rear datum Y=0', 'z': 'up; provisional bolt axis Z=0'}, 'preview_orientation': {'front_camera_azimuth_deg': 180.0, 'assembly_camera_azimuth_deg': 214.0, 'view_side': 'firewall side looking toward positive Y', 'image_right_axis': '+X', 'round_feature_appears_left_of_slot': True, 'shifted_pair_appears_right_of_body_center': True}, 'body_center_x_mm': 0.0, 'mount_pair_midpoint_x_mm': 32.0, 'mount_pair_offset_from_body_center_x_mm': 32.0, 'mount_pair_offset_assumption': 'owner-directed right shift; +X is image-right in the firewall-side front preview; the +32 mm default mirrors the approximately 32 mm left offset visible in the prior render', 'mount_pair_offset_source': 'owner_directed_mirror_of_prior_approximately_minus32_mm', 'prior_render_mirror_claim_applies': True, 'mount_centers_xz_mm': [[6.734999999999999, 0.0], [57.265, 0.0]], 'mount_edge_relationship': {'upper_shoulder_right_edge_x_mm': 63.0, 'right_slot_center_x_mm': 57.265, 'right_slot_center_inset_from_shoulder_edge_mm': 5.734999999999999, 'right_slot_far_edge_x_mm': 64.265, 'right_slot_edge_body_clearance_mm': -1.2650000000000006, 'right_slot_edge_adapter_ligament_mm': 13.735, 'maximum_pair_offset_for_slot_edge_inside_body_mm': 30.735, 'bounded_study_offset_range_mm': [20.0, 42.0], 'range_is_not_a_structural_or_fit_release': True}, 'mount_features': ['round', 'horizontal_slot'], 'adapter_outline_xz_mm': [-14.0, -25.0, 78.0, 9.0], 'body_profile_xz_mm': [[-63.0, -24.0], [63.0, -24.0], [63.0, -66.0], [38.0, -135.0], [-38.0, -135.0], [-63.0, -66.0]], 'straight_upper_side_region_mm': [24.0, 66.0], 'crossbars': [{'drop_mm': 40.0, 'z_mm': -40.0, 'outer_width_mm': 126.0}, {'drop_mm': 66.0, 'z_mm': -66.0, 'outer_width_mm': 126.0}, {'drop_mm': 100.0, 'z_mm': -100.0, 'outer_width_mm': 101.3623188405797}, {'drop_mm': 135.0, 'z_mm': -135.0, 'outer_width_mm': 76.0}], 'standoff_bridge_layout': {'adapter_body_overlap_x_mm': [-11.0, 60.0], 'usable_overlap_span_mm': 71.0, 'bridge_x_positions_mm': [-2.125, 15.625, 33.375, 51.125]}, 'depth_envelope_mm': 60.0, 'body_depth_mm': 51.0, 'rear_standoff_scenarios_mm': [6.0, 9.0, 12.0], 'selected_rear_standoff_mm': 9.0, 'lateral_offset_scenarios_mm': [-10.0, 0.0, 10.0], 'clearance_whiskers_mm': {'static_obstacle': 5.0, 'moving_loom': 10.0}, 'clearance_whisker_datums': {'moving_loom': {'axis': 'x', 'outward_sign': -1, 'coordinate_mm': -58.65217391304348, 'z_mm': -78.0, 'datum_contract': 'tapered_body_profile_side_at_whisker_centerline'}, 'static_obstacle': {'axis': 'x', 'outward_sign': 1, 'coordinate_mm': 50.31884057971014, 'z_mm': -101.0, 'datum_contract': 'tapered_body_profile_side_at_whisker_centerline'}, 'standalone_coupon': {'axis': 'y', 'outward_sign': 1, 'coordinate_mm': 10.0, 'datum_contract': 'coupon_base_outer_edge_y_10_mm'}}, 'clearance_whisker_measurement_contract': {'length_definition': 'outermost_solid_extent_normal_to_named_datum_plane', 'integrated_datum': 'tapered_body_profile_side_at_whisker_centerline', 'coupon_datum': 'coupon_base_outer_edge_y_10_mm', 'root_is_excluded_from_outward_length': True, 'cad_brep_tolerance_mm': 0.01}, 'clearance_release_minima_mm': {'static_obstacle': 5.0, 'moving_loom': 10.0, 'selected_static_witness_meets_minimum': True, 'selected_moving_loom_witness_meets_minimum': True}, 'right_io_reservation': {'side': 'straight upper-right wall', 'status': 'reference_only_pending_purchased_gland_connector_tool_and_cable_bend_measurements', 'printable_cutout': False, 'collision_qualification': False}, 'permanent_mount_load_path_requirement': {'status': 'reference_requirement_only_not_modeled_or_released', 'adapter': 'directly measured formed or gusseted metal adapter with metal compression sleeves; engineering review required', 'polymer_in_permanent_oem_bolt_clamp_path': False}, 'lower_anti_rock_reaction_provision': {'status': 'pending_direct_lower_panel_surface_gap_and_compliant_isolator_compression_measurements', 'candidate_x_mm': 0.0, 'candidate_z_mm': -132.0, 'panel_datum_y_mm': 0.0, 'rear_frame_y_mm': 9.0, 'printable_hard_contact': False, 'reason': 'an inferred hard foot could preload stamped sheet metal or transfer hood/vibration load before the panel surface is measured'}, 'bolt_head_envelope': {'diameter_mm': 20.0, 'lower_z_mm': -10.0, 'upper_z_mm': 10.0}, 'hood_datum_at_bolt_plane_z_mm': 15.0, 'lower_clearance_datum_z_mm': -150.0, 'nominal_lower_reserve_mm': 15.0, 'maximum_installed_polymer_z_mm': 9.0, 'adapter_bottom_z_mm': -25.0, 'interpretation': 'portrait tapered body in the firewall plane; fore/aft pitch is not encoded and must be measured separately'}
PRINT_BRIMS = {'tapered_clearance_cage': 12.0, 'adapter_drill_template': 6.0, 'tapered_profile_coupon': 6.0, 'depth_feeler_comb_45_50_55_60': 6.0, 'lateral_offset_indicator': 6.0, 'clearance_whisker_coupon': 6.0}
CROSSBAR_DROPS = [40.0, 66.0, 100.0, 135.0]
OUT = 'out'
os.makedirs(OUT, exist_ok=True)

def die(message):
    print("CAD_ERROR " + message, flush=True)
    raise RuntimeError(message)

def bbox(shape):
    b = shape.BoundBox
    return {
        "min_mm": [b.XMin, b.YMin, b.ZMin],
        "max_mm": [b.XMax, b.YMax, b.ZMax],
        "size_mm": [b.XLength, b.YLength, b.ZLength],
    }

def assert_valid(name, shape, require_single=False):
    if shape.isNull() or not shape.isValid() or shape.Volume <= 0:
        die("%s is null, invalid, or non-positive volume" % name)
    if require_single and len(shape.Solids) != 1:
        die("%s must be one connected solid; got %d" % (name, len(shape.Solids)))

def export_pair(shape, stem):
    shape.exportStep(os.path.join(OUT, stem + ".step"))
    mesh = MeshPart.meshFromShape(
        Shape=shape, LinearDeflection=0.08,
        AngularDeflection=0.25, Relative=False,
    )
    mesh.write(os.path.join(OUT, stem + ".stl"))

def add_feature(doc, name, label, shape, color, transparency=0):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = shape
    try:
        obj.ViewObject.ShapeColor = color
        obj.ViewObject.Transparency = transparency
    except Exception:
        pass
    return obj

def fuse_all(parts):
    if not parts:
        die("cannot fuse an empty shape list")
    result = parts[0]
    for part in parts[1:]:
        result = result.fuse(part)
    return result.removeSplitter()

def cylinder_between(start, end, radius):
    direction = Vector(
        end[0] - start[0], end[1] - start[1], end[2] - start[2]
    )
    if direction.Length <= 1.0e-6:
        die("zero-length rail")
    return Part.makeCylinder(radius, direction.Length, Vector(*start), direction)

def calibrated_whisker_x(datum_x, outward_sign, y_center, z_center, length):
    """Return one connected witness whose outward X extent is exactly length."""
    if outward_sign not in (-1, 1):
        die("clearance whisker direction must be -1 or +1")
    thickness = FIXED["whisker_d_mm"]
    overlap = FIXED["whisker_root_overlap_mm"]
    embed = FIXED["whisker_root_embed_mm"]
    if outward_sign < 0:
        blade_x = datum_x - length
        root_x = datum_x - overlap
    else:
        blade_x = datum_x
        root_x = datum_x - embed
    blade = Part.makeBox(
        length, thickness, thickness,
        Vector(
            blade_x,
            y_center - thickness / 2.0,
            z_center - thickness / 2.0,
        ),
    )
    root = Part.makeBox(
        embed + overlap, thickness, thickness,
        Vector(
            root_x,
            y_center - thickness / 2.0,
            z_center - thickness / 2.0,
        ),
    )
    return fuse_all([root, blade])

def calibrated_coupon_whisker_y(x_center, datum_y, length, thickness):
    """Return a coupon feeler whose outermost Y is datum_y + length."""
    width = FIXED["breakaway_neck_width_mm"]
    overlap = FIXED["whisker_root_overlap_mm"]
    embed = FIXED["whisker_root_embed_mm"]
    blade = Part.makeBox(
        width, length, thickness,
        Vector(x_center - width / 2.0, datum_y, 0),
    )
    root = Part.makeBox(
        width, embed + overlap, thickness,
        Vector(x_center - width / 2.0, datum_y - embed, 0),
    )
    # Keep a tactile 4 mm-wide head entirely inside the calibrated length; the
    # previous circular head extended 2 mm past it and overstated the witness.
    head_depth = min(FIXED["whisker_d_mm"], length)
    head = Part.makeBox(
        2.0 * FIXED["whisker_d_mm"], head_depth, thickness,
        Vector(
            x_center - FIXED["whisker_d_mm"],
            datum_y + length - head_depth,
            0,
        ),
    )
    return fuse_all([root, blade, head])

def hole_y(cx, cz, diameter, y0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(cx, y0, cz), Vector(0, 1, 0)
    )

def capsule_y(cx, cz, overall, diameter, y0, depth):
    travel = overall - diameter
    left = hole_y(cx - travel / 2.0, cz, diameter, y0, depth)
    right = hole_y(cx + travel / 2.0, cz, diameter, y0, depth)
    bridge = Part.makeBox(
        travel, depth, diameter,
        Vector(cx - travel / 2.0, y0, cz - diameter / 2.0),
    )
    return fuse_all([left, right, bridge])

def hole_z(cx, cy, diameter, z0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(cx, cy, z0), Vector(0, 0, 1)
    )

def capsule_z(cx, cy, overall, diameter, z0, depth):
    travel = overall - diameter
    left = hole_z(cx - travel / 2.0, cy, diameter, z0, depth)
    right = hole_z(cx + travel / 2.0, cy, diameter, z0, depth)
    bridge = Part.makeBox(
        travel, diameter, depth,
        Vector(cx - travel / 2.0, cy - diameter / 2.0, z0),
    )
    return fuse_all([left, right, bridge])

def profile_face_xy(points):
    wire = Part.makePolygon([Vector(x, y, 0) for x, y in points + [points[0]]])
    return Part.Face(wire)

def bed_orient(installed):
    result = installed.copy()
    b = result.BoundBox
    result.translate(Vector(-b.XMin, -b.YMin, -b.ZMin))
    return result

def bed_orient_firewall_face(installed):
    # Put the installed X/Z firewall plane on the printer X/Y bed.  The selected
    # installed Y depth therefore becomes print Z.  Merely translating the
    # installed cage would leave its long X rails as unsupported bridges.
    result = installed.copy()
    result.Placement = App.Placement(
        Vector(0, 0, 0), App.Rotation(Vector(1, 0, 0), 90.0)
    )
    b = result.BoundBox
    result.translate(Vector(-b.XMin, -b.YMin, -b.ZMin))
    return result

AW = P["adapter_outline_width_mm"]
AH = P["adapter_outline_height_mm"]
ADAPTER_TOP = FIXED["adapter_top_z_mm"]
ADAPTER_BOTTOM = ADAPTER_TOP - AH
TEMPLATE_T = FIXED["adapter_template_thickness_mm"]
REF_T = FIXED["adapter_reference_thickness_mm"]
SHOULDER = P["upper_width_mm"]
LOWER = P["lower_width_mm"]
TOP_DROP = FIXED["body_top_drop_mm"]
STRAIGHT_DROP = P["upper_straight_drop_mm"]
BOTTOM_DROP = P["total_drop_mm"]
DEPTH = P["maximum_depth_mm"]
STANDOFF = P["rear_standoff_mm"]
BODY_DEPTH = DEPTH - STANDOFF
RAIL = P["cage_rail_mm"]
R = RAIL / 2.0
MOUNT_OFFSET = P["mount_pair_offset_x_mm"]
LEFT_X = MOUNT_OFFSET - P["mount_hole_spacing_mm"] / 2.0
RIGHT_X = MOUNT_OFFSET + P["mount_hole_spacing_mm"] / 2.0
TEMPLATE_LEFT_X = -P["mount_hole_spacing_mm"] / 2.0
TEMPLATE_RIGHT_X = P["mount_hole_spacing_mm"] / 2.0

# Installed sacrificial mount/drill plate.  It reaches only Z=+9 mm, inside the
# conservative bolt-head upper tangent at Z=+10 mm.  This is explicitly not a
# bracket and is never the released vehicle load path.
adapter_raw = Part.makeBox(
    AW, REF_T, AH, Vector(MOUNT_OFFSET - AW / 2.0, 0, ADAPTER_BOTTOM)
)
mount_cuts = fuse_all([
    hole_y(LEFT_X, 0.0, P["mount_hole_d_mm"], -0.1, REF_T + 0.2),
    capsule_y(
        RIGHT_X, 0.0, P["mount_slot_length_mm"], P["mount_hole_d_mm"],
        -0.1, REF_T + 0.2,
    ),
])
adapter_reference = adapter_raw.cut(mount_cuts).removeSplitter()

# Tapered reference envelope from the marked-up front silhouette, extruded
# through the maximum proposed depth.  It is a keepout/reference volume only.
profile_xz = [
    (-SHOULDER / 2.0, -TOP_DROP),
    (SHOULDER / 2.0, -TOP_DROP),
    (SHOULDER / 2.0, -STRAIGHT_DROP),
    (LOWER / 2.0, -BOTTOM_DROP),
    (-LOWER / 2.0, -BOTTOM_DROP),
    (-SHOULDER / 2.0, -STRAIGHT_DROP),
]
profile_wire_xz = Part.makePolygon(
    [Vector(x, 0, z) for x, z in profile_xz + [profile_xz[0]]]
)
tapered_envelope_face = Part.Face(profile_wire_xz)
tapered_envelope_face.translate(Vector(0, STANDOFF, 0))
tapered_envelope = tapered_envelope_face.extrude(Vector(0, BODY_DEPTH, 0))

# Rear and front X/Z perimeter frames.
rear_y = STANDOFF
front_y = DEPTH - RAIL
shoulder_center = SHOULDER / 2.0 - R
lower_center = LOWER / 2.0 - R

def horizontal_bar(width, y0, z_center):
    return Part.makeBox(
        width, RAIL, RAIL,
        Vector(-width / 2.0, y0, z_center - R),
    )

frame_parts = []
for y0 in (rear_y, front_y):
    frame_parts.extend([
        # Perimeter rails sit *inside* the reference silhouette: the top rail's
        # upper tangent is -TOP_DROP and the bottom rail's lower tangent is
        # -BOTTOM_DROP.  This keeps the physical gauge at the selected total
        # drop rather than adding half a rail below it.
        horizontal_bar(SHOULDER, y0, -TOP_DROP - R),
        horizontal_bar(SHOULDER, y0, -STRAIGHT_DROP),
        horizontal_bar(LOWER, y0, -BOTTOM_DROP + R),
        cylinder_between(
            (-shoulder_center, y0 + R, -TOP_DROP - R),
            (-shoulder_center, y0 + R, -STRAIGHT_DROP), R,
        ),
        cylinder_between(
            (shoulder_center, y0 + R, -TOP_DROP - R),
            (shoulder_center, y0 + R, -STRAIGHT_DROP), R,
        ),
        cylinder_between(
            (-shoulder_center, y0 + R, -STRAIGHT_DROP),
            (-lower_center, y0 + R, -BOTTOM_DROP + R), R,
        ),
        cylinder_between(
            (shoulder_center, y0 + R, -STRAIGHT_DROP),
            (lower_center, y0 + R, -BOTTOM_DROP + R), R,
        ),
    ])

# Intermediate crossbars keep the gauge readable against the photographed
# obstructions and stiffen its very low-material outline.
for drop in CROSSBAR_DROPS:
    if (
        TOP_DROP < drop < BOTTOM_DROP
        and abs(drop - STRAIGHT_DROP) > 1.0e-6
    ):
        half = SHOULDER / 2.0
        if drop > STRAIGHT_DROP:
            fraction = (drop - STRAIGHT_DROP) / (BOTTOM_DROP - STRAIGHT_DROP)
            half += fraction * (LOWER / 2.0 - SHOULDER / 2.0)
        for y0 in (rear_y, front_y):
            frame_parts.append(horizontal_bar(2.0 * half, y0, -drop))

# Depth rails at the shoulder, taper start, and bottom corners make the cage a
# true panel-to-front depth witness instead of a flat silhouette.
depth_points = [
    (-shoulder_center, -TOP_DROP - R), (shoulder_center, -TOP_DROP - R),
    (-shoulder_center, -STRAIGHT_DROP), (shoulder_center, -STRAIGHT_DROP),
    (-lower_center, -BOTTOM_DROP + R), (lower_center, -BOTTOM_DROP + R),
]
for x, z in depth_points:
    frame_parts.append(cylinder_between(
        (x, rear_y + R, z), (x, DEPTH - R, z), R
    ))

# Four side-plane diagonal braces oppose rack without crossing the open front
# or implying an electronics panel.
frame_parts.extend([
    cylinder_between(
        (-shoulder_center, rear_y + R, -STRAIGHT_DROP),
        (-lower_center, DEPTH - R, -BOTTOM_DROP + R), R * 0.62,
    ),
    cylinder_between(
        (-shoulder_center, DEPTH - R, -STRAIGHT_DROP),
        (-lower_center, rear_y + R, -BOTTOM_DROP + R), R * 0.62,
    ),
    cylinder_between(
        (shoulder_center, rear_y + R, -STRAIGHT_DROP),
        (lower_center, DEPTH - R, -BOTTOM_DROP + R), R * 0.62,
    ),
    cylinder_between(
        (shoulder_center, DEPTH - R, -STRAIGHT_DROP),
        (lower_center, rear_y + R, -BOTTOM_DROP + R), R * 0.62,
    ),
])

# Four light sacrificial bridges make the selected rear standoff a
# real, testable geometric choice.  They overlap the polymer drill plate and
# rear shoulder frame but must never be interpreted as a permanent clamp path.
bridge_overlap_min, bridge_overlap_max = MECH[
    "standoff_bridge_layout"
]["adapter_body_overlap_x_mm"]
if bridge_overlap_max - bridge_overlap_min < 12.0:
    die("shifted adapter lacks enough overlap for sacrificial standoff bridges")
bridge_xs = MECH["standoff_bridge_layout"]["bridge_x_positions_mm"]
standoff_bridges = [
    cylinder_between(
        (x, 1.0, ADAPTER_BOTTOM + 2.5),
        (x, rear_y + R, -TOP_DROP - R + 1.0),
        2.0,
    )
    for x in bridge_xs
]

# Thin side webs spread handling loads around each sacrificial bridge so the
# fit gauge survives installation.  They are print-survival gussets only, not a
# claim that a polymer or identically shaped metal adapter is structurally safe.
gusset_width = max(2.4, RAIL * 0.45)
standoff_gussets = []
for x in bridge_xs:
    x0 = x - gusset_width / 2.0
    gusset_points = [
        Vector(x0, 0.5, ADAPTER_BOTTOM + 0.5),
        Vector(x0, max(0.6, REF_T - 0.2), ADAPTER_BOTTOM + 7.0),
        Vector(x0, rear_y + RAIL - 0.5, -TOP_DROP - 0.5),
        Vector(x0, rear_y + 0.5, -TOP_DROP - RAIL + 0.5),
    ]
    gusset_wire = Part.makePolygon(gusset_points + [gusset_points[0]])
    standoff_gussets.append(
        Part.Face(gusset_wire).extrude(Vector(gusset_width, 0, 0))
    )

# Three center indicators map the resolved negative/zero/positive lateral
# alternatives.  They remain below the adapter/head region and are easy to clip.
offset = P["lateral_offset_indicator_mm"]
offset_tabs = []
for index, x in enumerate((-offset, 0.0, offset)):
    length = 7.0 + index * 2.0
    offset_tabs.append(Part.makeBox(
        2.0, RAIL, length,
        Vector(x - 1.0, rear_y, -TOP_DROP - length + R),
    ))

# Sacrificial radial fingers show the requested static and loom margins.  Each
# box blade starts at the named body-profile side datum and ends at exactly the
# selected outward distance.  A separate root embeds behind that datum while
# overlapping only the measured blade, so it cannot lengthen the witness.
# These are clearance concepts, not collision proof; loom motion remains unknown.
whisker_datums = MECH["clearance_whisker_datums"]
loom_datum = whisker_datums["moving_loom"]
static_datum = whisker_datums["static_obstacle"]
loom_z = loom_datum["z_mm"]
static_z = static_datum["z_mm"]
loom_half = -loom_datum["coordinate_mm"]
static_half = static_datum["coordinate_mm"]
whiskers = [
    calibrated_whisker_x(
        -loom_half, -1, DEPTH - R, loom_z,
        P["loom_clearance_whisker_mm"],
    ),
    calibrated_whisker_x(
        static_half, 1, DEPTH - R, static_z,
        P["static_clearance_whisker_mm"],
    ),
]

# The shifted adapter does not directly meet the centered rear shoulder frame.
# The four sacrificial bridges and their thin print-survival gussets create the
# only physical connection between those two fit-gauge regions.
cage_installed = fuse_all(
    [adapter_reference]
    + frame_parts
    + standoff_bridges
    + standoff_gussets
    + offset_tabs
    + whiskers
)

# Bed-oriented printable cage; installed-coordinate reference is emitted
# separately so STEP users cannot silently confuse the two coordinate frames.
cage_print = bed_orient_firewall_face(cage_installed)

# Flat drill template: the resolved adapter outline and exact round/slot pattern,
# laid on the print bed.  The printed piece locates holes only; it is not a
# metal-adapter thickness recommendation.
template_raw = Part.makeBox(AW, AH, TEMPLATE_T, Vector(-AW / 2.0, 0, 0))
template_cuts = fuse_all([
    hole_z(
        TEMPLATE_LEFT_X, -ADAPTER_BOTTOM, P["mount_hole_d_mm"],
        -0.1, TEMPLATE_T + 0.2,
    ),
    capsule_z(
        TEMPLATE_RIGHT_X, -ADAPTER_BOTTOM, P["mount_slot_length_mm"],
        P["mount_hole_d_mm"], -0.1, TEMPLATE_T + 0.2,
    ),
])
adapter_template = template_raw.cut(template_cuts).removeSplitter()

# One-to-one front-profile coupon.  Y is downward drop from the body shoulder,
# and the full face remains intentionally thin and flat.
coupon_height = BOTTOM_DROP - TOP_DROP
coupon_points = [
    (-SHOULDER / 2.0, 0.0), (SHOULDER / 2.0, 0.0),
    (SHOULDER / 2.0, STRAIGHT_DROP - TOP_DROP),
    (LOWER / 2.0, coupon_height), (-LOWER / 2.0, coupon_height),
    (-SHOULDER / 2.0, STRAIGHT_DROP - TOP_DROP),
]
profile_coupon = profile_face_xy(coupon_points).extrude(
    Vector(0, 0, FIXED["profile_coupon_thickness_mm"])
)

# Four independent breakaway feelers share a base.  Their outer tips sit at
# exactly 45/50/55/60 mm from the rear datum edge of the base.
feeler_lengths = FIXED["depth_feeler_lengths_mm"]
base_w = 74.0
base_h = 10.0
feeler_t = FIXED["depth_feeler_thickness_mm"]
feeler_parts = [Part.makeBox(base_w, base_h, feeler_t, Vector(0, 0, 0))]
feeler_xs = [8.0, 26.0, 44.0, 62.0]
for x, length in zip(feeler_xs, feeler_lengths):
    neck_w = FIXED["breakaway_neck_width_mm"]
    neck_l = FIXED["breakaway_neck_length_mm"]
    blade_w = FIXED["depth_feeler_width_mm"]
    feeler_parts.append(Part.makeBox(
        neck_w, neck_l, feeler_t,
        Vector(x - neck_w / 2.0, base_h - 0.2, 0),
    ))
    feeler_parts.append(Part.makeBox(
        blade_w, length - base_h - neck_l + 0.4, feeler_t,
        Vector(x - blade_w / 2.0, base_h + neck_l - 0.4, 0),
    ))
depth_feeler_comb = fuse_all(feeler_parts)

# Separate tactile indicator coupon: three stems terminate at the resolved
# negative/zero/positive offsets.  Unequal heads make the options readable
# even before embossed text is added in a future measured revision.
indicator_t = FIXED["offset_indicator_thickness_mm"]
indicator = Part.makeBox(54.0, 8.0, indicator_t, Vector(-27.0, 0, 0))
for index, x in enumerate((-offset, 0.0, offset)):
    indicator = indicator.fuse(Part.makeBox(
        3.0 + index, 12.0 + index * 3.0, indicator_t,
        Vector(x - (3.0 + index) / 2.0, 6.0, 0),
    ))
offset_indicator = indicator.removeSplitter()

# Standalone resolved-clearance whisker coupon lets the print/material pair be
# checked before relying on the sacrificial fingers integrated into the cage.
# Y=10 is the named base-edge datum.  Both heads terminate within, rather than
# beyond, their selected 5/10 mm (or overridden) outward extents.
whisker_coupon_datum_y = whisker_datums["standalone_coupon"]["coordinate_mm"]
whisker_coupon_base = Part.makeBox(
    42.0, whisker_coupon_datum_y, 2.4, Vector(0, 0, 0)
)
coupon_whiskers = [
    calibrated_coupon_whisker_y(
        12.0, whisker_coupon_datum_y,
        P["static_clearance_whisker_mm"], 2.4,
    ),
    calibrated_coupon_whisker_y(
        30.0, whisker_coupon_datum_y,
        P["loom_clearance_whisker_mm"], 2.4,
    ),
]
whisker_coupon = fuse_all([whisker_coupon_base] + coupon_whiskers)

# Reference-only datums.  The hood slab is merely a bolt-plane extrapolation;
# the actual full-depth hood surface/slope is explicitly unknown.
head_depth = 8.0
bolt_heads = Part.makeCompound([
    Part.makeCylinder(
        FIXED["vehicle_head_envelope_d_mm"] / 2.0, head_depth,
        Vector(x, -head_depth, 0), Vector(0, 1, 0),
    )
    for x in (LEFT_X, RIGHT_X)
])
hood_datum = Part.makeBox(
    SHOULDER + 20.0, DEPTH, 1.0,
    Vector(-(SHOULDER + 20.0) / 2.0, 0,
           MECH["hood_datum_at_bolt_plane_z_mm"]),
)
lower_datum = Part.makeBox(
    SHOULDER + 20.0, DEPTH, 1.0,
    Vector(-(SHOULDER + 20.0) / 2.0, 0,
           MECH["lower_clearance_datum_z_mm"] - 1.0),
)

# Reference-only right-side I/O reservation.  This colored patch identifies a
# candidate zone on the straight upper-right wall but cuts no printable part
# and makes no connector, tool, strain-relief, or cable-bend clearance claim.
io_patch_y = STANDOFF + 5.0
io_patch_depth = max(8.0, BODY_DEPTH - 10.0)
io_patch_height = min(24.0, STRAIGHT_DROP - TOP_DROP - 12.0)
right_io_reservation = Part.makeBox(
    2.0, io_patch_depth, io_patch_height,
    Vector(SHOULDER / 2.0 - 2.0, io_patch_y, -STRAIGHT_DROP + 5.0),
)

shapes = {
    "tapered_clearance_cage": cage_print,
    "adapter_drill_template": bed_orient(adapter_template),
    "tapered_profile_coupon": bed_orient(profile_coupon),
    "depth_feeler_comb_45_50_55_60": bed_orient(depth_feeler_comb),
    "lateral_offset_indicator": bed_orient(offset_indicator),
    "clearance_whisker_coupon": bed_orient(whisker_coupon),
    "reference_tapered_clearance_cage_installed": cage_installed,
    "reference_tapered_envelope": tapered_envelope,
    "reference_adapter_outline": adapter_reference,
    "reference_bolt_head_keepouts": bolt_heads,
    "reference_hood_bolt_plane_datum": hood_datum,
    "reference_150mm_lower_datum": lower_datum,
    "reference_right_io_reservation": right_io_reservation,
}

for name, shape in shapes.items():
    assert_valid(name, shape, require_single=(name in PRINT_BRIMS))
    export_pair(shape, name)

assembly = Part.makeCompound([
    cage_installed, tapered_envelope, bolt_heads, hood_datum, lower_datum,
    right_io_reservation,
])
assert_valid("assembly", assembly)
export_pair(assembly, "assembly")

doc = App.newDocument("AC_Tapered_Fit_Gauge_V5")
add_feature(
    doc, "FitGauge", "NONSTRUCTURAL tapered fit gauge",
    cage_installed, (0.95, 0.55, 0.08), 0,
)
add_feature(
    doc, "TaperedEnvelope", "Reference-only proposed enclosure envelope",
    tapered_envelope, (0.18, 0.48, 0.85), 78,
)
add_feature(
    doc, "BoltHeadKeepouts", "Conservative bolt-head envelopes",
    bolt_heads, (0.82, 0.16, 0.10), 10,
)
add_feature(
    doc, "HoodDatum", "Bolt-plane-only hood datum extrapolation",
    hood_datum, (0.95, 0.76, 0.10), 65,
)
add_feature(
    doc, "LowerDatum", "Owner-reported 150 mm lower datum",
    lower_datum, (0.76, 0.12, 0.10), 65,
)
add_feature(
    doc, "RightIOReservation",
    "REFERENCE ONLY: right I/O zone pending purchased hardware measurements",
    right_io_reservation, (0.82, 0.14, 0.72), 35,
)
doc.recompute()
doc.saveAs(os.path.join(OUT, "assembly.FCStd"))

shape_validation = {
    name: {
        "valid": not shape.isNull() and shape.isValid() and shape.Volume > 0,
        "solid_count": len(shape.Solids),
        "volume_mm3": shape.Volume,
        "bbox": bbox(shape),
    }
    for name, shape in shapes.items()
}

print_volume_checks = []
for name, brim in PRINT_BRIMS.items():
    b = shapes[name].BoundBox
    required_radius = math.hypot(b.XLength, b.YLength) / 2.0 + brim
    row = {
        "part": name,
        "size_mm": [b.XLength, b.YLength, b.ZLength],
        "bed_z_min_mm": b.ZMin,
        "brim_mm": brim,
        "required_radius_mm": required_radius,
        "pass": (
            abs(b.ZMin) <= 0.01
            and required_radius <= FIXED["v400_bed_diameter_mm"] / 2.0 + 0.01
            and b.ZLength <= FIXED["v400_height_mm"] + 0.01
        ),
    }
    print_volume_checks.append(row)
    if not row["pass"]:
        die("%s does not fit the FLSUN V400 print contract" % name)

installed_bbox = cage_installed.BoundBox
if installed_bbox.ZMax > FIXED["vehicle_head_envelope_d_mm"] / 2.0 + 0.01:
    die("installed polymer rises above bolt-head envelope")
if installed_bbox.YLength > P["maximum_depth_mm"] + 0.01:
    die("installed gauge exceeds selected depth envelope")

# Probe the emitted finished BReps rather than restating the requested mount
# dimensions.  raw - finished isolates the actual voids left in each adapter;
# narrow local windows then separate the round opening from the slot.  This
# catches a cut-axis, placement, fusion, or template-coordinate regression.
def probe_mount_void(
    part_name, feature, raw_plate, finished_shape, expected_center_xz,
    expected_size_xz, vertical_axis, outer_side, plate_thickness,
):
    voids = raw_plate.cut(finished_shape).removeSplitter()
    if voids.isNull() or voids.Volume <= 0:
        die("%s has no measurable mount voids" % part_name)

    window_width = expected_size_xz[0] + 2.0
    rb = raw_plate.BoundBox
    if vertical_axis == "z":
        window = Part.makeBox(
            window_width, rb.YLength + 2.0, rb.ZLength + 2.0,
            Vector(
                expected_center_xz[0] - window_width / 2.0,
                rb.YMin - 1.0,
                rb.ZMin - 1.0,
            ),
        )
    elif vertical_axis == "y":
        window = Part.makeBox(
            window_width, rb.YLength + 2.0, rb.ZLength + 2.0,
            Vector(
                expected_center_xz[0] - window_width / 2.0,
                rb.YMin - 1.0,
                rb.ZMin - 1.0,
            ),
        )
    else:
        die("unknown mount-probe vertical axis")

    isolated = voids.common(window).removeSplitter()
    if isolated.isNull() or not isolated.isValid() or isolated.Volume <= 0:
        die("%s %s void probe is invalid" % (part_name, feature))
    vb = isolated.BoundBox

    if vertical_axis == "z":
        actual_center_vertical = (vb.ZMin + vb.ZMax) / 2.0
        actual_vertical_size = vb.ZLength
        through_depth = vb.YLength
        top_ligament = rb.ZMax - vb.ZMax
        bottom_ligament = vb.ZMin - rb.ZMin
    else:
        # The bed-flat drill template uses Y for installed Z.  Convert back to
        # the common bolt-axis datum so its independently printable geometry
        # can be compared directly with the installed adapter.
        actual_center_vertical = (
            (vb.YMin + vb.YMax) / 2.0 + ADAPTER_BOTTOM
        )
        actual_vertical_size = vb.YLength
        through_depth = vb.ZLength
        top_ligament = rb.YMax - vb.YMax
        bottom_ligament = vb.YMin - rb.YMin

    actual_center = [(vb.XMin + vb.XMax) / 2.0, actual_center_vertical]
    actual_size = [vb.XLength, actual_vertical_size]
    left_ligament = vb.XMin - rb.XMin
    right_ligament = rb.XMax - vb.XMax
    outer_ligament = left_ligament if outer_side == "left" else right_ligament
    perimeter_min = min(
        left_ligament, right_ligament, top_ligament, bottom_ligament
    )
    center_error = max(
        abs(actual_center[index] - expected_center_xz[index])
        for index in range(2)
    )
    size_error = max(
        abs(actual_size[index] - expected_size_xz[index])
        for index in range(2)
    )
    if feature == "round":
        expected_section_area = math.pi * (expected_size_xz[0] / 2.0) ** 2
    elif feature == "horizontal_slot":
        expected_section_area = (
            math.pi * (expected_size_xz[1] / 2.0) ** 2
            + (expected_size_xz[0] - expected_size_xz[1])
            * expected_size_xz[1]
        )
    else:
        die("unknown mount-probe feature")
    expected_void_volume = expected_section_area * plate_thickness
    actual_section_area = isolated.Volume / through_depth
    section_area_error = abs(actual_section_area - expected_section_area)
    void_volume_error = abs(isolated.Volume - expected_void_volume)
    section_area_tolerance = max(0.05, expected_section_area * 0.002)
    void_volume_tolerance = max(0.10, expected_void_volume * 0.003)
    tolerance = 0.03
    topology_pass = len(isolated.Solids) == 1
    through_pass = through_depth >= plate_thickness - tolerance
    geometry_pass = center_error <= tolerance and size_error <= tolerance
    section_area_pass = section_area_error <= section_area_tolerance
    void_volume_pass = void_volume_error <= void_volume_tolerance
    ligament_pass = (
        outer_ligament >= 5.0 - tolerance
        and bottom_ligament >= 5.0 - tolerance
        and perimeter_min >= 4.0 - tolerance
    )
    row = {
        "part": part_name,
        "feature": feature,
        "measurement_source": (
            "derived_from_raw_plate_minus_finished_brep_local_void_bbox"
        ),
        "coordinate_frame": (
            "installed; body centerline X=0"
            if vertical_axis == "z"
            else "part-local; pair midpoint X=0"
        ),
        "center_xz_mm": actual_center,
        "size_xz_mm": actual_size,
        "expected_center_xz_mm": expected_center_xz,
        "expected_size_xz_mm": expected_size_xz,
        "center_max_error_mm": center_error,
        "size_max_error_mm": size_error,
        "through_plate_depth_mm": through_depth,
        "plate_thickness_mm": plate_thickness,
        "void_solid_count": len(isolated.Solids),
        "void_volume_mm3": isolated.Volume,
        "expected_void_volume_mm3": expected_void_volume,
        "void_volume_error_mm3": void_volume_error,
        "void_volume_tolerance_mm3": void_volume_tolerance,
        "actual_void_section_area_mm2": actual_section_area,
        "expected_void_section_area_mm2": expected_section_area,
        "void_section_area_error_mm2": section_area_error,
        "void_section_area_tolerance_mm2": section_area_tolerance,
        "ligaments_mm": {
            "left": left_ligament,
            "right": right_ligament,
            "top": top_ligament,
            "bottom": bottom_ligament,
            "outer": outer_ligament,
            "minimum_to_plate_edge": perimeter_min,
        },
        "topology_pass": topology_pass,
        "geometry_pass": geometry_pass,
        "void_section_area_pass": section_area_pass,
        "void_volume_pass": void_volume_pass,
        "through_plate_pass": through_pass,
        "ligament_pass": ligament_pass,
        "pass": geometry_pass and through_pass and ligament_pass and (
            topology_pass and section_area_pass and void_volume_pass
        ),
    }
    if not row["pass"]:
        die("%s %s emitted mount-void audit failed" % (part_name, feature))
    return row

mount_feature_geometry_checks = [
    probe_mount_void(
        "adapter_drill_template", "round", template_raw, adapter_template,
        [TEMPLATE_LEFT_X, 0.0],
        [P["mount_hole_d_mm"], P["mount_hole_d_mm"]],
        "y", "left", TEMPLATE_T,
    ),
    probe_mount_void(
        "adapter_drill_template", "horizontal_slot", template_raw,
        adapter_template, [TEMPLATE_RIGHT_X, 0.0],
        [P["mount_slot_length_mm"], P["mount_hole_d_mm"]],
        "y", "right", TEMPLATE_T,
    ),
    probe_mount_void(
        "tapered_clearance_cage", "round", adapter_raw, cage_installed,
        [LEFT_X, 0.0], [P["mount_hole_d_mm"], P["mount_hole_d_mm"]],
        "z", "left", REF_T,
    ),
    probe_mount_void(
        "tapered_clearance_cage", "horizontal_slot", adapter_raw,
        cage_installed, [RIGHT_X, 0.0],
        [P["mount_slot_length_mm"], P["mount_hole_d_mm"]],
        "z", "right", REF_T,
    ),
]

# Measure the feature BReps that are actually fused into the cage and coupon.
# The contract is an outward extent from a named datum plane, not an overall
# root-to-tip span: the embedded root is deliberately excluded.
def probe_clearance_whisker(
    scope, feature, shape, datum_coordinate, axis, outward_sign,
    expected_length, datum_contract,
):
    if axis not in ("x", "y") or outward_sign not in (-1, 1):
        die("unknown clearance-whisker audit axis or direction")
    assert_valid(scope + "_" + feature + "_whisker", shape, require_single=True)
    b = shape.BoundBox
    axis_min = b.XMin if axis == "x" else b.YMin
    axis_max = b.XMax if axis == "x" else b.YMax
    if outward_sign < 0:
        actual_length = datum_coordinate - axis_min
        root_embed = axis_max - datum_coordinate
        outer_coordinate = axis_min
    else:
        actual_length = axis_max - datum_coordinate
        root_embed = datum_coordinate - axis_min
        outer_coordinate = axis_max
    error = abs(actual_length - expected_length)
    tolerance = FIXED["whisker_geometry_tolerance_mm"]
    length_pass = error <= tolerance
    root_pass = root_embed >= FIXED["whisker_root_embed_mm"] - tolerance
    row = {
        "scope": scope,
        "feature": feature,
        "measurement_source": (
            "individual_feature_brep_outer_bbox_from_named_datum_plane"
        ),
        "datum_contract": datum_contract,
        "axis": axis,
        "outward_sign": outward_sign,
        "datum_coordinate_mm": datum_coordinate,
        "outer_coordinate_mm": outer_coordinate,
        "requested_outward_extent_mm": expected_length,
        "actual_outward_extent_mm": actual_length,
        "outward_extent_error_mm": error,
        "geometry_tolerance_mm": tolerance,
        "root_embed_behind_datum_mm": root_embed,
        "feature_solid_count": len(shape.Solids),
        "length_pass": length_pass,
        "root_embed_pass": root_pass,
        "single_solid_pass": len(shape.Solids) == 1,
        "pass": length_pass and root_pass and len(shape.Solids) == 1,
    }
    if not row["pass"]:
        die("%s %s clearance-whisker geometry drifted" % (scope, feature))
    return row

clearance_whisker_geometry_checks = [
    probe_clearance_whisker(
        "integrated_cage", "moving_loom", whiskers[0], -loom_half,
        "x", -1, P["loom_clearance_whisker_mm"],
        loom_datum["datum_contract"],
    ),
    probe_clearance_whisker(
        "integrated_cage", "static_obstacle", whiskers[1], static_half,
        "x", 1, P["static_clearance_whisker_mm"],
        static_datum["datum_contract"],
    ),
    probe_clearance_whisker(
        "standalone_coupon", "static_obstacle", coupon_whiskers[0],
        whisker_coupon_datum_y, "y", 1,
        P["static_clearance_whisker_mm"],
        whisker_datums["standalone_coupon"]["datum_contract"],
    ),
    probe_clearance_whisker(
        "standalone_coupon", "moving_loom", coupon_whiskers[1],
        whisker_coupon_datum_y, "y", 1,
        P["loom_clearance_whisker_mm"],
        whisker_datums["standalone_coupon"]["datum_contract"],
    ),
]

result = {
    "status": "pass",
    "shape_validation": shape_validation,
    "print_volume_checks": print_volume_checks,
    "mount_feature_geometry_checks": mount_feature_geometry_checks,
    "clearance_whisker_geometry_checks": clearance_whisker_geometry_checks,
    "fit_gauge": {
        "installed_bbox": bbox(cage_installed),
        "reference_envelope_bbox": bbox(tapered_envelope),
        "diagonal_brace_count": 4,
        "depth_rail_count": len(depth_points),
        "crossbar_drops_mm": CROSSBAR_DROPS,
        "depth_feeler_lengths_mm": feeler_lengths,
        "lateral_offsets_mm": MECH["lateral_offset_scenarios_mm"],
        "clearance_whiskers_mm": MECH["clearance_whiskers_mm"],
        "clearance_whisker_measurement_contract": MECH[
            "clearance_whisker_measurement_contract"
        ],
        "maximum_installed_polymer_z_mm": installed_bbox.ZMax,
        "lower_reserve_mm": MECH["nominal_lower_reserve_mm"],
        "rear_standoff_mm": STANDOFF,
        "body_depth_mm": BODY_DEPTH,
        "standoff_bridge_count": len(standoff_bridges),
        "standoff_gusset_count": len(standoff_gussets),
        "standoff_gusset_status": (
            "nonstructural_polymer_fit_gauge_print_survival_only"
        ),
        "mount_pair_midpoint_x_mm": (LEFT_X + RIGHT_X) / 2.0,
        "adapter_center_x_mm": (
            adapter_reference.BoundBox.XMin + adapter_reference.BoundBox.XMax
        ) / 2.0,
        "bridge_x_positions_mm": bridge_xs,
        "bridge_overlap_connectivity_contract": {
            "adapter_body_overlap_x_mm": [
                bridge_overlap_min, bridge_overlap_max,
            ],
            "all_bridge_axes_inside_overlap": all(
                bridge_overlap_min <= x <= bridge_overlap_max for x in bridge_xs
            ),
            "bridge_count_matches": len(standoff_bridges) == 4,
            "installed_cage_single_solid": len(cage_installed.Solids) == 1,
            "pass": (
                all(bridge_overlap_min <= x <= bridge_overlap_max for x in bridge_xs)
                and len(standoff_bridges) == 4
                and len(cage_installed.Solids) == 1
            ),
        },
    },
    "release": 'blocked_pending_direct_vehicle_measurements_fit_gauge_material_hood_slope_vibration_and_temperature_tests',
}
with open(os.path.join(OUT, "freecad_result.json"), "w", encoding="utf-8") as handle:
    json.dump(result, handle, indent=2, sort_keys=True)
print("CAD_OK tapered V5 fit gauge", flush=True)

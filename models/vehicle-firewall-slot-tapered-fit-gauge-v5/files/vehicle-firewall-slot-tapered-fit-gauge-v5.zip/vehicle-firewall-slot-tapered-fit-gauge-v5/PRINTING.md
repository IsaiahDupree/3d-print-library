# FLSUN V400 print guide — V5 tapered fit gauge

These parts are temporary measurement tools. They are not certified underhood
components and must not be left installed for driving.

Mandatory use conditions: the engine must be cold and switched off, the vehicle
must remain stationary, and the hood must be independently supported. Install
temporary matching hardware hand-snug only with no clamp torque, keep the gauge
under direct operator supervision, and remove it before starting the engine or
driving. This is an empty geometry gauge: do not install electronics, UPS
hardware, batteries, wiring, cable glands or cable penetrations, pressure
sensors/transducers, refrigerant hoses/fittings, or other pressure hardware.

The CAD whiskers reproduce the selected fit-study overrides as outermost-solid
extents from named datum planes. The coupon datum is the base's Y=10 mm edge;
embedded roots are excluded from the calibrated outward length. Measure the
printed result because extrusion and material shrink can change it. Regardless
of those selected lengths, any later release still requires at least
5.0 mm static clearance and
10.0 mm moving-loom clearance.

| STL | Orientation | Brim | Purpose |
|---|---|---:|---|
| `tapered_profile_coupon.stl` | flat | 6 mm | Verify 126→76 mm silhouette first |
| `clearance_whisker_coupon.stl` | flat | 6 mm | Measure from the base's Y=10 mm outer edge to each outermost tip; verify 5/10 mm after process compensation |
| `depth_feeler_comb_45_50_55_60.stl` | flat | 6 mm | Check 45/50/55/60 mm depth before cage |
| `adapter_drill_template.stl` | flat | 6 mm | Check 50.53 mm-pitch round/slot pattern |
| `lateral_offset_indicator.stl` | flat | 6 mm | Compare -10/0/+10 mm candidates |
| `tapered_clearance_cage.stl` | firewall X/Z face flat; installed depth prints upward | 12 mm | Final stationary fit trial |

Suggested starting slicer settings: 0.20 mm layers, 0.4 mm nozzle, four walls,
five top/bottom layers, 20% gyroid, and slow first layers. The cage footprint is
the union of the centered 126→76 mm front silhouette and the
92 mm adapter shifted to X=+32.0 mm; its build height is the configured
60 mm depth. PETG or ASA is more
suitable for a brief controlled engine-bay trial than PLA, but material remains
unqualified. Inspect every layer preview, especially the diagonal rails,
breakaway whiskers, four bridge/gusset pairs, and cage-to-adapter overlap. These
gussets improve fit-gauge handling durability only; they do not qualify a
permanent polymer or metal load path.

Measure the printed round hole, slot width/length, bolt pitch, shoulder width,
bottom width, 45/50/55/60 mm feelers, and 60 mm cage depth before approaching
the vehicle. Do not force a fastener through a print and do not close the hood
against a hard gauge; lower it by hand onto removable soft witness material.

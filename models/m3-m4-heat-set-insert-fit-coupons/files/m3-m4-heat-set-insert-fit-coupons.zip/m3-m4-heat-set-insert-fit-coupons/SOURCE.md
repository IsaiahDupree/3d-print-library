# Source and checks

These are the original R3.service.2 test pieces from the service-arm project. Orion checked the exact STL meshes and compared them with the editable STEP geometry. The CAD and mesh audits identify the released geometry.

- Native source job `mdl_0a1b357c11484d29`
- Mesh integrity job `mdl_3188b494d4fd486a`

| File | SHA-256 |
| --- | --- |
| coupon_M3_pilot_3p8_horizontal.step | `84a20e107455d49b086da08fe75ac09a615f7fe394d78e673ba7c42c343d2658` |
| coupon_M3_pilot_3p8_horizontal.stl | `285fda72f1a71308a54cb73f2aa25a3097aa864f615ad33192f3e9922b8708d9` |
| coupon_M3_pilot_3p8_vertical.step | `d2f4e0ed781f03ca169bcd6b4dc8ff65fcaa13b3cb39d8fa4cea3cf2ee648d00` |
| coupon_M3_pilot_3p8_vertical.stl | `e54810a7465179cfcf293f2deb1a5c0541e5659c454e27aba35daf10d1c1f4e3` |
| coupon_M3_pilot_3p9_horizontal.step | `50098b5b6b7b3066fa463bd10779b57ab54ba694edadc66391e7f91f70fe5dcd` |
| coupon_M3_pilot_3p9_horizontal.stl | `6d651b6e17245e40b27b400b5e220c2817bb23f92176c3e6e390cc99c7a1c9b2` |
| coupon_M3_pilot_3p9_vertical.step | `b3bc855923bdb8060ccab99d514007136b7330bf719a3ff041e7b4cc942e5b12` |
| coupon_M3_pilot_3p9_vertical.stl | `db972fa49eef1d95d137585bf1dcaf49791b8d16e8580ffdffaf8508139e9a97` |
| coupon_M3_pilot_4p0_horizontal.step | `d72a6ca156a8a53688ca70aa38bb758767868a387b4508e2e222b72af468bfb5` |
| coupon_M3_pilot_4p0_horizontal.stl | `69ac6a7210d9b7bda170c85e9f144f3e5a796aa437cbc4a301c5ab7bc305351a` |
| coupon_M3_pilot_4p0_vertical.step | `9bb8fd695fa58803cfeef1c487aa1762e452f196da0b0ad126c065bb6e9925d9` |
| coupon_M3_pilot_4p0_vertical.stl | `4d747b61ef928fc2e58db0513d92d94132cc6d57b3fd3662a15002e3cb922daa` |
| coupon_M3_pilot_4p1_horizontal.step | `4ffd000d1126e4128c80ea48dcd5a75c1dfd93b588e8afa0c669e5c84d4062fb` |
| coupon_M3_pilot_4p1_horizontal.stl | `02ab2c15a696c5c516d90fe24ad1b8afacceeff134a99839a0af42366af13acf` |
| coupon_M3_pilot_4p1_vertical.step | `2658cda952dac46abb0c7442da4805a05652fb35c9141942b38f97e7a72b3401` |
| coupon_M3_pilot_4p1_vertical.stl | `1730d9ccedd3bdd9ddd8644ca5bb7b66c5c09e45a58bc5924a7978f102ec90b6` |
| coupon_M3_pilot_4p2_horizontal.step | `4531610d12c3da68fd60d521ee8186cc5911ad0049119c3b1959d002a9a75ba7` |
| coupon_M3_pilot_4p2_horizontal.stl | `e90d713e2c1f30637c12df8d53bf55c4b1509a8c02123b16abd150c5ac961444` |
| coupon_M3_pilot_4p2_vertical.step | `ca0229943736dff53d4ba70c27227ac08fce70e76253306890ef111a71314bc4` |
| coupon_M3_pilot_4p2_vertical.stl | `ffda567c21ca354f961030b73ad2f8fcdebb0cc2b52637216593ac32d9e62f0c` |
| coupon_M4_pilot_5p4_horizontal.step | `ee7f5a5e3e306d8a6bc15677f0b86d8bce6f593712de128537a4e6b9dbf04f8c` |
| coupon_M4_pilot_5p4_horizontal.stl | `b4923f288e7f66cf18983b7cfc4d1f9175ae1b1499328abe367c50058c4b8f73` |
| coupon_M4_pilot_5p4_vertical.step | `1b8e67bab5a84d11acf7c96cc866022a6a3f396ad4094b561e69f301941458b1` |
| coupon_M4_pilot_5p4_vertical.stl | `a8df39a3140dae29bbe20e783ba53fda79bc5ff9720b1d030f2c660ccc3f0f16` |
| coupon_M4_pilot_5p5_horizontal.step | `2e4c6f27c4deeb2497ad3929f7f50549e90b39eef760a4daeb3191f8177fb267` |
| coupon_M4_pilot_5p5_horizontal.stl | `ba14d340a91a0749b13b65055131b3ca3ad092e1e422773d6ab803960448d3e8` |
| coupon_M4_pilot_5p5_vertical.step | `e9dce3006477bddd74230f7d768478ab65018e47ee1683576b82f2b0a82baf19` |
| coupon_M4_pilot_5p5_vertical.stl | `21a0532af25dffa25242a7bddd3be20c7b81fa43a716c227ea2e2be7c72a1d3d` |
| coupon_M4_pilot_5p6_horizontal.step | `46d72c40d541fa3e418fcd75ae5efff397fc816c74d826e5abe659c0c2f61396` |
| coupon_M4_pilot_5p6_horizontal.stl | `c3a473f19922a99fdbb4ad0f875b6690f211add7fcd5e959d783c14b81945170` |
| coupon_M4_pilot_5p6_vertical.step | `77f891b1bbdb5d518773f4ec35b79d0108fda36b614d9448fbb1f95b196896b4` |
| coupon_M4_pilot_5p6_vertical.stl | `0b9d9ab93479de37abbe69f677c580ef87ed92fb380fc75a092ae2c0ad909942` |
| coupon_M4_pilot_5p7_horizontal.step | `18303e51e5af51f149fade1f210e9208b4f9b8ede0aa0bb6814698d2afd6836c` |
| coupon_M4_pilot_5p7_horizontal.stl | `0ab75d332f933e7b7b45a9ce3467397a9348a92140dcd21ef6b6280afbb8d370` |
| coupon_M4_pilot_5p7_vertical.step | `cfd81e5b4c750295bc4b4e6b509ea4108f4d94a87d791500242d21176a311e04` |
| coupon_M4_pilot_5p7_vertical.stl | `39cdbe29591d1de75af8fb0e1e0765a1c5a6682832fe6a62e9c31936c2ee4829` |
| coupon_M4_pilot_5p8_horizontal.step | `6749026fae4334002a324c0ee248d7faf2a2251908e806fe6395f6fbe9c08d2e` |
| coupon_M4_pilot_5p8_horizontal.stl | `75bdc9fb7992f27c6bfa8995a57eb1fc5bde2920e33157ebcf63542c1d68ec99` |
| coupon_M4_pilot_5p8_vertical.step | `0ef45b52f678187136fe3b1748010305bd631ee5f5742a2d34720cef1d2280cc` |
| coupon_M4_pilot_5p8_vertical.stl | `8fcbcf92c9a527a8ed7cfd4c79d4f70aed8e9490789e15ec6faa4082384465b7` |

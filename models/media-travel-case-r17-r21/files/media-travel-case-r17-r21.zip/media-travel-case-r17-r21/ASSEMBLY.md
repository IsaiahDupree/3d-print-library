# Assembly and fit

The printed set is one base, one lid, two R21 front clips, and two rear sleeves. Print the base and lid separately in the supplied orientations. The sleeve and clip files each contain a pair.

| Joint | Hardware |
| --- | --- |
| Rear hinge | Two M3 × 35 screws and two M3 heat-set inserts |
| Front upper pivots and lower catches | Four M3 × 40 screws and four M3 heat-set inserts |

The modeled insert body is 4.6 mm outside diameter and 5.7 mm long. Measure the actual insert, print a fit specimen and follow the hardware maker's installation procedure. Place the sleeves at the rear hinges and trial the rear pivots with the empty case. The two front clips pivot on the upper screws and catch the lower screws. Lift the downward-facing lip to release. Check that the clips release and the hinge turns without forcing either one.

The model uses the R17 press-in microSD guides and a rigid seam. Check an expendable card before fitting media that matters to you. Try the completed case unloaded before carrying it.

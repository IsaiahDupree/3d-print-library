# Source and digital checks

Orion job `mdl_056c40ec35364ab3` bound the exact R17 base and lid and the exact R21 clips to the default configuration. It checked 23 payload spaces, 458 latch positions and the four print envelopes. The assembly STEP contains printed bodies and nominal fastening hardware. Media reference geometry was used separately.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| media-case-base.stl | `43d986e8f4c7b301f0e4c08c2ebd5f71252583c7288b8d0d104ccd5b26da4c8b` | `43d986e8f4c7b301f0e4c08c2ebd5f71252583c7288b8d0d104ccd5b26da4c8b` |
| media-case-lid.stl | `ebca3045a0ece358978e60a9e1c4ad205a75787d33de17f4ec871e2a6e699538` | `ebca3045a0ece358978e60a9e1c4ad205a75787d33de17f4ec871e2a6e699538` |
| media-case-front-clips.stl | `d51d09e65bdaf60959b4bca599c97ce2a8f7d508bdd8b28e32a8e0ad939ba686` | `d51d09e65bdaf60959b4bca599c97ce2a8f7d508bdd8b28e32a8e0ad939ba686` |
| media-case-rear-sleeves.stl | `1f0397b9a91e4de9443f2bd4125b6c25ba231344d4d9c0f1aedd00b34bf8b97d` | `1f0397b9a91e4de9443f2bd4125b6c25ba231344d4d9c0f1aedd00b34bf8b97d` |
| media-case-base.step | `a526a9c813c51fd6a4547de4453fa4e22f4e3b6bcf0f8efbe2ec2c9c2f2036bc` | `a526a9c813c51fd6a4547de4453fa4e22f4e3b6bcf0f8efbe2ec2c9c2f2036bc` |
| media-case-lid.step | `ad8766d6e34e8122c8c40bbce90e27ff7c1809cfadddb6f029e0cfdb404c6ac3` | `ad8766d6e34e8122c8c40bbce90e27ff7c1809cfadddb6f029e0cfdb404c6ac3` |
| media-case-front-clip.step | `037cca62d8c499005f49665c453c64c40911225d5c46385e8a14c4a41d27c939` | `037cca62d8c499005f49665c453c64c40911225d5c46385e8a14c4a41d27c939` |
| media-case-assembled.step | `f649e204bcd334589d180ac6b03809f1952b5a67317d27628e692fc9dd758044` | `f649e204bcd334589d180ac6b03809f1952b5a67317d27628e692fc9dd758044` |

# Recovered source geometry

Orion exported the original DesignModeler model to STEP. FreeCAD isolated the rack body, translated the bounding box to the origin, and wrote standalone STEP and STL. The released mesh has one connected component and no open or nonmanifold edges. The STEP was reopened and checked against the tessellated bounds and solid volume.

- Original DesignModeler SHA-256 `70eca09d7643847b70d2ac4b47afba20745fe75a7ff76952b4de6d51958d528b`
- Intermediate assembly STEP SHA-256 `6017625c966ef74b07a7ecdb107e439e252a5e91ddac90777d3c10c3a44d3240`
- muffin-cup-dispenser-body.stl SHA-256 `ed6330629a594b45bee058065d3f3fea37fbee9bf3dba350bb4423285ae80a5d`
- muffin-cup-dispenser-body.step SHA-256 `d3582296d09459a37ddac74a0932f111281fa53ba99b7cb4480957e9f0284593`

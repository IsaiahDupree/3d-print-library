# Source and digital checks

The Cypress live files match the October 24 backup by SHA-256. The original DesignModeler STEP headers and local project revisions identify the source. Orion checked each STL for closure, orientation consistency and one connected solid, and reloaded the matching STEP to compare its solid count, dimensions and volume.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| dust-mount-v2.stl | `355f294eb8662133fc1023d081126b3d88cf308af5757e56a9b31b0ca7f90331` | `355f294eb8662133fc1023d081126b3d88cf308af5757e56a9b31b0ca7f90331` |
| dust-mount-v2.step | `3c340d41483710315033616ad5885fb1723df2af5c3eba102cacbf7ddcca6c67` | `62e0ec6228239d7587c4299ebdccf09e23d3247c5c4ff32544522befe2474110` |

Workstation paths and account names were removed from the affected STEP headers. The geometry section was preserved byte for byte.

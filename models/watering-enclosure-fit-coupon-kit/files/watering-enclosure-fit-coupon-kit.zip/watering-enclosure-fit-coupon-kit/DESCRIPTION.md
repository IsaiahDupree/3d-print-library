Seven specimens from the front-service watering enclosure project. Use these parts to check your printer and hardware against the enclosure dimensions before printing full-size components.

The set includes a drawer guide and blade edge, a wet seal land and mating cover, M3 insert pilots at 4.3, 4.5 and 4.7 mm, M12 gland bores at 12.8, 13.2 and 13.6 mm, and a cup for checking a 6 mm wall. Print the guide and blade as a pair. Check the holes against your exact inserts and glands, and record measured diameters.

Print the individual STL files in their exported orientations. Orion checked mesh closure and sliced each coupon with a 0.4 mm nozzle at 0.2 mm layers. The PLA review profile used a 210 °C nozzle and 60 °C bed. Use a profile appropriate to your printer and filament. The cover images show the CAD geometry arranged on a build plate.

Physical fit, insert strength, sealing, and outdoor service remain unverified. The cup is a bench specimen for observing printed walls.

Licence CC BY-NC-SA 4.0. Credit Isaiah Dupree when sharing or remixing.

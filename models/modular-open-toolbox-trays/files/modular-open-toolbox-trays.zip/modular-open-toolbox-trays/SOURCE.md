# Geometry and validation

The trays are original Orion exports from the toolbox-interiors project. Each STL and STEP pair was reloaded by FreeCAD and checked against the nominal grid dimensions. The Orion jobs below identify the source bytes.

| Tray | Orion job | Source file | SHA-256 |
| --- | --- | --- | --- |
| open-tray-1x1.stl | mdl_b41247278261449d | dewalt-dwst17805_plain_tray.stl | `808197bd4d5cc4ab13d14a06d36cd1cc08e19d973d507455e882a3dfded2498c` |
| open-tray-1x1.step | mdl_b41247278261449d | dewalt-dwst17805_plain_tray.step | `122d156d0ce0045ae17e9c0ebeeba6853f35200b0aa75793b589acf782e30fcf` |
| open-tray-1x2.stl | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_1x2.stl | `3cfa1935483e909e9c8da0794b5dfb0e3e726eaac3fea58c7b56330d38a31a10` |
| open-tray-1x2.step | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_1x2.step | `3d1541db6c77cf177e85f6cb874ceb2e3b826ab6aa3d1ed3632ac1d56a17a4ac` |
| open-tray-2x1.stl | mdl_b9e9671e04574dc7 | dewalt-dwst08320_tray_2x1.stl | `61734fde79c77a23cf802598c3f356d78263f5c9b74991d2acec017170429754` |
| open-tray-2x1.step | mdl_b9e9671e04574dc7 | dewalt-dwst08320_tray_2x1.step | `f786d991e922814636b592c8bb26162c8306796b7db955fd9c30681216bbd759` |
| open-tray-2x2.stl | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_2x2.stl | `415a0056ee9f066e2f1825b301a1f1be82f44ac709f8d193473baed557e52088` |
| open-tray-2x2.step | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_2x2.step | `2090d74ac25cd876210848867efa5eaff48a34011b0b123fa44c6fa03144feb3` |
| open-tray-3x1.stl | mdl_1c69b78e0dd9436e | dewalt-dwst17803_tray_3x1.stl | `ce4acfb35b09bcbaf7ee36d655276db919d21769ab62e279cd319427bb440087` |
| open-tray-3x1.step | mdl_1c69b78e0dd9436e | dewalt-dwst17803_tray_3x1.step | `413c4472d5682094909d98ca9b77305ecd8f6f4103d6c663ca23f1b8d21486ed` |
| open-tray-4x1.stl | mdl_1c69b78e0dd9436e | dewalt-dwst17803_tray_4x1.stl | `44d40670951cc6e6a4ddb935bd5c59891d7b922a14203d8c4dc96724d0b44873` |
| open-tray-4x1.step | mdl_1c69b78e0dd9436e | dewalt-dwst17803_tray_4x1.step | `5515d7f321eb39816ac372c98e964e17755bca390470b5ef865afa69bb948cae` |
| open-tray-5x1.stl | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_5x1.stl | `c3bf5230e55c0e320cbdcb41640a63fa7c77d36f1bd7a4004f4a80f80a4bf75b` |
| open-tray-5x1.step | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_5x1.step | `97e1897b25f20f344014b392a9bb08a42fa4f29046bb466aed875c7a686a1303` |
| open-tray-6x1.stl | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_6x1.stl | `c6432c4615643e95221b99ac392bfab42595ca8bbc9ec457c7a1fb880230d579` |
| open-tray-6x1.step | mdl_0c2b8d969585473b | dewalt-dwst08165_tray_6x1.step | `7f85a0428dc30bb923b6a2904f009c39a74bd603e50a5acba12a3f18e0f3955b` |

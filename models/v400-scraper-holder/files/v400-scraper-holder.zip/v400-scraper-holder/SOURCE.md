# Source and digital checks

The Cypress live files match the October 24 backup by SHA-256. The original DesignModeler STEP headers and local project revisions identify the source. Orion checked each STL for closure, orientation consistency and one connected solid, and reloaded the matching STEP to compare its solid count, dimensions and volume.

| File | Source SHA-256 | Release SHA-256 |
| --- | --- | --- |
| scraper-v2.stl | `3303da35271b492ae55c347bad0bf8b3006374cf69a10361cf9f0323f189960b` | `3303da35271b492ae55c347bad0bf8b3006374cf69a10361cf9f0323f189960b` |
| scraper-v2.step | `23427ba694875c8e93a1b4d6f78dd8117b377c9dabccf8255d4ffcf55ec9f2e3` | `a97e5bb022973f64f040a4e71a221d322975ea5206e1c3e6fe14d177a7ca3e84` |
| scraper-v1.stl | `2f9c4522f4eba9e77aac8a56b16d894407e6ab430263ad2f8433e25aa05675fe` | `2f9c4522f4eba9e77aac8a56b16d894407e6ab430263ad2f8433e25aa05675fe` |
| scraper-v1.step | `38c7918cc6fbb34fd8d05c27ead7113ee34dfea23fba3c03bacc29c199552059` | `3050e68f2dc75e7665b44a97cab0ba997d1008e8c54a74628beb1bf0f36dacf8` |

Workstation paths and account names were removed from the affected STEP headers. The geometry section was preserved byte for byte.


import bpy, math, os
from mathutils import Vector

OUT = 'out5'
COMPONENT_FILES = ['reference_waveshare_ups_hat_d_fit_only.stl', 'reference_interface_pcb_reserved.stl', 'reference_dfrobot_dfr0975.stl', 'reference_adafruit_microsd_4682.stl', 'reference_adafruit_sht40_4885.stl']

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x = 1280
    scene.render.resolution_y = 800
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.display.shading.light = "STUDIO"
    scene.display.shading.studio_light = "paint.sl"
    scene.display.shading.color_type = "OBJECT"
    scene.display.shading.show_shadows = True
    scene.display.shading.show_cavity = True
    scene.display.shading.cavity_type = "WORLD"
    if scene.world is None:
        scene.world = bpy.data.worlds.new("Firewall slot preview world")
    scene.world.color = (0.045, 0.052, 0.065)
    return scene

def import_stl(filename, name, color, alpha=1.0):
    path = os.path.join(OUT, filename)
    before = set(bpy.data.objects)
    try:
        bpy.ops.wm.stl_import(filepath=path)
    except Exception:
        bpy.ops.import_mesh.stl(filepath=path)
    created = [obj for obj in bpy.data.objects if obj not in before]
    if not created:
        raise RuntimeError("STL import made no object: " + path)
    obj = created[0]
    obj.name = name
    obj.color = (*color, alpha)
    return obj

def frame(scene, objects, azimuth=34.0, elevation=26.0, scale=1.36):
    bpy.context.view_layer.update()
    points = []
    for obj in objects:
        if not obj.hide_render:
            points.extend([obj.matrix_world @ Vector(corner) for corner in obj.bound_box])
    lo = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    hi = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    center = (lo + hi) / 2.0
    extent = max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z)
    data = bpy.data.cameras.new("PreviewCamera")
    data.type = "ORTHO"
    data.ortho_scale = extent * scale
    camera = bpy.data.objects.new("PreviewCamera", data)
    bpy.context.collection.objects.link(camera)
    az = math.radians(azimuth)
    el = math.radians(elevation)
    distance = extent * 2.7
    camera.location = center + Vector((
        distance * math.sin(az) * math.cos(el),
        distance * math.cos(az) * math.cos(el),
        distance * math.sin(el),
    ))
    camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = camera

def render(scene, filename):
    scene.render.filepath = os.path.join(OUT, filename)
    bpy.ops.render.render(write_still=True)

scene = reset()
body = import_stl("body.stl", "Compact shell", (0.10, 0.30, 0.56))
cap = import_stl(
    "reference_right_pigtail_cap_installed.stl",
    "Recessed pigtail cap", (0.16, 0.48, 0.76),
)
lid = import_stl(
    "reference_front_lid_installed.stl",
    "Front service lid", (0.91, 0.30, 0.07),
)
backplane = import_stl(
    "reference_electronics_backplane_installed.stl",
    "Vertical backplane", (0.70, 0.72, 0.76),
)
tier = import_stl(
    "reference_upper_electronics_carrier_installed.stl",
    "Upper carrier", (0.62, 0.20, 0.74),
)
palette = [
    (0.12, 0.62, 0.24), (0.64, 0.22, 0.76),
    (0.06, 0.52, 0.84), (0.91, 0.62, 0.06), (0.08, 0.72, 0.68),
]
components = [
    import_stl(filename, filename[10:-4], palette[index % len(palette)])
    for index, filename in enumerate(COMPONENT_FILES)
]
assembly_objects = [body, cap, lid, backplane, tier] + components
frame(scene, assembly_objects, azimuth=32.0, elevation=24.0, scale=1.40)
render(scene, "preview_assembly.png")

cap.location.x += 34.0
lid.location.y += 35.0
backplane.location.y += 20.0
tier.location.y += 20.0
for component in components:
    component.location.y += 20.0
frame(scene, assembly_objects, azimuth=30.0, elevation=28.0, scale=1.48)
render(scene, "preview_service.png")

for obj in assembly_objects:
    obj.hide_render = True
fit = import_stl(
    "slot_clearance_cage.stl", "Photo-datum clearance cage", (0.95, 0.58, 0.08)
)
frame(scene, [fit], azimuth=38.0, elevation=18.0, scale=1.42)
render(scene, "preview_fit_gauge.png")
fit.hide_render = True

standing = import_stl(
    "body_standing.stl", "FLSUN V400 standing body", (0.10, 0.30, 0.56)
)
frame(scene, [standing], azimuth=42.0, elevation=17.0, scale=1.60)
render(scene, "preview_standing.png")
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "workbench.blend"))
print(
    "BLENDER_OK preview_assembly.png preview_service.png "
    "preview_fit_gauge.png preview_standing.png",
    flush=True,
)

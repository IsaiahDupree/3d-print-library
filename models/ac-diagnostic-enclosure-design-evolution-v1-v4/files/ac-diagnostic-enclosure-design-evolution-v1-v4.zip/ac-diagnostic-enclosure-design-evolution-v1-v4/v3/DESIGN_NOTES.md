# A/C diagnostic enclosure — firewall-slot V3 fit study

## Outcome and release status

This is a new version; it does not alter the released V1 or standing V2 files. The
photo-scaled candidate is 175 W x 88 H x
60 D mm plus a 5.0 mm engine-facing lid
and 12.0 mm ventilated adapter gap. The complete empty-cage
projection is 77.0 mm.

Fit status is provisional_photo_envelope; engine-bay release is
blocked_pending_measurements. Only the bolt coupon, empty clearance cage,
depth comb, I/O witness, and hardware coupons are approved for the next physical
step. The populated enclosure remains blocked until every worksheet measurement,
thermal test, material decision, and mount review passes.

## Bolt datum and placement

Enclosure coordinates start at its lower-left rear corner. The photographed bolt
midpoint is X=115.0, Z=25.0
mm, so the candidate extends 115.0
mm left, 60.0 mm right,
25.0 mm below, and
63.0 mm above that midpoint.
The holes are a Ø9.2 round datum and a
14.0 x 9.2 horizontal slot on
50.0 mm centers.

Perspective photographs cannot establish thread pitch, bolt purpose/torque, stamped
land height, hood depth, or moving clearances. Never put the polymer shell directly
under the M8 bolts. Fabricate reference_metal_adapter.step from suitable metal,
measure each rigid bolt-land spacer independently, use four compression-sleeved case
fasteners, and add two lower elastomer bump stops. The printed adapter template is
only a drill/fit pattern.

## Packaging

The UPS reference is rotated to use 85 mm horizontally and 62.464 mm vertically.
The interface PCB stays beside it. The ESP32, microSD, and SHT40 sit on a removable
upper carrier over the interface reservation:

- waveshare_ups_hat_d_fit_only: origin [9.5, 10.0, 12.768] mm, envelope [85.0, 31.38, 62.464] mm, tier lower.
- interface_pcb_reserved: origin [98.50000000000001, 10.0, 16.5] mm, envelope [55.0, 15.0, 55.0] mm, tier lower.
- dfrobot_dfr0975: origin [97.50000000000001, 35.0, 13.0] mm, envelope [25.4, 15.35, 61.47] mm, tier upper.
- adafruit_microsd_4682: origin [128.0, 35.0, 22.0] mm, envelope [25.4, 6.8, 22.86] mm, tier upper.
- adafruit_sht40_4885: origin [128.0, 35.0, 48.0] mm, envelope [25.4, 6.5, 17.78] mm, tier upper.

The lower-tier modules retain 2.00
mm minimum modeled opening clearance. Disconnect the two pigtails, remove the lid,
remove the upper carrier, then withdraw the backplane toward +Y. Board outlines and
hole locations still require physical part measurement.

## Right-side wire entry

The recessed cap uses two small sealed pigtail glands at
[[44.0, 13.0], [44.0, 75.0]] mm rather than placing
full SP13 panel barrels inside the tight cavity. Short pigtails turn downward, form
drip loops, and terminate in separately keyed HIGH/LOW inline connectors outside
the shell. A metal-backed P-clamp on the adapter must carry harness load within
roughly 40-60 mm; neither gland nor FDM wall is a harness support.

The recess has an upper eyebrow and an independent bottom drain. No penetration faces
up. If panel-mounted SP13 sockets remain mandatory, model and measure a separate
down/right doghouse and its complete plug/bend sweep; it is not included in this
175 mm envelope.

## Lid, vent, and printing

The service lid faces the engine, away from the cowl edge. Six M3 fasteners compress
a Ø2.5 mm silicone cord approximately 25 percent in a
3.30 x 1.88
mm square-bottom groove. This is not an IP rating. Leak, condensation, thermal-cycle,
chemical, and vibration tests are mandatory.

body_standing.stl places the flat short end on the FLSUN V400 bed. Its footprint is
60.0 x 88.0 mm,
height 159.8 mm, and required radial extent with the
12 mm brim is 65.25 mm versus a 150 mm bed
radius. Print process coupons first. PLA and PETG are fit-check materials only.
Even ASA is provisional until measured hot-soak data leaves a substantial margin;
use a qualified higher-temperature/flame-conscious material or a commercial
automotive enclosure for permanent service.

## Battery and electrical safety

Do not install or charge the Waveshare board or loose 21700 cells underhood. The UPS
geometry remains only to prove packaging. Relocate energy storage to the cabin, or
use fused, reverse-polarity- and transient-protected automotive vehicle power.
The Samsung 50E specification limits charging to 0-45 C and discharging to -20-60 C;
underhood parked temperatures and crash/hood intrusion are not controlled here.

Pressure-side refrigerant fittings, hoses, tees, transducers, and probes remain
external, metal, pressure-rated assemblies. No printed part may contain refrigerant
pressure. The interface must protect ADC inputs; a nominal 4.5 V pressure signal
must not connect directly to an ESP32 pin.

## Generated validation

- Pure geometry validation: {"battery_policy": "prohibited_underhood", "component_face_clearances_mm": {"adafruit_microsd_4682": {"back": 31.0, "bottom": 18.8, "front": 18.200000000000003, "left": 124.8, "right": 6.400000000000006, "top": 39.94}, "adafruit_sht40_4885": {"back": 31.0, "bottom": 44.8, "front": 18.5, "left": 124.8, "right": 6.400000000000006, "top": 19.019999999999996}, "dfrobot_dfr0975": {"back": 31.0, "bottom": 9.8, "front": 9.649999999999999, "left": 94.30000000000001, "right": 36.900000000000006, "top": 10.329999999999998}, "interface_pcb_reserved": {"back": 6.0, "bottom": 13.3, "front": 35.0, "left": 95.30000000000001, "right": 6.300000000000011, "top": 13.299999999999997}, "waveshare_ups_hat_d_fit_only": {"back": 6.0, "bottom": 9.568000000000001, "front": 18.620000000000005, "left": 6.3, "right": 65.30000000000001, "top": 9.567999999999998}}, "component_pair_checks": [{"gap_mm": 4.000000000000014, "left": "waveshare_ups_hat_d_fit_only", "overlap_mm3": 0.0, "right": "interface_pcb_reserved"}, {"gap_mm": 3.000000000000014, "left": "waveshare_ups_hat_d_fit_only", "overlap_mm3": 0.0, "right": "dfrobot_dfr0975"}, {"gap_mm": 33.5, "left": "waveshare_ups_hat_d_fit_only", "overlap_mm3": 0.0, "right": "adafruit_microsd_4682"}, {"gap_mm": 33.5, "left": "waveshare_ups_hat_d_fit_only", "overlap_mm3": 0.0, "right": "adafruit_sht40_4885"}, {"gap_mm": 10.0, "left": "interface_pcb_reserved", "overlap_mm3": 0.0, "right": "dfrobot_dfr0975"}, {"gap_mm": 10.0, "left": "interface_pcb_reserved", "overlap_mm3": 0.0, "right": "adafruit_microsd_4682"}, {"gap_mm": 10.0, "left": "interface_pcb_reserved", "overlap_mm3": 0.0, "right": "adafruit_sht40_4885"}, {"gap_mm": 5.099999999999994, "left": "dfrobot_dfr0975", "overlap_mm3": 0.0, "right": "adafruit_microsd_4682"}, {"gap_mm": 5.099999999999994, "left": "dfrobot_dfr0975", "overlap_mm3": 0.0, "right": "adafruit_sht40_4885"}, {"gap_mm": 3.1400000000000006, "left": "adafruit_microsd_4682", "overlap_mm3": 0.0, "right": "adafruit_sht40_4885"}], "engine_bay_release": "blocked_pending_measurements", "fit_status": "provisional_photo_envelope", "gland_component_checks": [{"component": "waveshare_ups_hat_d_fit_only", "gland": "LOW", "overlap_mm3": 0.0}, {"component": "interface_pcb_reserved", "gland": "LOW", "overlap_mm3": 0.0}, {"component": "dfrobot_dfr0975", "gland": "LOW", "overlap_mm3": 0.0}, {"component": "adafruit_microsd_4682", "gland": "LOW", "overlap_mm3": 0.0}, {"component": "adafruit_sht40_4885", "gland": "LOW", "overlap_mm3": 0.0}, {"component": "waveshare_ups_hat_d_fit_only", "gland": "HIGH", "overlap_mm3": 0.0}, {"component": "interface_pcb_reserved", "gland": "HIGH", "overlap_mm3": 0.0}, {"component": "dfrobot_dfr0975", "gland": "HIGH", "overlap_mm3": 0.0}, {"component": "adafruit_microsd_4682", "gland": "HIGH", "overlap_mm3": 0.0}, {"component": "adafruit_sht40_4885", "gland": "HIGH", "overlap_mm3": 0.0}], "mechanical_layout": {"adapter_case_centers_xz_mm": [[22.5, 13.0], [152.5, 13.0], [22.5, 75.0], [152.5, 75.0]], "backplane_origin_mm": [8.0, 7.0, 8.0], "backplane_size_mm": [147.0, 3.0, 72.0], "body_cap_interface_x_mm": 159.8, "coordinate_system": {"origin": "lower-left corner of enclosure rear face", "photo_bolt_midpoint_xz_mm": [115.0, 25.0], "x": "positive toward fuse/relay boxes", "y": "positive toward engine/camera", "z": "positive toward cowl"}, "fit_cage_envelope_mm": [175.0, 77.0, 88.0], "full_case_width_mm": 175.0, "gasket": {"cord_d_mm": 2.5, "groove_depth_mm": 1.875, "groove_width_mm": 3.3, "land_inset_mm": 7.5, "target_compression_percent": 25.0}, "installed_projection_mm": 77.0, "lid_width_mm": 163.0, "mount_centers_xz_mm": [[90.0, 25.0], [140.0, 25.0]], "mount_datum_relative_envelope_mm": {"above": 63.0, "below": -25.0, "left": -115.0, "right": 60.0}, "mount_features": ["round", "horizontal_slot"], "photo_envelope_basis": "provisional dimensions scaled from nominal 50 mm bolt spacing", "right_panel_face_x_mm": 163.0, "standing_body_height_mm": 159.8, "standing_footprint_mm": [60.0, 88.0], "upper_carrier_size_mm": [60.5, 2.5, 68.0], "v400_body_required_radius_mm": 65.2541078227774}, "minimum_moving_clearance_mm": 20.0, "minimum_static_clearance_mm": 10.0, "required_measurements": ["OEM bolt purpose, torque, pitch, length, engagement, and rear-panel clearance", "bolt-center spacing and both stamped-land offsets from a straightedge", "clear width/height at the firewall and 30, 45, 60, and 77 mm outward", "hood, hinge, and gas-strut swept volume during slow closure", "fuse-box latch/lid and brake-reservoir service envelopes", "pigtail, inline connector, cable diameter, bend radius, and P-clamp location", "worst-case operating plus parked hot-soak temperature", "cowl-water path"], "service_opening_clearance_mm": {"bottom": 5.268000000000001, "left": 2.0, "right": 2.0, "top": 5.268000000000001}, "status": "pass"}
- FreeCAD result: {"collision_checks": [{"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "interface_pcb_reserved"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "dfrobot_dfr0975"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_microsd_4682"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_sht40_4885"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "dfrobot_dfr0975"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_microsd_4682"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_sht40_4885"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_microsd_4682"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_sht40_4885"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "adafruit_sht40_4885"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "body"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "right_cap"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "front_lid"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "LOW_gland_keepout"}, {"left": "waveshare_ups_hat_d_fit_only", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "HIGH_gland_keepout"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "body"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "right_cap"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "front_lid"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "LOW_gland_keepout"}, {"left": "interface_pcb_reserved", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "HIGH_gland_keepout"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "body"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "right_cap"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "front_lid"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "LOW_gland_keepout"}, {"left": "dfrobot_dfr0975", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "HIGH_gland_keepout"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "body"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "right_cap"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "front_lid"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "LOW_gland_keepout"}, {"left": "adafruit_microsd_4682", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "HIGH_gland_keepout"}, {"left": "adafruit_sht40_4885", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "body"}, {"left": "adafruit_sht40_4885", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "right_cap"}, {"left": "adafruit_sht40_4885", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "front_lid"}, {"left": "adafruit_sht40_4885", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "LOW_gland_keepout"}, {"left": "adafruit_sht40_4885", "limit_mm3": 0.01, "overlap_mm3": 0.0, "pass": true, "right": "HIGH_gland_keepout"}], "fit_cage": {"engine_off": true, "envelope_mm": [175.0, 77.0, 88.0], "hood_close_instruction": "close slowly with soft clay/foam witnesses; never slam", "static_use_only": true}, "freecad_version": ["1", "0", "0", "39109 (Git)", "https://github.com/FreeCAD/FreeCAD", "2024/11/18 16:48:00", "(HEAD detached at 1.0.0)", "2fcc5317fe3aee96ca73475986a577719fc78e20"], "gland_coupon": {"features": [{"diameter_mm": 12.5, "x_mm": 14.0}, {"diameter_mm": 12.7, "x_mm": 36.0}, {"diameter_mm": 12.9, "x_mm": 58.0}], "panel_web_mm": 3.2}, "mount": {"adapter_material": "2.0-2.5 mm bent 5052 aluminum or 1.5-2.0 mm coated steel", "centers_xz_mm": [[90.0, 25.0], [140.0, 25.0]], "datum": "photo bolt midpoint", "printed_template_load_bearing": false, "round_d_mm": 9.2, "slot_overall_mm": [14.0, 9.2]}, "service": {"backplane_direction": "+Y after disconnecting pigtails and upper carrier", "battery_installation": "prohibited underhood; UPS envelope is fit-only", "lid_direction": "+Y toward engine"}, "shape_validation": {"adapter_drill_template": {"bbox": {"max_mm": [175.00000000000003, 88.00000000000001, 3.0000000000000204], "min_mm": [0.0, 0.0, 0.0], "size_mm": [175.00000000000003, 88.00000000000001, 3.0000000000000204]}, "solids": 1, "valid": true, "volume_mm3": 45477.8116429947}, "assembly": {"bbox": {"max_mm": [178.0, 65.0, 88.0], "min_mm": [0.0, -14.5, -28.0], "size_mm": [178.0, 79.5, 116.0]}, "solids": 16, "valid": true}, "body": {"bbox": {"max_mm": [159.80000000000007, 60.0, 88.0], "min_mm": [0.0, 0.0, 0.0], "size_mm": [159.80000000000007, 60.0, 88.0]}, "solids": 1, "valid": true, "volume_mm3": 150519.48533447168}, "body_standing": {"bbox": {"max_mm": [88.00000000000003, 60.0, 159.80000000000013], "min_mm": [0.0, 0.0, 0.0], "size_mm": [88.00000000000003, 60.0, 159.80000000000013]}, "solids": 1, "valid": true, "volume_mm3": 150519.4853344717}, "depth_feeler_45_55_65": {"bbox": {"max_mm": [32.0, 65.0, 6.0], "min_mm": [0.0, 0.0, 0.0], "size_mm": [32.0, 65.0, 6.0]}, "solids": 1, "valid": true, "volume_mm3": 6290.0}, "electronics_backplane": {"bbox": {"max_mm": [147.00000000000003, 72.00000000000001, 3.000000000000016], "min_mm": [0.0, 0.0, 0.0], "size_mm": [147.00000000000003, 72.00000000000001, 3.000000000000016]}, "solids": 1, "valid": true, "volume_mm3": 31440.270016111484}, "front_lid": {"bbox": {"max_mm": [163.00000000000003, 88.00000000000001, 5.000000000000021], "min_mm": [0.0, 0.0, 0.0], "size_mm": [163.00000000000003, 88.00000000000001, 5.000000000000021]}, "solids": 1, "valid": true, "volume_mm3": 68619.93319407111}, "pigtail_gland_coupon": {"bbox": {"max_mm": [72.00000000000001, 30.000000000000007, 3.2000000000000077], "min_mm": [0.0, 0.0, 0.0], "size_mm": [72.00000000000001, 30.000000000000007, 3.2000000000000077]}, "solids": 1, "valid": true, "volume_mm3": 5695.70098823618}, "pigtail_strain_relief_bar": {"bbox": {"max_mm": [48.0, 4.0, 12.0], "min_mm": [0.0, 0.0, 0.0], "size_mm": [48.0, 4.0, 12.0]}, "solids": 1, "valid": true, "volume_mm3": 2176.000000000001}, "reference_electronics_backplane_installed": {"bbox": {"max_mm": [155.0, 10.0, 80.0], "min_mm": [8.0, 7.0, 8.0], "size_mm": [147.0, 3.0, 72.0]}, "solids": 1, "valid": true, "volume_mm3": 31440.270016111466}, "reference_front_lid_installed": {"bbox": {"max_mm": [163.0, 65.0, 88.0], "min_mm": [0.0, 60.0, 0.0], "size_mm": [163.0, 5.0, 88.0]}, "solids": 1, "valid": true, "volume_mm3": 68619.93319407105}, "reference_pigtail_strain_relief_installed": {"bbox": {"max_mm": [178.0, 55.0, 20.0], "min_mm": [166.0, 51.0, -28.0], "size_mm": [12.0, 4.0, 48.0]}, "solids": 1, "valid": true, "volume_mm3": 2176.000000000001}, "reference_right_pigtail_cap_installed": {"bbox": {"max_mm": [175.0, 60.0, 88.0], "min_mm": [157.3, 0.0, 0.0], "size_mm": [17.69999999999999, 60.0, 88.0]}, "solids": 1, "valid": true, "volume_mm3": 26607.57925822075}, "reference_upper_electronics_carrier_installed": {"bbox": {"max_mm": [155.0, 32.5, 78.0], "min_mm": [94.50000000000001, 30.0, 10.0], "size_mm": [60.499999999999986, 2.5, 68.0]}, "solids": 1, "valid": true, "volume_mm3": 10159.33629385641}, "right_io_60mm_witness": {"bbox": {"max_mm": [65.0, 24.0, 8.0], "min_mm": [0.0, 0.0, 0.0], "size_mm": [65.0, 24.0, 8.0]}, "solids": 1, "valid": true, "volume_mm3": 5184.0}, "right_pigtail_cap": {"bbox": {"max_mm": [175.0, 60.0, 88.0], "min_mm": [157.3, 0.0, 0.0], "size_mm": [17.69999999999999, 60.0, 88.0]}, "solids": 1, "valid": true, "volume_mm3": 26607.57925822075}, "right_pigtail_cap_print": {"bbox": {"max_mm": [88.00000000000001, 60.0, 17.700000000000017], "min_mm": [-1.4210854715202004e-14, 0.0, 0.0], "size_mm": [88.00000000000003, 60.0, 17.700000000000017]}, "solids": 1, "valid": true, "volume_mm3": 26607.579258220758}, "slot_clearance_cage": {"bbox": {"max_mm": [88.00000000000004, 77.0, 175.00000000000003], "min_mm": [0.0, 0.0, 1.7763568394002505e-15], "size_mm": [88.00000000000004, 77.0, 175.00000000000003]}, "solids": 1, "valid": true, "volume_mm3": 32638.663396700267}, "standing_wall_hole_coupon": {"bbox": {"max_mm": [30.0, 12.0, 28.0], "min_mm": [0.0, 0.0, 0.0], "size_mm": [30.0, 12.0, 28.0]}, "solids": 1, "valid": true, "volume_mm3": 8729.82044650712}, "upper_electronics_carrier": {"bbox": {"max_mm": [60.5, 68.0, 2.5000000000000178], "min_mm": [0.0, -1.4210854715202004e-14, 0.0], "size_mm": [60.5, 68.00000000000001, 2.5000000000000178]}, "solids": 1, "valid": true, "volume_mm3": 10159.336293856411}, "vehicle_bolt_coupon": {"bbox": {"max_mm": [90.00000000000001, 32.00000000000001, 4.000000000000008], "min_mm": [0.0, 0.0, 0.0], "size_mm": [90.00000000000001, 32.00000000000001, 4.000000000000008]}, "solids": 1, "valid": true, "volume_mm3": 10811.551195600325}}, "standing_print": {"body_footprint_mm": [60.0, 88.0], "body_height_mm": 159.8, "body_required_radius_with_brim_mm": 65.2541078227774, "v400_bed_radius_mm": 150.0, "v400_height_mm": 410.0}}
- Preview result: {"artifacts": ["preview_assembly.png", "preview_service.png", "preview_fit_gauge.png", "preview_standing.png", "workbench.blend"], "available": true, "exit_code": 0, "requested": true}

## Photo provenance

- Photo 1.jpg: 2880 x 3840 px, SHA-256 dcff818030723ab68949cf3d26066eb93f17a78e1ed81309e8d91bb4bef031f9
- Photo 2.jpg: 2880 x 3840 px, SHA-256 063aeef450a261a0555b7617d65e55dfc9538ce755ee5a369f546c3dc5ba9a4c
- Photo 3.jpg: 2880 x 3840 px, SHA-256 a38b408f80a102c6400fdbb8fa0b3e9bdb097a163db2b8ee2485e21b6d39de80
- Photo 4.jpg: 2880 x 3840 px, SHA-256 514fea6ef303bf27ff1d31713d4cb3c595d4f4d70e535cda1d7cdc9423ff4ffc

## Sources

- owner_photos: four owner-supplied 2880 x 3840 engine-bay photographs, 2026-09-11
- flsun_v400_profile: https://github.com/Flsun3d/Flsun-V400/blob/main/V400%20config%20for%20Cura%204.13.1/flsun_v400.def.json
- waveshare_ups_hat_d: https://www.waveshare.com/wiki/UPS_HAT_(D)
- samsung_50e_specification: https://aeroelectric.com/Mfgr_Data/Batteries/LithiumCells/Samsung/INR21700-50E.pdf
- oring_gland: https://www.trelleborg.com/seals/-/media/tss-media-repository/tss_website/pdf-and-other-literature/catalogs/o_ring_gb_en.pdf

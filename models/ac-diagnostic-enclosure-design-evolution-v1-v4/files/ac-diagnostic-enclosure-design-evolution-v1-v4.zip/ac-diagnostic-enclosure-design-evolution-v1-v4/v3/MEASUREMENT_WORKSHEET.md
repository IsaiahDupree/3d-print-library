# Firewall-slot V3 measurement worksheet

The photographs establish orientation and an approximate envelope only. Fill every
blank before changing this fit-study into a vehicle-installable part.

| Measurement | Provisional CAD value | Measured value |
| --- | ---: | --- |
| Bolt center distance | 50.0 mm | ______ |
| Thread diameter and pitch | likely M8 x 1.25, unconfirmed | ______ |
| Original bolt length | unknown | ______ |
| Usable thread engagement / rear clearance | unknown | ______ |
| Left bolt-land stand-off from straightedge | unknown | ______ |
| Right bolt-land stand-off from straightedge | unknown | ______ |
| Clear left from bolt midpoint | 115.0 mm candidate | ______ |
| Clear right from bolt midpoint | 60.0 mm candidate | ______ |
| Clear below bolt midpoint | 25.0 mm candidate | ______ |
| Clear above bolt midpoint | 63.0 mm candidate | ______ |
| Clear depth at all four corners | 77.0 mm candidate | ______ |
| Hood / hinge / strut sweep clearance | >= 20 mm target | ______ |
| Fixed-part and harness clearance | >= 10 mm target | ______ |
| Fuse-box lid and latch service sweep | unknown | ______ |
| Brake-reservoir cap and hand access | unknown | ______ |
| Pigtail gland thread/body/nut | Ø12.5 coupon | ______ |
| Inline plug length and cable bend radius | 60 mm witness | ______ |
| Worst running temperature | unknown | ______ |
| 30-60 minute parked hot-soak temperature | unknown | ______ |
| Cowl water path | unknown | ______ |

## Safe fit sequence

1. Identify the OEM purpose and torque of both bolts. Confirm pitch by hand; never force a fastener.
2. Print and test vehicle_bolt_coupon.stl without driving or running the engine.
3. Print slot_clearance_cage.stl. Install it empty, with the planned rigid spacers.
4. Place soft modeling clay or crushable foam at the cage corners. Close the hood slowly by hand; never slam it.
5. Exercise the fuse-box latch/lid, reservoir cap, hood hinge, and gas strut through their full service/swept paths.
6. Route dummy cables through the 60 mm witness and verify a downward drip loop plus metal-backed P-clamp.
7. Record underhood running and parked hot-soak temperatures before selecting material or locating any energy storage.

Do not run or drive the vehicle with a loose printed gauge. Remove all clay, foam,
tools, and temporary hardware before starting the engine.

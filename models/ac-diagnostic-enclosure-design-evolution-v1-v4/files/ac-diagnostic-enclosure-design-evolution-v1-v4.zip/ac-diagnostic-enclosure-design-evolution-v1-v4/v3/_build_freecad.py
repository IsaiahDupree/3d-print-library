
import json, math, os
import FreeCAD as App
import Part
import MeshPart
from FreeCAD import Vector

P = {'case_width_mm': 175.0, 'case_height_mm': 88.0, 'case_depth_mm': 60.0, 'wall_mm': 3.2, 'back_wall_mm': 4.0, 'lid_thickness_mm': 5.0, 'mount_hole_spacing_mm': 50.0, 'mount_hole_d_mm': 9.2, 'mount_slot_length_mm': 14.0, 'mount_datum_x_mm': 115.0, 'mount_datum_from_bottom_mm': 25.0, 'adapter_gap_mm': 12.0, 'gasket_cord_d_mm': 2.5, 'pigtail_gland_d_mm': 12.5, 'power_cutout_d_mm': 16.2, 'vent_cutout_d_mm': 12.2}
FIXED = {'corner_radius_mm': 4.0, 'right_recess_depth_mm': 12.0, 'right_panel_web_mm': 3.2, 'cap_receiver_length_mm': 8.0, 'cap_receiver_radius_mm': 5.0, 'cap_receiver_root_radius_mm': 2.6, 'cap_screw_clearance_d_mm': 3.6, 'm3_insert_pocket_d_mm': 4.0, 'm3_insert_depth_mm': 6.0, 'backplane_thickness_mm': 3.0, 'backplane_standoff_mm': 3.0, 'upper_carrier_thickness_mm': 2.5, 'upper_carrier_lower_clearance_mm': 5.0, 'upper_component_standoff_mm': 2.5, 'gasket_groove_extra_width_mm': 0.8, 'gasket_land_extra_mm': 5.0, 'gland_keepout_d_mm': 16.0, 'gland_keepout_length_mm': 14.0, 'cable_tie_slot_width_mm': 3.2, 'cable_tie_slot_height_mm': 5.0, 'wall_sacrificial_membrane_mm': 0.45, 'adapter_plate_thickness_mm': 2.5, 'adapter_case_hole_d_mm': 4.5, 'adapter_case_pattern_width_mm': 130.0, 'adapter_case_pattern_height_mm': 62.0, 'adapter_spacer_d_mm': 10.0, 'lower_bump_stop_d_mm': 18.0, 'fit_cage_rail_mm': 5.0, 'fit_static_clearance_mm': 10.0, 'fit_moving_clearance_mm': 20.0, 'external_pigtail_service_mm': 60.0, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0, 'standing_body_brim_mm': 12.0, 'flat_part_brim_mm': 6.0}
MECH = {'coordinate_system': {'origin': 'lower-left corner of enclosure rear face', 'x': 'positive toward fuse/relay boxes', 'y': 'positive toward engine/camera', 'z': 'positive toward cowl', 'photo_bolt_midpoint_xz_mm': [115.0, 25.0]}, 'body_cap_interface_x_mm': 159.8, 'right_panel_face_x_mm': 163.0, 'lid_width_mm': 163.0, 'mount_centers_xz_mm': [[90.0, 25.0], [140.0, 25.0]], 'mount_features': ['round', 'horizontal_slot'], 'mount_datum_relative_envelope_mm': {'left': -115.0, 'right': 60.0, 'below': -25.0, 'above': 63.0}, 'adapter_case_centers_xz_mm': [[22.5, 13.0], [152.5, 13.0], [22.5, 75.0], [152.5, 75.0]], 'backplane_origin_mm': [8.0, 7.0, 8.0], 'backplane_size_mm': [147.0, 3.0, 72.0], 'upper_carrier_size_mm': [60.5, 2.5, 68.0], 'gasket': {'cord_d_mm': 2.5, 'groove_width_mm': 3.3, 'groove_depth_mm': 1.875, 'land_inset_mm': 7.5, 'target_compression_percent': 25.0}, 'standing_footprint_mm': [60.0, 88.0], 'standing_body_height_mm': 159.8, 'full_case_width_mm': 175.0, 'v400_body_required_radius_mm': 65.2541078227774, 'installed_projection_mm': 77.0, 'fit_cage_envelope_mm': [175.0, 77.0, 88.0], 'photo_envelope_basis': 'provisional dimensions scaled from nominal 50 mm bolt spacing'}
LAYOUT = {'waveshare_ups_hat_d_fit_only': {'origin_mm': [9.5, 10.0, 12.768], 'size_mm': [85.0, 31.38, 62.464], 'tier': 'lower', 'mount': 'backplane; physical fit only, no underhood cells'}, 'interface_pcb_reserved': {'origin_mm': [98.50000000000001, 10.0, 16.5], 'size_mm': [55.0, 15.0, 55.0], 'tier': 'lower', 'mount': 'future-drill carrier area'}, 'dfrobot_dfr0975': {'origin_mm': [97.50000000000001, 35.0, 13.0], 'size_mm': [25.4, 15.35, 61.47], 'tier': 'upper', 'mount': 'rotated 90 degrees on removable upper carrier'}, 'adafruit_microsd_4682': {'origin_mm': [128.0, 35.0, 22.0], 'size_mm': [25.4, 6.8, 22.86], 'tier': 'upper', 'mount': 'card edge toward removable front lid'}, 'adafruit_sht40_4885': {'origin_mm': [128.0, 35.0, 48.0], 'size_mm': [25.4, 6.5, 17.78], 'tier': 'upper', 'mount': 'thermally isolated upper-carrier pads'}}
IO = {'pigtail_glands': [{'id': 'LOW', 'center_yz_mm': [44.0, 13.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'HIGH', 'center_yz_mm': [44.0, 75.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}], 'power': {'installed_cutout': False, 'coupon_d_mm': 16.2, 'reason': 'use upstream fused disconnect; compact lid remains unperforated'}, 'vent': {'center_xy_mm': [94.0, 20.0], 'cutout_d_mm': 12.2, 'orientation': 'downward through shell bottom'}, 'external_connector_policy': 'short sealed pigtails; keyed inline disconnects outside enclosure; panel SP13 option requires separately measured doghouse'}
OUT = 'out5'
os.makedirs(OUT, exist_ok=True)

def die(message):
    print("CAD_ERROR " + message, flush=True)
    raise RuntimeError(message)

def bbox(shape):
    b = shape.BoundBox
    return {
        "min_mm": [b.XMin, b.YMin, b.ZMin],
        "max_mm": [b.XMax, b.YMax, b.ZMax],
        "size_mm": [b.XLength, b.YLength, b.ZLength],
    }

def assert_single(name, shape):
    if shape.isNull() or not shape.isValid() or len(shape.Solids) != 1 or shape.Volume <= 0:
        die("%s is not one valid positive-volume solid (solids=%d)" %
            (name, len(shape.Solids)))

def assert_valid(name, shape):
    if shape.isNull() or not shape.isValid():
        die("%s is null or invalid" % name)

def export_pair(shape, stem):
    shape.exportStep(os.path.join(OUT, stem + ".step"))
    mesh = MeshPart.meshFromShape(
        Shape=shape, LinearDeflection=0.08,
        AngularDeflection=0.25, Relative=False,
    )
    mesh.write(os.path.join(OUT, stem + ".stl"))

def add_feature(doc, name, label, shape, color, transparency=0):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = shape
    try:
        obj.ViewObject.ShapeColor = color
        obj.ViewObject.Transparency = transparency
    except Exception:
        pass
    return obj

def bed_orient(shape, rotation):
    result = shape.copy()
    result.Placement = App.Placement(Vector(0, 0, 0), rotation)
    b = result.BoundBox
    result.translate(Vector(-b.XMin, -b.YMin, -b.ZMin))
    return result

def hole_y(cx, cz, diameter, y0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(cx, y0, cz), Vector(0, 1, 0)
    )

def hole_x(cy, cz, diameter, x0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(x0, cy, cz), Vector(1, 0, 0)
    )

def hole_z(cx, cy, diameter, z0, depth):
    return Part.makeCylinder(diameter / 2.0, depth, Vector(cx, cy, z0))

def capsule_y(cx, cz, overall, diameter, y0, depth):
    travel = overall - diameter
    left = hole_y(cx - travel / 2.0, cz, diameter, y0, depth)
    right = hole_y(cx + travel / 2.0, cz, diameter, y0, depth)
    bridge = Part.makeBox(
        travel, depth, diameter,
        Vector(cx - travel / 2.0, y0, cz - diameter / 2.0),
    )
    return left.fuse(right).fuse(bridge).removeSplitter()

def rectangular_frame(width, depth, height, rail, y0=0.0):
    parts = [
        Part.makeBox(width, depth, rail, Vector(0, y0, 0)),
        Part.makeBox(width, depth, rail, Vector(0, y0, height - rail)),
        Part.makeBox(rail, depth, height - 2.0 * rail, Vector(0, y0, rail)),
        Part.makeBox(
            rail, depth, height - 2.0 * rail,
            Vector(width - rail, y0, rail),
        ),
    ]
    return parts[0].multiFuse(parts[1:]).removeSplitter()

L = P["case_width_mm"]
H = P["case_height_mm"]
D = P["case_depth_mm"]
WALL = P["wall_mm"]
BACK = P["back_wall_mm"]
LID_T = P["lid_thickness_mm"]
BODY_X = MECH["body_cap_interface_x_mm"]
PANEL_WEB = FIXED["right_panel_web_mm"]
PANEL_FACE_X = MECH["right_panel_face_x_mm"]
LID_W = MECH["lid_width_mm"]
LAND = MECH["gasket"]["land_inset_mm"]
GROOVE_W = MECH["gasket"]["groove_width_mm"]
GROOVE_D = MECH["gasket"]["groove_depth_mm"]
MEMBRANE = FIXED["wall_sacrificial_membrane_mm"]

# Main shell: an X-constant U-channel with a flat left build face.  The front
# and right faces remain open during the standing print.
outer = Part.makeBox(BODY_X, D, H)
cavity = Part.makeBox(
    BODY_X - WALL + 2.0,
    D - BACK + 2.0,
    H - 2.0 * WALL,
    Vector(WALL, BACK, WALL),
)
body = outer.cut(cavity).removeSplitter()

# Widen the front top, bottom, and left lands for the face gasket and lid
# inserts while preserving the constant-X standing section.
rail_depth = FIXED["m3_insert_depth_mm"] + 2.0
front_y = D - rail_depth
front_bottom = Part.makeBox(BODY_X, rail_depth, LAND, Vector(0, front_y, 0))
front_top = Part.makeBox(
    BODY_X, rail_depth, LAND, Vector(0, front_y, H - LAND)
)
front_left = Part.makeBox(
    LAND, rail_depth, H - 2.0 * LAND, Vector(0, front_y, LAND)
)
body = body.multiFuse([front_bottom, front_top, front_left]).removeSplitter()

# Two narrow front receiver ribs also run all the way from the flat build face.
# This prevents the cap bosses from appearing as disconnected mid-print islands.
front_receiver_ribs = [
    Part.makeBox(BODY_X, rail_depth, 4.0, Vector(0, front_y, cz - 2.0))
    for cz in (30.0, H - 30.0)
]
body = body.multiFuse(front_receiver_ribs).removeSplitter()

# Four short, axial receiver cones support the removable right cap.  They
# begin only near the end of the standing print and stay outside the reserved
# board volumes.
cap_screws = [
    [4.0, 30.0], [4.0, H - 30.0],
    [D - 4.0, 30.0], [D - 4.0, H - 30.0],
]
receiver_len = FIXED["cap_receiver_length_mm"]
receivers = []
receiver_pockets = []
for cy, cz in cap_screws:
    receiver = Part.makeCone(
        FIXED["cap_receiver_root_radius_mm"],
        FIXED["cap_receiver_radius_mm"],
        receiver_len,
        Vector(BODY_X - receiver_len, cy, cz),
        Vector(1, 0, 0),
    )
    receiver_clip = Part.makeBox(
        receiver_len + 0.2, D, H,
        Vector(BODY_X - receiver_len - 0.1, 0, 0),
    )
    receivers.append(receiver.common(receiver_clip).removeSplitter())
    receiver_pockets.append(Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["m3_insert_depth_mm"] + 0.25,
        Vector(BODY_X - FIXED["m3_insert_depth_mm"], cy, cz),
        Vector(1, 0, 0),
    ))
body = body.multiFuse(receivers).removeSplitter()
body = body.cut(Part.makeCompound(receiver_pockets)).removeSplitter()

# Six lid insert pockets enter from the front.  The screw row remains outside
# the square-bottom cord groove.
lid_screws = [
    [30.0, 4.0], [85.0, 4.0], [140.0, 4.0],
    [30.0, H - 4.0], [85.0, H - 4.0], [140.0, H - 4.0],
]
lid_insert_cuts = [
    hole_y(cx, cz, FIXED["m3_insert_pocket_d_mm"],
           D - FIXED["m3_insert_depth_mm"], FIXED["m3_insert_depth_mm"] + 0.25)
    for cx, cz in lid_screws
]
body = body.cut(Part.makeCompound(lid_insert_cuts)).removeSplitter()

# Four M4 passages align to metal standoffs on the adapter.  They pass only
# through the rear wall; metal compression sleeves carry clamp load.
adapter_holes = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_holes.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"], -0.5, BACK + 1.0
    ))
body = body.cut(Part.makeCompound(adapter_holes)).removeSplitter()

# Downward vent: leave a removable one-perimeter membrane for the standing
# print.  This is a process aid, not an IP claim.
vent = IO["vent"]
vx, vy = vent["center_xy_mm"]
vent_cut = hole_z(
    vx, vy, vent["cutout_d_mm"],
    MEMBRANE, WALL - MEMBRANE + 1.0,
)
body = body.cut(vent_cut).removeSplitter()

# Recessed right cap.  The small pigtail glands replace bulky SP13 panel
# barrels inside this constrained shell.  The open recess drains downward.
cap_web = Part.makeBox(PANEL_WEB, D, H, Vector(BODY_X, 0, 0))
recess_x = PANEL_FACE_X
recess_depth = FIXED["right_recess_depth_mm"]
rim = [
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, 0, 0)),
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, D - WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, H - WALL)),
]
cap = cap_web.multiFuse(rim).removeSplitter()
gland_holes = []
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_holes.append(hole_x(
        cy, cz, gland["cutout_d_mm"], BODY_X - 0.5, PANEL_WEB + 1.0
    ))
cap_holes = [
    hole_x(cy, cz, FIXED["cap_screw_clearance_d_mm"],
           BODY_X - 0.5, PANEL_WEB + 1.0)
    for cy, cz in cap_screws
]
cap = cap.cut(Part.makeCompound(gland_holes + cap_holes)).removeSplitter()
drain_slot = Part.makeBox(
    recess_depth + 1.0, 12.0, WALL + 1.0,
    Vector(recess_x - 0.5, D - 18.0, -0.5),
)
cap = cap.cut(drain_slot).removeSplitter()

# Four shallow tabs register the cap but deliberately do not form the seal.
tab_clear = 0.6
tabs = [
    Part.makeBox(2.5, 8.0, 3.0, Vector(BODY_X - 2.5, WALL + tab_clear, WALL + tab_clear)),
    Part.makeBox(2.5, 8.0, 3.0, Vector(BODY_X - 2.5, D - WALL - 8.0 - tab_clear, WALL + tab_clear)),
    Part.makeBox(2.5, 8.0, 3.0, Vector(BODY_X - 2.5, WALL + tab_clear, H - WALL - 3.0 - tab_clear)),
    Part.makeBox(2.5, 8.0, 3.0, Vector(BODY_X - 2.5, D - WALL - 8.0 - tab_clear, H - WALL - 3.0 - tab_clear)),
]
cap = cap.multiFuse(tabs).removeSplitter()

# Front service lid.  Its installed position is in front of the body.  The
# compact face gland uses a square-bottom groove and 25 percent target squeeze.
lid_installed = Part.makeBox(LID_W, LID_T, H, Vector(0, D, 0))
groove_outer = Part.makeBox(
    LID_W - 2.0 * LAND, GROOVE_D + 0.2, H - 2.0 * LAND,
    Vector(LAND, D - 0.1, LAND),
)
groove_inner = Part.makeBox(
    LID_W - 2.0 * (LAND + GROOVE_W),
    GROOVE_D + 0.4,
    H - 2.0 * (LAND + GROOVE_W),
    Vector(LAND + GROOVE_W, D - 0.2, LAND + GROOVE_W),
)
groove = groove_outer.cut(groove_inner).removeSplitter()
lid_installed = lid_installed.cut(groove).removeSplitter()
lid_clearance_holes = [
    hole_y(cx, cz, FIXED["cap_screw_clearance_d_mm"], D - 0.5, LID_T + 1.0)
    for cx, cz in lid_screws
]
lid_installed = lid_installed.cut(
    Part.makeCompound(lid_clearance_holes)
).removeSplitter()

# Removable lower backplane and second tier.  Actual electronics use metal
# spacers; the printed boards contain holes only.
bp = MECH["backplane_origin_mm"]
bs = MECH["backplane_size_mm"]
backplane_installed = Part.makeBox(bs[0], bs[1], bs[2], Vector(*bp))
backplane_mounts = [
    [13.0, 10.0], [151.0, 10.0],
    [13.0, H - 10.0], [151.0, H - 10.0],
]
bp_cuts = [
    hole_y(cx, cz, 3.6, bp[1] - 0.2, bs[1] + 0.4)
    for cx, cz in backplane_mounts
]

# Known UPS holes after rotating the 62.464 x 85 mm drawing onto X/Z.
ups = LAYOUT["waveshare_ups_hat_d_fit_only"]["origin_mm"]
for local_x, local_z in ([81.5, 3.5], [23.5, 3.5], [81.5, 52.5], [23.5, 52.5]):
    bp_cuts.append(hole_y(
        ups[0] + local_x, ups[2] + local_z, 3.2, bp[1] - 0.2, bs[1] + 0.4
    ))

tier_x = LAYOUT["interface_pcb_reserved"]["origin_mm"][0] - 4.0
tier_z = 10.0
tier_y = (
    LAYOUT["interface_pcb_reserved"]["origin_mm"][1]
    + LAYOUT["interface_pcb_reserved"]["size_mm"][1]
    + FIXED["upper_carrier_lower_clearance_mm"]
)
tier_s = MECH["upper_carrier_size_mm"]
tier_mounts = [
    [tier_x + 2.5, tier_z + 2.5],
    [tier_x + tier_s[0] - 2.5, tier_z + 2.5],
    [tier_x + 2.5, tier_z + tier_s[2] - 2.5],
    [tier_x + tier_s[0] - 2.5, tier_z + tier_s[2] - 2.5],
]
for cx, cz in tier_mounts:
    bp_cuts.append(hole_y(cx, cz, 3.2, bp[1] - 0.2, bs[1] + 0.4))
backplane_installed = backplane_installed.cut(
    Part.makeCompound(bp_cuts)
).removeSplitter()

upper_carrier_installed = Part.makeBox(
    tier_s[0], tier_s[1], tier_s[2], Vector(tier_x, tier_y, tier_z)
)
tier_cuts = [
    hole_y(cx, cz, 3.2, tier_y - 0.2, tier_s[1] + 0.4)
    for cx, cz in tier_mounts
]

# Controller holes mapped through its 90-degree X/Z rotation.
esp = LAYOUT["dfrobot_dfr0975"]["origin_mm"]
for local_x, local_z in ([1.7, 1.7], [1.7, 58.3], [23.7, 1.7], [23.7, 58.3]):
    tier_cuts.append(hole_y(
        esp[0] + local_x, esp[2] + local_z, 2.4, tier_y - 0.2, tier_s[1] + 0.4
    ))
upper_carrier_installed = upper_carrier_installed.cut(
    Part.makeCompound(tier_cuts)
).removeSplitter()

# Small removable strain-relief bar for the two outgoing pigtails.
strain_bar = Part.makeBox(48.0, 4.0, 12.0)
for sx in (12.0, 34.0):
    slot = Part.makeBox(
        FIXED["cable_tie_slot_width_mm"], 5.0,
        FIXED["cable_tie_slot_height_mm"],
        Vector(sx, -0.5, 3.5),
    )
    strain_bar = strain_bar.cut(slot)
strain_bar = strain_bar.removeSplitter()
strain_bar_installed = strain_bar.copy()
strain_bar_installed.rotate(Vector(0, 0, 0), Vector(0, 1, 0), 90)
strain_bar_installed.translate(Vector(PANEL_FACE_X + 3.0, D - 9.0, 20.0))

# Component and gland reference envelopes.
component_shapes = {}
for name, item in LAYOUT.items():
    component_shapes[name] = Part.makeBox(
        item["size_mm"][0], item["size_mm"][1], item["size_mm"][2],
        Vector(*item["origin_mm"]),
    )
gland_keepouts = {}
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_keepouts[gland["id"]] = Part.makeCylinder(
        FIXED["gland_keepout_d_mm"] / 2.0,
        FIXED["gland_keepout_length_mm"],
        Vector(BODY_X - FIXED["gland_keepout_length_mm"], cy, cz),
        Vector(1, 0, 0),
    )

# Reference structural adapter.  It is exported as STEP only and must be
# fabricated from metal; the printable template below is never the load path.
adapter_t = FIXED["adapter_plate_thickness_mm"]
adapter_y = -P["adapter_gap_mm"] - adapter_t
adapter_plate = Part.makeBox(L, adapter_t, H, Vector(0, adapter_y, 0))
mounts = MECH["mount_centers_xz_mm"]
adapter_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"],
           adapter_y - 0.5, adapter_t + 1.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_cutters.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"],
        adapter_y - 0.5, adapter_t + 1.0,
    ))
adapter_plate = adapter_plate.cut(Part.makeCompound(adapter_cutters)).removeSplitter()
spacers = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    sleeve = Part.makeCylinder(
        FIXED["adapter_spacer_d_mm"] / 2.0,
        P["adapter_gap_mm"],
        Vector(cx, -P["adapter_gap_mm"], cz),
        Vector(0, 1, 0),
    )
    bore = Part.makeCylinder(
        FIXED["adapter_case_hole_d_mm"] / 2.0,
        P["adapter_gap_mm"] + 0.2,
        Vector(cx, -P["adapter_gap_mm"] - 0.1, cz),
        Vector(0, 1, 0),
    )
    spacers.append(sleeve.cut(bore).removeSplitter())
adapter_reference = Part.makeCompound([adapter_plate] + spacers)

# Flat printed drill template uses the exact adapter holes, but is explicitly
# too thin and too creep-prone to become a vehicle bracket.
adapter_template = Part.makeBox(L, 3.0, H)
template_cuts = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    template_cuts.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"], -0.5, 4.0
    ))
adapter_template = adapter_template.cut(
    Part.makeCompound(template_cuts)
).removeSplitter()

# Low-material installed-envelope cage.  It validates the 175 x 88 outline
# and the full adapter + shell + lid projection without installing electronics.
cage_depth = MECH["installed_projection_mm"]
rail = FIXED["fit_cage_rail_mm"]
rear_frame = rectangular_frame(L, 3.0, H, rail, 0.0)
front_frame = rectangular_frame(L, 3.0, H, rail, cage_depth - 3.0)
long_rails = [
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, 0)),
    Part.makeBox(rail, cage_depth, rail, Vector(L - rail, 0, 0)),
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, H - rail)),
    Part.makeBox(rail, cage_depth, rail, Vector(L - rail, 0, H - rail)),
]
crossbar = Part.makeBox(
    L, 3.0, 22.0,
    Vector(0, 0, P["mount_datum_from_bottom_mm"] - 11.0),
)
fit_cage = rear_frame.multiFuse(
    [front_frame, crossbar] + long_rails
).removeSplitter()
fit_cage = fit_cage.cut(Part.makeCompound([
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
])).removeSplitter()

# Compact bolt coupon with the same round + horizontal-slot datum.
coupon_w = 90.0
coupon_h = 32.0
bolt_coupon = Part.makeBox(coupon_w, 4.0, coupon_h)
bolt_coupon = bolt_coupon.cut(Part.makeCompound([
    hole_y(20.0, coupon_h / 2.0, P["mount_hole_d_mm"], -0.5, 5.0),
    capsule_y(70.0, coupon_h / 2.0, P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 5.0),
])).removeSplitter()

# 45/55/65 mm comb for measuring depth at several points on the stamped
# firewall.  The connected heel keeps it one printable solid.
depth_comb = Part.makeBox(32.0, 5.0, 5.0)
for index, length in enumerate((45.0, 55.0, 65.0)):
    depth_comb = depth_comb.fuse(
        Part.makeBox(6.0, length, 6.0, Vector(2.0 + index * 11.0, 0, 0))
    )
depth_comb = depth_comb.removeSplitter()

# A 60 mm right-side witness makes the pigtail/inline-connector service zone
# visible during the static fit test.
io_witness = Part.makeBox(65.0, 8.0, 8.0)
io_witness = io_witness.fuse(
    Part.makeBox(8.0, 24.0, 8.0, Vector(0, 0, 0))
).removeSplitter()

# Exact web-thickness coupons for purchased gland/vent measurement and for the
# standing shell's horizontal-hole membrane process.
gland_coupon = Part.makeBox(72.0, PANEL_WEB, 30.0)
coupon_features = []
for index, delta in enumerate((0.0, 0.2, 0.4)):
    cx = 14.0 + 22.0 * index
    diameter = P["pigtail_gland_d_mm"] + delta
    gland_coupon = gland_coupon.cut(hole_y(
        cx, 15.0, diameter, -0.5, PANEL_WEB + 1.0
    ))
    coupon_features.append({"x_mm": cx, "diameter_mm": diameter})
wall_coupon = Part.makeBox(30.0, 12.0, 28.0)
wall_hole = hole_y(
    15.0, 14.0, P["vent_cutout_d_mm"],
    MEMBRANE, 12.0 - MEMBRANE + 1.0,
)
wall_coupon = wall_coupon.cut(wall_hole).removeSplitter()

# Production print transforms.
body_standing = bed_orient(
    body, App.Rotation(Vector(0, 1, 0), -90.0)
)
cap_print = bed_orient(
    cap, App.Rotation(Vector(0, 1, 0), -90.0)
)
lid_print = bed_orient(
    lid_installed, App.Rotation(Vector(1, 0, 0), 90.0)
)
backplane_print = bed_orient(
    backplane_installed, App.Rotation(Vector(1, 0, 0), 90.0)
)
upper_carrier_print = bed_orient(
    upper_carrier_installed, App.Rotation(Vector(1, 0, 0), 90.0)
)
adapter_template_print = bed_orient(
    adapter_template, App.Rotation(Vector(1, 0, 0), 90.0)
)
bolt_coupon_print = bed_orient(
    bolt_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
fit_cage_standing = bed_orient(
    fit_cage, App.Rotation(Vector(0, 1, 0), -90.0)
)
gland_coupon_print = bed_orient(
    gland_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)

shapes = {
    "body": body,
    "body_standing": body_standing,
    "right_pigtail_cap": cap,
    "right_pigtail_cap_print": cap_print,
    "front_lid": lid_print,
    "electronics_backplane": backplane_print,
    "upper_electronics_carrier": upper_carrier_print,
    "pigtail_strain_relief_bar": strain_bar,
    "slot_clearance_cage": fit_cage_standing,
    "vehicle_bolt_coupon": bolt_coupon_print,
    "adapter_drill_template": adapter_template_print,
    "depth_feeler_45_55_65": depth_comb,
    "right_io_60mm_witness": io_witness,
    "pigtail_gland_coupon": gland_coupon_print,
    "standing_wall_hole_coupon": wall_coupon,
    "reference_right_pigtail_cap_installed": cap,
    "reference_front_lid_installed": lid_installed,
    "reference_electronics_backplane_installed": backplane_installed,
    "reference_upper_electronics_carrier_installed": upper_carrier_installed,
    "reference_pigtail_strain_relief_installed": strain_bar_installed,
}
for name, shape in shapes.items():
    assert_single(name, shape)
    export_pair(shape, name)
for name, shape in component_shapes.items():
    assert_single("reference_" + name, shape)
    export_pair(shape, "reference_" + name)
for name, shape in gland_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_gland_keepout")

assert_valid("adapter_reference", adapter_reference)
adapter_reference.exportStep(os.path.join(OUT, "reference_metal_adapter.step"))

assembly_parts = [
    body, cap, lid_installed, backplane_installed,
    upper_carrier_installed, strain_bar_installed,
] + list(component_shapes.values()) + [adapter_reference]
assembly = Part.makeCompound(assembly_parts)
assert_valid("assembly", assembly)
assembly.exportStep(os.path.join(OUT, "assembly.step"))
assembly_mesh = MeshPart.meshFromShape(
    Shape=assembly, LinearDeflection=0.08,
    AngularDeflection=0.25, Relative=False,
)
assembly_mesh.write(os.path.join(OUT, "assembly.stl"))

collision_checks = []
def no_overlap(left_name, left_shape, right_name, right_shape, limit=0.01):
    volume = left_shape.common(right_shape).Volume
    row = {
        "left": left_name, "right": right_name,
        "overlap_mm3": volume, "limit_mm3": limit,
        "pass": volume <= limit,
    }
    collision_checks.append(row)
    if not row["pass"]:
        die("%s overlaps %s by %.6f mm^3" % (left_name, right_name, volume))

component_names = list(component_shapes)
for index, left_name in enumerate(component_names):
    for right_name in component_names[index + 1:]:
        no_overlap(
            left_name, component_shapes[left_name],
            right_name, component_shapes[right_name],
        )
for name, shape in component_shapes.items():
    no_overlap(name, shape, "body", body)
    no_overlap(name, shape, "right_cap", cap)
    no_overlap(name, shape, "front_lid", lid_installed)
    for gland_name, gland_shape in gland_keepouts.items():
        no_overlap(name, shape, gland_name + "_gland_keepout", gland_shape)

doc = App.newDocument("AC_Diagnostic_Enclosure_Firewall_Slot_V3")
add_feature(doc, "Body", "Standing-print compact shell", body, (0.10, 0.28, 0.52))
add_feature(doc, "RightPigtailCap", "Recessed right pigtail cap", cap, (0.18, 0.46, 0.72))
add_feature(doc, "FrontLid", "Engine-facing service lid", lid_installed, (0.92, 0.34, 0.08), 12)
add_feature(doc, "Backplane", "Vertical electronics backplane", backplane_installed, (0.72, 0.72, 0.76), 15)
add_feature(doc, "UpperCarrier", "Removable upper electronics carrier", upper_carrier_installed, (0.58, 0.25, 0.72), 15)
add_feature(doc, "MetalAdapterReference", "METAL ONLY adapter reference", adapter_reference, (0.58, 0.60, 0.64), 10)
palette = [
    (0.12, 0.62, 0.24), (0.65, 0.22, 0.75),
    (0.06, 0.52, 0.84), (0.91, 0.62, 0.06), (0.08, 0.72, 0.68),
]
for index, (name, shape) in enumerate(component_shapes.items()):
    add_feature(doc, "Reference_" + name, name, shape, palette[index], 50)
for name, shape in gland_keepouts.items():
    add_feature(doc, "Keepout_" + name, name + " gland keepout", shape, (0.9, 0.1, 0.1), 82)
doc.recompute()
doc.saveAs(os.path.join(OUT, "assembly.FCStd"))

shape_validation = {}
for name, shape in shapes.items():
    shape_validation[name] = {
        "valid": shape.isValid(),
        "solids": len(shape.Solids),
        "volume_mm3": shape.Volume,
        "bbox": bbox(shape),
    }
shape_validation["assembly"] = {
    "valid": assembly.isValid(),
    "solids": len(assembly.Solids),
    "bbox": bbox(assembly),
}

result = {
    "freecad_version": App.Version(),
    "shape_validation": shape_validation,
    "collision_checks": collision_checks,
    "mount": {
        "datum": "photo bolt midpoint",
        "centers_xz_mm": mounts,
        "round_d_mm": P["mount_hole_d_mm"],
        "slot_overall_mm": [P["mount_slot_length_mm"], P["mount_hole_d_mm"]],
        "adapter_material": "2.0-2.5 mm bent 5052 aluminum or 1.5-2.0 mm coated steel",
        "printed_template_load_bearing": False,
    },
    "fit_cage": {
        "envelope_mm": MECH["fit_cage_envelope_mm"],
        "static_use_only": True,
        "engine_off": True,
        "hood_close_instruction": "close slowly with soft clay/foam witnesses; never slam",
    },
    "standing_print": {
        "body_footprint_mm": MECH["standing_footprint_mm"],
        "body_height_mm": MECH["standing_body_height_mm"],
        "body_required_radius_with_brim_mm": MECH["v400_body_required_radius_mm"],
        "v400_bed_radius_mm": FIXED["v400_bed_diameter_mm"] / 2.0,
        "v400_height_mm": FIXED["v400_height_mm"],
    },
    "gland_coupon": {
        "panel_web_mm": PANEL_WEB,
        "features": coupon_features,
    },
    "service": {
        "lid_direction": "+Y toward engine",
        "backplane_direction": "+Y after disconnecting pigtails and upper carrier",
        "battery_installation": "prohibited underhood; UPS envelope is fit-only",
    },
}
with open(os.path.join(OUT, "freecad_result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, indent=2, sort_keys=True)
print(
    "CAD_OK firewall_slot_v3 body=%.3f cap=%.3f checks=%d" %
    (body.Volume, cap.Volume, len(collision_checks)),
    flush=True,
)

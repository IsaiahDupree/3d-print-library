# AC diagnostic enclosure — design notes

## Intended use and safety lock

This is a **cabin/service-tool prototype only**. It is not an under-hood enclosure and is not qualified for engine-bay heat, hot soak, vibration, refrigerant exposure, or charging in a parked/hot vehicle. The recessed lid label pad is for:

> SERVICE TOOL — NOT FOR ENGINE BAY / REMOVE WHEN PARKED

Pressure transducers, refrigerant hoses, tees, couplers, and line-temperature probes remain entirely external to this enclosure; **no refrigerant-pressure part may be 3D printed**. Never support hose/manifold mass from a vehicle service port. This design has no vibration qualification.

Use only matched, genuine 21700 cells of the same model, batch, capacity, age, and state of health. Bring both cells to equal voltage before installation, power the tool fully off, verify holder polarity one cell at a time, and never hot-swap or mix old/new cells. Obey the cell and UPS vendor charging, discharging, and storage temperature limits; never charge this tool in a hot vehicle.

For the prototype, use ASA or a better documented temperature-rated polymer—**not PLA**. Ordinary hobby ASA is not automatically flame-retardant; any productized version needs a documented UL94 V-0 material/process evaluation, not a filament-name assumption.

## Source-template provenance

- Source STEP: `ac.stp`
- SHA-256: `90C24B9E69317FE15B9EB6698FC90A7F5E4F10AEB81FC437214E7C18065CCE9B`
- Measured bounding box: `126.7 × 90 × 30 mm`; main body approximately `126.7 × 75 × 30 mm`.
- Original mount observations: two approximately Ø6.7 mm holes at 50 mm centers, 7.5 mm flange thickness, and 15 mm extension.
- The generator derives the source's rounded-box styling and mounting datums. It creates a new parametric solid; it does **not** import, edit, or claim a direct solid modification of that STEP.

## Geometry

- Main body footprint: `200 × 98 mm`; body height `50 mm`; wall `3 mm`; floor `3.2 mm`.
- The usable opening is preserved at `194 × 92 mm`. The sealing flange grows outward by `7.200 mm` per side instead of shrinking that opening. A ≤45-degree 0.4 mm-rise/0.4 mm-outward stair buttress supports it when printed floor-down.
- Rear/bottom mounting flange: exact `86.7 mm` width, `21 mm` extension, `7.5 mm` thickness; two Ø`9` holes at `50 mm` centers and the template-derived `8.65 mm` Y offset from the body edge. This resolved geometry leaves `12.350 mm` from hole center to rear edge and `7.850 mm` ligament. It deliberately enlarges the source template's measured 15 mm extension. Three ribs join flange to rear wall without entering Ø18 head/washer keepouts. Mount through the body/base only; the lid carries no vehicle load. Confirm M8 × 1.25 with a gauge/known bolt and select engaged length on the vehicle.
- Lid screws: `8` M3 clearance holes, distributed along the long front/rear edges and outboard of the continuous gasket path. Their body supports and webs are full height; external connector/vent faces and rear M8 heads are collision-checked. Body pockets are Ø4.0 × 6.7 mm blind for the referenced M3 insert datum. UPS and removable-carrier pockets use the Ø4.0 × 5.0 mm M2.5 datum. Run insert/process coupons before the final print.
- Gasket datum: `3.00 mm` cord, `4.00 mm` wide × `2.30 mm` deep, bottom R`0.60`, with at least 3 mm land on each side. This is geometry, not an IP rating.

## Panel cutouts and keepouts

- HIGH and LOW: WEIPU SP1312/S6 female-contact rear-nut receptacles; the resolved production cut is Ø`13` with **opposing** `11.8 mm` flats and panel thickness `3 mm` (capped at 3.5 mm). Mate to SP1310/P6II cable plugs for 5–8 mm finished cable OD (P6I for 4–6.5 mm). Six-contact rating is 5 A/contact, 125 VAC, ≤0.75 mm² / 18 AWG. IP68 applies only while mated, so add caps. Ø22 × 25 mm rigid rear corridors plus 30 mm wire-turn corridors are collision-checked. Functional printed U-bridges provide zip-tie strain relief without perforating the floor. HIGH and LOW need distinct mechanical secondary keying/captive color identifiers and firmware sanity checks; identical connector pinouts must not make an accidental field swap plausible.
- USB-C: Ø`16.2` is **provisional** for the QIANRENON M15 listing. A `34 × 26 × 26 mm` rear envelope and a second wire-turn volume are reserved. Measure the purchased bulkhead, nut, cable bend, and keying before final print.
- Power: E-Switch PVA6LRPW1241 nominal Ø16.0 +0.2, D-flat span 15.4 mm, M16 × 1, 18.5 mm head. The production parameter is Ø`16.2` with the 15.4 mm flat retained. Reserve at least 25 mm behind the panel and 40 mm wire-turn space.
- Rear vent: Amphenol LTW VENT-PS1YGY-O8002 (black `YBK` is acceptable), M12 × 1.5, cutout Ø12.2 ±0.1, 2–3.5 mm panel, Ø17 max/16 mm hex, and 6–8 mm rear keepout. The fit coupon derives its nominal, +0.2, and +0.4 mm variants from the resolved override.

An explicit top-service volume is reserved above the DFR0975 USB end, and a full vertical removal volume is reserved above the microSD board. The exact DFR0975 connector orientation, selected right-angle cable, and microSD card-side direction still require physical confirmation.

## Component datum and hole inputs

- **Waveshare UPS HAT (D), rotated -90 degrees** — envelope `62.464 × 85 × 31.38 mm`; local hole centers `[[3.5, 81.5], [3.5, 23.5], [52.5, 81.5], [52.5, 23.5]]`; Ø`3`. Source/status: https://files.waveshare.com/wiki/UPS-HAT-D/UPS-HAT-D%203D%20Drawing.zip.
- **Reserved future interface PCB envelope on removable carrier** — envelope `55 × 55 × 15 mm`; no PCB mounting holes modeled; removable carrier is future-drill. Source/status: FUTURE-DRILL BLANK: final PCB outline and mounting holes are not released.
- **DFRobot DFR0975 ESP32-S3 development board** — envelope `61.47 × 25.4 × 7.1 mm`; local hole centers `[[2.435, 1.7], [59.035, 1.7], [2.435, 23.7], [59.035, 23.7]]`; Ø`2`. Source/status: https://wiki.dfrobot.com/dfr0975.
- **Adafruit microSD SPI/SDIO breakout product 4682** — envelope `25.4 × 22.86 × 3.46 mm`; local hole centers `[[2.54, 2.54], [22.86, 2.54]]`; Ø`2.5`. Source/status: VERIFY: two-hole card-side orientation inferred from the Adafruit CAD/Eagle datum.
- **Adafruit SHT40 temperature/humidity breakout product 4885** — envelope `25.4 × 17.78 × 4.53 mm`; local hole centers `[[2.54, 2.54], [22.86, 2.54], [2.54, 15.24], [22.86, 15.24]]`; Ø`2.5`. Source/status: https://www.adafruit.com/product/4885.

The UPS is transformed from drawing coordinates with `world local (x,y) = (input y, 85 - input x)` so its 85 mm axis runs across the short enclosure dimension. The microSD two-hole Y datum/orientation is explicitly unverified; compare the purchased board against `reference_adafruit_microsd_4682.stl` before printing the body. The custom interface PCB has no released dimensions. V1 reserves a collision-free 55 × 55 mm envelope and supplies `interface_pcb_carrier_blank.stl`; all four body mounts are for that removable carrier, and no permanent PCB holes were invented. Lift the future PCB before accessing/replacing the carrier screws.

`ups_clearance_guard.stl` is deliberately a **clearance guard, not a cell retainer**. Four dedicated full-height posts and four short M2 thread-forming screws hold it 2 mm above the complete UPS envelope; it keeps loose wiring/lid features away from cells and lifts out from the top without removing the ESP32. It does not touch wrappers or terminals and provides no shock/vibration retention. Check it against the physical UPS, cells, insulators, terminals, and cable path before use.

## Electronics and pressure-channel gates

- Vehicle-facing sensor inputs require automotive-appropriate TVS/transient protection, current-limited or fused sensor power, reverse/overvoltage protection, and a star-grounded interface. Use an external ADC with a protected divider/filter front end for the nominal 0.5–4.5 V channels; do not connect 4.5 V directly to an ESP32 pin or treat its internal ADC as a production pressure instrument.
- The generic FUSCH 500 PSI listing lacks a primary manufacturer qualification package and is not frozen into this design. Sensata publishes R134a A/C sensor families including LOW 0.6–10.25 barA and HIGH 0.6–35 barA options, but exact orderable part numbers, electrical transfer, connector, wetted materials, proof/burst rating, and refrigerant/oil compatibility remain TBD through the manufacturer/authorized channel.
- No printed part carries refrigerant pressure. Pressure/hose hardware stays outside the case and needs independent pressure, temperature, chemical, strain-relief, and service-procedure review.

## Required first-article work

1. Print `panel_fit_coupon.stl` and record the selected variant for every purchased connector.
2. Print an insert/gasket corner section in the chosen material and process; tune hole shrink, elephant-foot compensation, gland finish, and screw torque.
3. Surface-finish the gasket land and groove. Raw FDM is porous and **is not IP-rated**. Perform an empty-enclosure leak/spray test, then a condensation/thermal-cycle test before installing electronics.
4. Bench-fit every exact board and cable bend. Verify cell removal with the lid off and verify no conductor can abrade on a printed edge.
5. Do not connect the service-port harness until refrigerant fittings, pressure ratings, strain relief, and technician procedures have been independently reviewed.

## Generated validation

- FreeCAD shape report: `{"assembly": {"bbox": {"max_mm": [207.20000000000002, 119.0, 55.0], "min_mm": [-7.199999999999999, -13.399933404838546, 0.0], "size_mm": [214.4, 132.39993340483855, 55.0]}, "solids": 2, "valid": true}, "body": {"bbox": {"max_mm": [207.20000000000002, 119.0, 50.000000000000036], "min_mm": [-7.199999999999999, -13.399933404838546, 0.0], "size_mm": [214.4, 132.39993340483855, 50.000000000000036]}, "solids": 1, "valid": true, "volume_mm3": 224011.47830488143}, "interface_pcb_carrier_blank": {"bbox": {"max_mm": [55.0, 55.0, 2.5], "min_mm": [0.0, 0.0, 0.0], "size_mm": [55.0, 55.0, 2.5]}, "solids": 1, "valid": true, "volume_mm3": 7483.230091830127}, "lid": {"bbox": {"max_mm": [207.20000000000002, 111.39993340483855, 5.0], "min_mm": [-7.199999999999999, -13.399933404838544, 0.0], "size_mm": [214.4, 124.7998668096771, 5.0]}, "solids": 1, "valid": true, "volume_mm3": 114403.82042507063}, "panel_fit_coupon": {"bbox": {"max_mm": [166.0, 58.0, 3.200000000000001], "min_mm": [0.0, 0.0, 0.0], "size_mm": [166.0, 58.0, 3.200000000000001]}, "solids": 1, "valid": true, "volume_mm3": 24334.365079655192}, "ups_clearance_guard": {"bbox": {"max_mm": [69.664, 66.0, 2.4], "min_mm": [0.0, 0.0, 0.0], "size_mm": [69.664, 66.0, 2.4]}, "solids": 1, "valid": true, "volume_mm3": 3399.668223156777}}`
- Component/keepout collision checks: `104` passed.
- Internal boss/tie/support checks: `160` passed.
- Lid-support service-face checks: `20` passed.
- Blender preview: `{"artifacts": ["preview_closed.png", "preview_layout.png", "workbench.blend"], "available": true, "exit_code": 0, "requested": true}`

## Sources

- weipu_sp1312: https://www.weipuconnector.com/wp-content/uploads/2023/04/SP1312-2D.png
- weipu_sp13_catalogue: https://www.weipuconnector.com/wp-content/uploads/2023/04/SP13-Series-WEIPU-Connector.pdf
- usb_qianrenon_b0bqhhf7sz: https://www.amazon.com/dp/B0BQHHF7SZ
- power_eswitch_pva6lrpw1241: https://datasheet.octopart.com/PVA6LRPW1241-E-Switch-datasheet-154835033.pdf
- vent_amphenol_ltw_o8002: https://www.amphenolltw.com/product-info/Vent/Vent.M12Plastic/VENT-PS1YGY-O8002.html
- oring_gland: https://www.trelleborg.com/seals/-/media/tss-media-repository/tss_website/pdf-and-other-literature/catalogs/o_ring_gb_en.pdf
- sensata_ac_pressure_family: https://www.sensata.com/products/pressure-sensors/ac-pressure-sensor-0
- sensata_ac_pressure_datasheet: https://www.sensata.com/sites/default/files/a/sensata-pressure-sensor-ac-datasheet.pdf?cb=c762a8c5
- waveshare_ups_hat_d: https://files.waveshare.com/wiki/UPS-HAT-D/UPS-HAT-D%203D%20Drawing.zip
- dfrobot_dfr0975: https://wiki.dfrobot.com/dfr0975
- adafruit_microsd_4682: https://www.adafruit.com/product/4682
- adafruit_sht40_4885: https://www.adafruit.com/product/4885
- interface_pcb_reserved: design reservation

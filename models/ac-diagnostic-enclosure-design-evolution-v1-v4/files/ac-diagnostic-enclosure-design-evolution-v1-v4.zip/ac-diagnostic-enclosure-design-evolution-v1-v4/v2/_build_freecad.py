
import json, math, os
import FreeCAD as App
import Part
import MeshPart
from FreeCAD import Vector

P = {'case_length_mm': 235.0, 'case_width_mm': 98.0, 'case_body_height_mm': 60.0, 'wall_mm': 3.0, 'floor_mm': 3.2, 'lid_thickness_mm': 5.0, 'mount_hole_spacing_mm': 50.0, 'mount_hole_d_mm': 9.2, 'sp13_hole_d_mm': 13.0, 'sp13_flat_mm': 11.8, 'usb_cutout_d_mm': 16.2, 'power_cutout_d_mm': 16.2, 'vent_cutout_d_mm': 12.2, 'gasket_cord_d_mm': 3.0}
FIXED = {'panel_web_mm': 3.0, 'panel_perimeter_rim_mm': 8.0, 'lid_flange_overhang_mm': 14.0, 'panel_screw_boss_r_mm': 5.0, 'panel_receiver_taper_mm': 30.0, 'panel_receiver_root_r_mm': 1.0, 'panel_screw_low_z_mm': 18.0, 'm3_panel_clearance_d_mm': 3.6, 'm3_lid_clearance_d_mm': 3.6, 'm3_insert_pocket_d_mm': 4.0, 'm3_insert_depth_mm': 6.7, 'tray_thickness_mm': 3.2, 'tray_wall_clearance_mm': 2.3, 'tray_rail_width_mm': 12.0, 'tray_mount_clearance_d_mm': 3.6, 'tray_screw_head_d_mm': 6.0, 'tray_service_lift_mm': 1.0, 'tray_service_min_clearance_mm': 1.0, 'minimum_clear_body_height_mm': 55.98, 'locating_tongue_clearance_mm': 0.6, 'cable_tie_slot_width_mm': 3.2, 'cable_tie_slot_height_mm': 4.0, 'tray_mount_insert_depth_mm': 5.0, 'mount_axis_offset_mm': 20.2, 'mount_gauge_depth_mm': 35.0, 'mount_gauge_width_mm': 86.7, 'power_flat_to_edge_mm': 15.4, 'wall_sacrificial_membrane_mm': 0.45, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0}
MECH = {'build_axis': 'enclosure +X maps to printer +Z', 'body_cap_interface_x_mm': 224.8, 'right_panel_depth_mm': 10.2, 'right_panel_web_mm': 3.0, 'tray_origin_mm': [5.0, 5.3, 8.2], 'tray_size_mm': [193.0, 87.4, 3.2], 'tray_side_clearance_mm': 2.3, 'tray_service_direction': '+Z lift, then +X toward removable right cap', 'tray_service_lift_mm': 1.0, 'tray_to_low_receiver_clearance_after_lift_mm': 2.7103826104804947, 'interface_carrier_to_rear_receiver_clearance_mm': 1.0, 'tray_mount_centers_xy_mm': [[75.0, 11.0], [75.0, 87.0], [190.0, 11.0], [160.0, 87.0]], 'panel_screw_centers_yz_mm': [[0.0, 18.0], [0.0, 32.0], [0.0, 50.0], [98.0, 18.0], [98.0, 32.0], [98.0, 50.0]], 'lid_screw_centers_xy_mm': [[25.0, -9.0], [80.0, -9.0], [140.0, -9.0], [200.0, -9.0], [25.0, 107.0], [80.0, 107.0], [140.0, 107.0], [200.0, 107.0]], 'tray_service_bay_mm': 26.80000000000001, 'standing_body_height_mm': 224.8, 'standing_footprint_mm': [60.0, 126.0], 'v400_build_volume_mm': [300.0, 300.0, 410.0]}
LAYOUT = {'waveshare_ups_hat_d': {'origin_mm': [7.0, 6.5, 17.4], 'size_mm': [62.464, 85.0, 31.38], 'hole_d_mm': 3.0, 'hole_centers_local_mm': [[3.5, 81.5], [3.5, 23.5], [52.5, 81.5], [52.5, 23.5]], 'hole_centers_world_mm': [[10.5, 88.0], [10.5, 30.0], [59.5, 88.0], [59.5, 30.0]], 'mount': 'M2.5 heat-set'}, 'interface_pcb_reserved': {'origin_mm': [94.0, 37.0, 19.9], 'size_mm': [55.0, 55.0, 15.0], 'hole_d_mm': 0.0, 'hole_centers_local_mm': [], 'hole_centers_world_mm': [], 'mount': 'M2.5 heat-set'}, 'dfrobot_dfr0975': {'origin_mm': [107.0, 6.5, 15.399999999999999], 'size_mm': [61.47, 25.4, 7.1], 'hole_d_mm': 2.0, 'hole_centers_local_mm': [[1.7, 1.7], [58.3, 1.7], [1.7, 23.7], [58.3, 23.7]], 'hole_centers_world_mm': [[108.7, 8.2], [165.3, 8.2], [108.7, 30.2], [165.3, 30.2]], 'mount': 'M1.6 provisional; verify Ø2.0 board holes'}, 'adafruit_microsd_4682': {'origin_mm': [171.0, 37.0, 15.399999999999999], 'size_mm': [25.4, 22.86, 3.46], 'hole_d_mm': 2.5, 'hole_centers_local_mm': [[2.54, 2.54], [22.86, 2.54]], 'hole_centers_world_mm': [[173.54, 39.54], [193.86, 39.54]], 'mount': 'M2 provisional; verify purchased board'}, 'adafruit_sht40_4885': {'origin_mm': [171.0, 68.0, 15.399999999999999], 'size_mm': [25.4, 17.78, 4.53], 'hole_d_mm': 2.5, 'hole_centers_local_mm': [[2.54, 2.54], [22.86, 2.54], [2.54, 15.24], [22.86, 15.24]], 'hole_centers_world_mm': [[173.54, 70.54], [193.86, 70.54], [173.54, 83.24], [193.86, 83.24]], 'mount': 'M2 provisional; verify purchased board'}}
PANEL = {'right': [{'name': 'HIGH_SP13', 'y_mm': 28.0, 'z_mm': 38.0, 'geometry': 'circle_with_opposing_flats', 'diameter_mm': 13.0, 'across_flats_mm': 11.8, 'status': 'manufacturer nominal'}, {'name': 'LOW_SP13', 'y_mm': 70.0, 'z_mm': 38.0, 'geometry': 'circle_with_opposing_flats', 'diameter_mm': 13.0, 'across_flats_mm': 11.8, 'status': 'manufacturer nominal'}, {'name': 'POWER', 'y_mm': 49.0, 'z_mm': 19.0, 'geometry': 'd_flat', 'diameter_mm': 16.2, 'flat_to_opposite_edge_mm': 15.4, 'status': 'manufacturer drawing; first-article fit required'}], 'front': [{'name': 'USB_C_CHARGE', 'x_mm': 87.0, 'z_mm': 30.0, 'geometry': 'circle', 'diameter_mm': 16.2, 'status': 'PROVISIONAL - measure purchased bulkhead and cable'}], 'rear': [{'name': 'VENT', 'x_mm': 175.0, 'z_mm': 30.0, 'geometry': 'circle', 'diameter_mm': 12.2, 'status': 'manufacturer nominal'}]}
OUT = 'out'
os.makedirs(OUT, exist_ok=True)

def die(message):
    print("CAD_ERROR " + message, flush=True)
    raise RuntimeError(message)

def rounded_prism(width, depth, height, radius, x=0.0, y=0.0, z=0.0):
    radius = max(0.0, min(radius, width / 2.0 - 0.01, depth / 2.0 - 0.01))
    if radius < 0.01:
        return Part.makeBox(width, depth, height, Vector(x, y, z))
    pieces = [
        Part.makeBox(width - 2.0 * radius, depth, height, Vector(x + radius, y, z)),
        Part.makeBox(width, depth - 2.0 * radius, height, Vector(x, y + radius, z)),
    ]
    for cx in (x + radius, x + width - radius):
        for cy in (y + radius, y + depth - radius):
            pieces.append(Part.makeCylinder(radius, height, Vector(cx, cy, z)))
    return pieces[0].multiFuse(pieces[1:]).removeSplitter()

def assert_solid(name, shape):
    if shape.isNull() or not shape.isValid() or len(shape.Solids) != 1 or shape.Volume <= 0:
        die("%s is not one valid positive-volume solid (solids=%d)" % (name, len(shape.Solids)))

def export_shape(shape, stem):
    shape.exportStep(os.path.join(OUT, stem + ".step"))
    mesh = MeshPart.meshFromShape(Shape=shape, LinearDeflection=0.08,
                                  AngularDeflection=0.25, Relative=False)
    mesh.write(os.path.join(OUT, stem + ".stl"))

def add_feature(doc, name, label, shape, color, transparency=0):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = shape
    try:
        obj.ViewObject.ShapeColor = color
        obj.ViewObject.Transparency = transparency
    except Exception:
        pass
    return obj

def front_round_hole(cx, cz, diameter, y0, depth):
    return Part.makeCylinder(diameter / 2.0, depth, Vector(cx, y0, cz), Vector(0, 1, 0))

def right_round_hole(cy, cz, diameter, x0, depth):
    return Part.makeCylinder(diameter / 2.0, depth, Vector(x0, cy, cz), Vector(1, 0, 0))

def right_opposing_flats(cy, cz, diameter, across_flats, x0, depth):
    cyl = right_round_hole(cy, cz, diameter, x0, depth)
    clip = Part.makeBox(depth, across_flats, diameter + 2.0,
                        Vector(x0, cy - across_flats / 2.0, cz - diameter / 2.0 - 1.0))
    return cyl.common(clip).removeSplitter()

def right_d_flat(cy, cz, diameter, flat_to_edge, x0, depth):
    radius = diameter / 2.0
    yflat = cy + radius - flat_to_edge
    cyl = right_round_hole(cy, cz, diameter, x0, depth)
    clip = Part.makeBox(depth, flat_to_edge, diameter + 2.0,
                        Vector(x0, yflat, cz - radius - 1.0))
    return cyl.common(clip).removeSplitter()

def panel_round_hole(cx, cy, diameter, z0, depth):
    return Part.makeCylinder(diameter / 2.0, depth, Vector(cx, cy, z0))

def panel_opposing_flats(cx, cy, diameter, across_flats, z0, depth):
    cyl = panel_round_hole(cx, cy, diameter, z0, depth)
    clip = Part.makeBox(across_flats, diameter + 2.0, depth,
                        Vector(cx - across_flats / 2.0, cy - diameter / 2.0 - 1.0, z0))
    return cyl.common(clip).removeSplitter()

def panel_d_flat(cx, cy, diameter, flat_to_edge, z0, depth):
    radius = diameter / 2.0
    xflat = cx + radius - flat_to_edge
    cyl = panel_round_hole(cx, cy, diameter, z0, depth)
    clip = Part.makeBox(flat_to_edge, diameter + 2.0, depth,
                        Vector(xflat, cy - radius - 1.0, z0))
    return cyl.common(clip).removeSplitter()

def bbox(shape):
    b = shape.BoundBox
    return {"min_mm": [b.XMin, b.YMin, b.ZMin],
            "max_mm": [b.XMax, b.YMax, b.ZMax],
            "size_mm": [b.XLength, b.YLength, b.ZLength]}

L = P["case_length_mm"]
W = P["case_width_mm"]
H = P["case_body_height_mm"]
WALL = P["wall_mm"]
FLOOR = P["floor_mm"]
LID_T = P["lid_thickness_mm"]
CORD = P["gasket_cord_d_mm"]
GROOVE_W = CORD + 1.0
GROOVE_D = CORD * (2.3 / 3.0)
SEAL_LAND = CORD + 7.2
SEAL_OVERHANG = max(0.0, SEAL_LAND - WALL)
FLANGE_OVERHANG = FIXED["lid_flange_overhang_mm"]
CAP_X = MECH["body_cap_interface_x_mm"]
CAP_DEPTH = MECH["right_panel_depth_mm"]
PANEL_WEB = FIXED["panel_web_mm"]

# Axially constant U-shell.  X=0 is a complete, planar bed face.  The right
# end remains open and receives a separately printed cap, so no 92 x 56 mm
# roof is bridged at the top of a 225 mm standing print.
outer = Part.makeBox(CAP_X, W, H)
cavity = Part.makeBox(CAP_X - WALL + 2.0, W - 2.0 * WALL, H - FLOOR + 2.0,
                      Vector(WALL, WALL, FLOOR))
body = outer.cut(cavity).removeSplitter()

# Continuous long-side sealing shoulders are support-free with +X as build Z.
top_t = max(4.0, WALL)
screw_rail_t = max(top_t, FIXED["m3_insert_depth_mm"] + 1.5)
front_seal = Part.makeBox(CAP_X, WALL + FLANGE_OVERHANG, screw_rail_t,
                          Vector(0.0, -FLANGE_OVERHANG, H - screw_rail_t))
rear_seal = Part.makeBox(CAP_X, WALL + FLANGE_OVERHANG, screw_rail_t,
                         Vector(0.0, W - WALL, H - screw_rail_t))
# Only the front/rear rails contain lid inserts. Keeping the closed left-end
# gasket land at four mm preserves clearance above the UPS guard.
left_seal = Part.makeBox(SEAL_LAND, W + 2.0 * FLANGE_OVERHANG, top_t,
                         Vector(0.0, -FLANGE_OVERHANG, H - top_t))
body = body.multiFuse([front_seal, rear_seal, left_seal]).removeSplitter()

# Longitudinal lower rails carry the removable sled.  They start at the bed
# face and never appear as isolated mid-print islands.
rail_top = FLOOR + 5.0
tray_rail_w = FIXED["tray_rail_width_mm"]
front_tray_rail = Part.makeBox(CAP_X, tray_rail_w, rail_top - FLOOR,
                               Vector(0.0, WALL, FLOOR))
rear_tray_rail = Part.makeBox(CAP_X, tray_rail_w, rail_top - FLOOR,
                              Vector(0.0, W - WALL - tray_rail_w, FLOOR))
body = body.multiFuse([front_tray_rail, rear_tray_rail]).removeSplitter()

tray_mount_centers = MECH["tray_mount_centers_xy_mm"]
tray_insert_pockets = []
for tx, ty in tray_mount_centers:
    tray_insert_pockets.append(Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["tray_mount_insert_depth_mm"] + 0.3,
        Vector(tx, ty, rail_top - FIXED["tray_mount_insert_depth_mm"])))
body = body.cut(Part.makeCompound(tray_insert_pockets)).removeSplitter()

# Six axial end-cap receivers expand gradually over their final 30 mm. In the
# standing orientation that is a shallow, support-free slope rather than six
# full-length external cylinders or isolated horizontal bosses.
panel_screw_centers = MECH["panel_screw_centers_yz_mm"]
receiver_r = FIXED["panel_screw_boss_r_mm"]
receiver_taper = FIXED["panel_receiver_taper_mm"]
receivers = []
receiver_pockets = []
for py, pz in panel_screw_centers:
    receivers.append(Part.makeCone(
        FIXED["panel_receiver_root_r_mm"], receiver_r, receiver_taper,
        Vector(CAP_X - receiver_taper, py, pz), Vector(1, 0, 0)))
    receiver_pockets.append(Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["m3_insert_depth_mm"] + 0.4,
        Vector(CAP_X - FIXED["m3_insert_depth_mm"], py, pz), Vector(1, 0, 0)))
body = body.multiFuse(receivers).removeSplitter()
body = body.cut(Part.makeCompound(receiver_pockets)).removeSplitter()

# USB charge stays on the long front wall; the hydrophobic vent stays rear.
# A one-perimeter sacrificial membrane supports each horizontal tunnel during
# the standing print. Remove it and finish the opening only after the wall-hole
# orientation coupon has passed in the production material/profile.
front_feature = PANEL["front"][0]
vent_feature = PANEL["rear"][0]
membrane = FIXED["wall_sacrificial_membrane_mm"]
body = body.cut(front_round_hole(front_feature["x_mm"], front_feature["z_mm"],
                                 front_feature["diameter_mm"], membrane,
                                 WALL + 1.0))
body = body.cut(Part.makeCylinder(
    vent_feature["diameter_mm"] / 2.0, WALL + 1.0 - membrane,
                                  Vector(vent_feature["x_mm"], W - WALL - 1.0,
                                         vent_feature["z_mm"]), Vector(0, 1, 0)))

# Lid insert locations sit in continuous seal rails rather than discrete ears.
lid_screw_centers = MECH["lid_screw_centers_xy_mm"]
lid_insert_pockets = [Part.makeCylinder(
    FIXED["m3_insert_pocket_d_mm"] / 2.0,
    FIXED["m3_insert_depth_mm"] + 0.3,
    Vector(x, y, H - FIXED["m3_insert_depth_mm"])) for x, y in lid_screw_centers]
body = body.cut(Part.makeCompound(lid_insert_pockets)).removeSplitter()
assert_solid("standing body", body)
export_shape(body, "body")

# Print-oriented body: original +X becomes printer +Z.  The flush X=0 face is
# exactly on Z=0 and all permanent features are longitudinal.
body_standing = body.copy()
body_standing.rotate(Vector(0, 0, 0), Vector(0, 1, 0), -90.0)
body_standing.translate(Vector(H, FLANGE_OVERHANG, 0.0))
assert_solid("standing-oriented body", body_standing)
export_shape(body_standing, "body_standing")

# Right I/O cap, installed form.  A 3 mm central web respects panel-hardware
# thickness while the 10.2 mm perimeter rim carries screws and the lid land.
cap_web = Part.makeBox(PANEL_WEB, W, H, Vector(L - PANEL_WEB, 0.0, 0.0))
rim = FIXED["panel_perimeter_rim_mm"]
clamp_bar_y0 = MECH["tray_origin_mm"][1]
clamp_bar_w = MECH["tray_size_mm"][1]
clamp_bar_h = 10.0
clamp_bar_t = 4.0
# Keep the clamp tied to the two fixed SP13 wire-turn corridors rather than
# to the variable roof height. At the default H=60 this remains Z=44.
clamp_bar_z0 = PANEL["right"][0]["z_mm"] + 6.0
clamp_boss_depth = 28.0
clamp_boss_r = 4.0
clamp_mount_ys = [clamp_bar_y0 + 5.0, clamp_bar_y0 + clamp_bar_w - 5.0]
clamp_mount_z = clamp_bar_z0 + clamp_bar_h / 2.0
cap_parts = [
    cap_web,
    Part.makeBox(CAP_DEPTH, rim, H, Vector(CAP_X, 0.0, 0.0)),
    Part.makeBox(CAP_DEPTH, rim, H, Vector(CAP_X, W - rim, 0.0)),
    Part.makeBox(CAP_DEPTH, W, rim, Vector(CAP_X, 0.0, 0.0)),
    Part.makeBox(CAP_DEPTH, W + 2.0 * FLANGE_OVERHANG, top_t,
                 Vector(CAP_X, -FLANGE_OVERHANG, H - top_t)),
]
# Four shallow locating tabs enter the shell and hold the cap close to its
# installed datum while the screws are started. They are not a waterproof
# seal.
tongue_depth = 2.5
tongue_t = 1.5
tongue_clear = FIXED["locating_tongue_clearance_mm"]
tongue_x = CAP_X - tongue_depth
tongue_overlap_depth = tongue_depth + 0.2
# The axial panel receivers are centred on Y=0/Y=W and reach a 5 mm radius
# at the mating face. Float the side legs just beyond those envelopes; the M3
# clearance holes provide final lateral registration. The bottom leg retains
# the close floor datum without crossing a receiver.
tongue_front_y = max(WALL + tongue_clear, receiver_r + tongue_clear)
tongue_rear_y = min(W - WALL - tongue_clear - tongue_t,
                    W - receiver_r - tongue_clear - tongue_t)
tongue_side_wall_float = tongue_front_y - WALL
tongue_bottom_z = FLOOR + tongue_clear
tongue_floor_tab_w = 18.0
tongue_floor_ys = [WALL + tray_rail_w + tongue_clear,
                   W - WALL - tray_rail_w - tongue_clear - tongue_floor_tab_w]
# Side tabs begin above the full-length sled rails; floor tabs sit between
# those rails and stay away from the central power-connector rear keepout.
tongue_side_z = rail_top + tongue_clear
tongue_side_h = H - top_t - tongue_clear - tongue_side_z
cap_parts += [
    Part.makeBox(tongue_overlap_depth, tongue_floor_tab_w, tongue_t,
                 Vector(tongue_x, tongue_floor_ys[0], tongue_bottom_z)),
    Part.makeBox(tongue_overlap_depth, tongue_floor_tab_w, tongue_t,
                 Vector(tongue_x, tongue_floor_ys[1], tongue_bottom_z)),
    Part.makeBox(tongue_overlap_depth, tongue_t, tongue_side_h,
                 Vector(tongue_x, tongue_front_y, tongue_side_z)),
    Part.makeBox(tongue_overlap_depth, tongue_t, tongue_side_h,
                 Vector(tongue_x, tongue_rear_y, tongue_side_z)),
]
for clamp_y in clamp_mount_ys:
    cap_parts.append(Part.makeCylinder(
        clamp_boss_r, clamp_boss_depth,
        Vector(L, clamp_y, clamp_mount_z), Vector(-1, 0, 0)))
    # Tie each long clamp boss back to its nearest cap side rim with a full-
    # depth rib. These print from the cap's exterior bed face and resist the
    # cable clamp's cantilever load without creating an isolated feature.
    rib_y = clamp_y - clamp_boss_r if clamp_y < W / 2.0 else clamp_y
    cap_parts.append(Part.makeBox(
        clamp_boss_depth, clamp_boss_r, 3.0,
        Vector(L - clamp_boss_depth, rib_y, clamp_mount_z - 1.5)))
for py, pz in panel_screw_centers:
    cap_parts.append(Part.makeCylinder(receiver_r, CAP_DEPTH,
                                       Vector(CAP_X, py, pz), Vector(1, 0, 0)))
cap_installed = cap_parts[0].multiFuse(cap_parts[1:]).removeSplitter()
right_cutters = []
for feature in PANEL["right"]:
    x0 = L - PANEL_WEB - 1.0
    depth = PANEL_WEB + 2.0
    if feature["geometry"] == "circle_with_opposing_flats":
        cutter = right_opposing_flats(feature["y_mm"], feature["z_mm"],
                                      feature["diameter_mm"], feature["across_flats_mm"],
                                      x0, depth)
    elif feature["geometry"] == "d_flat":
        cutter = right_d_flat(feature["y_mm"], feature["z_mm"],
                              feature["diameter_mm"], feature["flat_to_opposite_edge_mm"],
                              x0, depth)
    else:
        cutter = right_round_hole(feature["y_mm"], feature["z_mm"],
                                  feature["diameter_mm"], x0, depth)
    right_cutters.append(cutter)
panel_clearance_cutters = [Part.makeCylinder(
    FIXED["m3_panel_clearance_d_mm"] / 2.0, CAP_DEPTH + 2.0,
    Vector(CAP_X - 1.0, py, pz), Vector(1, 0, 0)) for py, pz in panel_screw_centers]
clamp_insert_cutters = [Part.makeCylinder(
    FIXED["m3_insert_pocket_d_mm"] / 2.0,
    FIXED["m3_insert_depth_mm"] + 0.4,
    Vector(L - clamp_boss_depth - 0.1, clamp_y, clamp_mount_z), Vector(1, 0, 0))
    for clamp_y in clamp_mount_ys]
cap_installed = cap_installed.cut(Part.makeCompound(
    right_cutters + panel_clearance_cutters + clamp_insert_cutters)).removeSplitter()
assert_solid("installed right I/O cap", cap_installed)
export_shape(cap_installed, "reference_right_io_panel_installed")

# Two exact, cropped interface coupons reproduce the front/low body receiver,
# axial insert pocket, cap screw passage, and one side locating tab. Build the
# intersections before any print transforms or repeated clearance booleans so
# OCC operates on pristine production solids.
interface_y_min = -6.0
interface_y_span = 21.0
interface_z_min = 8.0
interface_z_span = 22.0
if (interface_y_min > -receiver_r or
        interface_y_min + interface_y_span < receiver_r + tongue_t):
    die("cap interface coupon crop does not enclose receiver and locating tab")
body_interface_crop = Part.makeBox(
    16.0, interface_y_span, interface_z_span,
    Vector(CAP_X - 16.0, interface_y_min, interface_z_min))
body_interface_coupon = body.common(body_interface_crop).removeSplitter()
body_interface_coupon.rotate(Vector(0, 0, 0), Vector(0, 1, 0), -90.0)
body_interface_coupon.translate(Vector(H, FLANGE_OVERHANG, 0.0))
body_coupon_bb = body_interface_coupon.BoundBox
body_interface_coupon.translate(Vector(-body_coupon_bb.XMin, -body_coupon_bb.YMin,
                                       -body_coupon_bb.ZMin))
assert_solid("body-side cap interface coupon", body_interface_coupon)
export_shape(body_interface_coupon, "cap_interface_body_coupon")

cap_interface_crop = Part.makeBox(
    CAP_DEPTH + tongue_depth + 1.0, interface_y_span, interface_z_span,
    Vector(CAP_X - tongue_depth - 0.5, interface_y_min, interface_z_min))
cap_coupon_pieces = []
for cap_piece in cap_parts:
    clipped_piece = cap_piece.common(cap_interface_crop).removeSplitter()
    if clipped_piece.Volume > 1.0e-6:
        cap_coupon_pieces.append(clipped_piece)
if not cap_coupon_pieces:
    die("panel-side cap interface coupon crop missed all production primitives")
cap_interface_coupon = cap_coupon_pieces[0].multiFuse(
    cap_coupon_pieces[1:]).removeSplitter()
cap_interface_coupon = cap_interface_coupon.cut(Part.makeCompound(
    right_cutters + panel_clearance_cutters + clamp_insert_cutters)).removeSplitter()
cap_interface_coupon.rotate(Vector(0, 0, 0), Vector(1, 1, -1), 120.0)
cap_interface_coupon.translate(Vector(FLANGE_OVERHANG, H, L))
cap_coupon_bb = cap_interface_coupon.BoundBox
cap_interface_coupon.translate(Vector(-cap_coupon_bb.XMin, -cap_coupon_bb.YMin,
                                      -cap_coupon_bb.ZMin))
assert_solid("panel-side cap interface coupon", cap_interface_coupon)
export_shape(cap_interface_coupon, "cap_interface_panel_coupon")

# Derive the printable cap from the installed solid instead of rebuilding it.
# This guarantees that the clamp insert pockets, locating tabs, and every
# panel cutout are identical in the assembly and STL. A +120 degree rotation
# about (1,1,-1) maps world X/Y/Z to print -Z/X/-Y; the translation places the
# exterior face on Z=0 and keeps the complete mesh in positive coordinates.
cap_print = cap_installed.copy()
cap_print.rotate(Vector(0, 0, 0), Vector(1, 1, -1), 120.0)
cap_print.translate(Vector(FLANGE_OVERHANG, H, L))
cap_print = cap_print.removeSplitter()
cap_transform_volume_delta = abs(cap_print.Volume - cap_installed.Volume)
if cap_transform_volume_delta >= 1.0e-5:
    die("print cap differs from installed cap after rigid transform")
assert_solid("print-oriented right I/O cap", cap_print)
export_shape(cap_print, "right_io_panel")

# Removable internal clamp bar. It screws to two bosses on the cap, so the
# panel and both restrained sensor pigtails can leave as one service assembly.
clamp_bar = rounded_prism(clamp_bar_w, clamp_bar_h, clamp_bar_t, 2.0)
clamp_holes = [Part.makeCylinder(
    FIXED["m3_panel_clearance_d_mm"] / 2.0, clamp_bar_t + 2.0,
    Vector(local_y, clamp_bar_h / 2.0, -1.0))
    for local_y in (5.0, clamp_bar_w - 5.0)]
clamp_slots = []
for feature in PANEL["right"][:2]:
    local_center = feature["y_mm"] - clamp_bar_y0
    for offset in (-5.0, 5.0):
        clamp_slots.append(Part.makeBox(
            FIXED["cable_tie_slot_width_mm"], FIXED["cable_tie_slot_height_mm"],
            clamp_bar_t + 2.0,
            Vector(local_center + offset - FIXED["cable_tie_slot_width_mm"] / 2.0,
                   (clamp_bar_h - FIXED["cable_tie_slot_height_mm"]) / 2.0, -1.0)))
clamp_bar = clamp_bar.cut(Part.makeCompound(clamp_holes + clamp_slots)).removeSplitter()
assert_solid("cable strain-relief clamp bar", clamp_bar)
export_shape(clamp_bar, "cable_strain_relief_bar")

clamp_installed_x = L - clamp_boss_depth - clamp_bar_t
# Transform the printable bar itself into assembly coordinates so rounded
# corners, screw holes, and tie slots are identical in both representations.
# A +120 degree rotation about (1,1,1) maps local X/Y/Z to world Y/Z/X.
clamp_bar_installed = clamp_bar.copy()
clamp_bar_installed.rotate(Vector(0, 0, 0), Vector(1, 1, 1), 120.0)
clamp_bar_installed.translate(Vector(clamp_installed_x, clamp_bar_y0, clamp_bar_z0))
clamp_transform_volume_delta = abs(clamp_bar_installed.Volume - clamp_bar.Volume)
if clamp_transform_volume_delta >= 1.0e-5:
    die("installed clamp differs from printable clamp after rigid transform")
assert_solid("installed cable clamp bar", clamp_bar_installed)
export_shape(clamp_bar_installed, "reference_cable_strain_relief_bar_installed")

# Removable electronics sled.  It prints flat; component bosses grow in +Z.
tray_x, tray_y, tray_z = MECH["tray_origin_mm"]
tray_l, tray_w, tray_t = MECH["tray_size_mm"]
tray = rounded_prism(tray_l, tray_w, tray_t, 3.0)
tray_mount_cutters = [Part.makeCylinder(
    FIXED["tray_mount_clearance_d_mm"] / 2.0, tray_t + 2.0,
    Vector(world_x - tray_x, world_y - tray_y, -1.0))
    for world_x, world_y in tray_mount_centers]
tray_mount_compound = Part.makeCompound(tray_mount_cutters)

bosses = []
boss_pockets = []
carrier_mounts = [[100.0, 43.0], [143.0, 43.0], [100.0, 86.0], [143.0, 86.0]]
for name, item in LAYOUT.items():
    if name == "interface_pcb_reserved":
        holes = carrier_mounts
        boss_od, pilot_d, boss_h, pilot_depth = 7.0, 4.0, 6.0, 5.0
    elif name == "waveshare_ups_hat_d":
        holes = item["hole_centers_world_mm"]
        boss_od, pilot_d, boss_h, pilot_depth = 7.0, 4.0, 6.0, 5.0
    elif name == "dfrobot_dfr0975":
        holes = item["hole_centers_world_mm"]
        boss_od, pilot_d, boss_h, pilot_depth = 4.4, 1.4, 4.0, 3.2
    else:
        holes = item["hole_centers_world_mm"]
        boss_od, pilot_d, boss_h, pilot_depth = 5.2, 1.7, 4.0, 3.2
    for hx, hy in holes:
        lx, ly = hx - tray_x, hy - tray_y
        bosses.append(Part.makeCylinder(boss_od / 2.0, boss_h,
                                        Vector(lx, ly, tray_t - 0.05)))
        boss_pockets.append(Part.makeCylinder(pilot_d / 2.0, pilot_depth + 0.3,
                                              Vector(lx, ly, tray_t + boss_h - pilot_depth)))
for boss_index, boss in enumerate(bosses):
    overlap = boss.common(tray_mount_compound).Volume
    if overlap >= 1.0e-5:
        die("component boss %d refills or blocks a tray mounting hole (%.6f mm3)" %
            (boss_index, overlap))
tray = tray.multiFuse(bosses).removeSplitter()
tray = tray.cut(Part.makeCompound(boss_pockets)).removeSplitter()
tray = tray.cut(tray_mount_compound).removeSplitter()
assert_solid("electronics sled", tray)
export_shape(tray, "electronics_tray")
tray_installed = tray.copy()
tray_installed.translate(Vector(tray_x, tray_y, tray_z))
export_shape(tray_installed, "reference_electronics_tray_installed")

# Future-drill interface carrier remains cheap and replaceable.
carrier = rounded_prism(55.0, 55.0, 2.5, 2.0)
carrier_holes = [Part.makeCylinder(1.5, 4.5, Vector(hx - 94.0, hy - 37.0, -1.0))
                 for hx, hy in carrier_mounts]
carrier = carrier.cut(Part.makeCompound(carrier_holes)).removeSplitter()
assert_solid("interface carrier", carrier)
export_shape(carrier, "interface_pcb_carrier_blank")
carrier_installed = carrier.copy()
carrier_installed.translate(Vector(94.0, 37.0, LAYOUT["interface_pcb_reserved"]["origin_mm"][2] - 2.5))
export_shape(carrier_installed, "reference_interface_pcb_carrier_installed")

# The UPS rests on the tray's 6 mm printed bosses. The guard uses selected
# upper metal spacers above the UPS rather than a second tall printed tower.
ups = LAYOUT["waveshare_ups_hat_d"]
ux, uy, uz = ups["origin_mm"]
uw, ud, uh = ups["size_mm"]
guard_x0, guard_y0 = ux, uy
guard_l, guard_w, guard_t = uw, ud, 2.4
guard_frame_w = 7.0
guard = (Part.makeBox(guard_l, guard_frame_w, guard_t)
         .multiFuse([Part.makeBox(guard_l, guard_frame_w, guard_t,
                                  Vector(0.0, guard_w - guard_frame_w, 0.0)),
                     Part.makeBox(guard_frame_w, guard_w, guard_t),
                     Part.makeBox(guard_frame_w, guard_w, guard_t,
                                  Vector(guard_l - guard_frame_w, 0.0, 0.0))])
         .removeSplitter())
# Reuse the four UPS mounting axes for a stacked metal-spacer arrangement;
# the printed tray already carries inserts at these exact locations.
guard_holes_local = [[hx - ux, hy - uy] for hx, hy in ups["hole_centers_world_mm"]]
guard_pad_r = 3.5
guard = guard.multiFuse([
    Part.makeCylinder(guard_pad_r, guard_t, Vector(gx, gy, 0.0))
    for gx, gy in guard_holes_local]).removeSplitter()
guard = guard.cut(Part.makeCompound([
    Part.makeCylinder(1.35, guard_t + 2.0, Vector(gx, gy, -1.0))
    for gx, gy in guard_holes_local])).removeSplitter()
assert_solid("UPS clearance guard", guard)
export_shape(guard, "ups_clearance_guard")
guard_z = uz + uh + 2.0
guard_installed = guard.copy()
guard_installed.translate(Vector(guard_x0, guard_y0, guard_z))
export_shape(guard_installed, "reference_ups_clearance_guard_installed")

# Reference component envelopes.
component_shapes = {}
for name, item in LAYOUT.items():
    ox, oy, oz = item["origin_mm"]
    sx, sy, sz = item["size_mm"]
    shape = Part.makeBox(sx, sy, sz, Vector(ox, oy, oz))
    holes = [Part.makeCylinder(item["hole_d_mm"] / 2.0, sz + 2.0,
                               Vector(hx, hy, oz - 1.0))
             for hx, hy in item["hole_centers_world_mm"]]
    if holes:
        shape = shape.cut(Part.makeCompound(holes)).removeSplitter()
    assert_solid(name, shape)
    component_shapes[name] = shape
    export_shape(shape, "reference_" + name)

# Complete panel bodies and routed cable volumes, not only nominal cutouts.
inner_web_x = L - PANEL_WEB
keepouts = {
    "high_sp13_rear": Part.makeCylinder(11.0, 25.0,
        Vector(inner_web_x, PANEL["right"][0]["y_mm"], PANEL["right"][0]["z_mm"]), Vector(-1, 0, 0)),
    "low_sp13_rear": Part.makeCylinder(11.0, 25.0,
        Vector(inner_web_x, PANEL["right"][1]["y_mm"], PANEL["right"][1]["z_mm"]), Vector(-1, 0, 0)),
    "high_sp13_upper_turn": Part.makeBox(30.0, 22.0, 14.0,
        Vector(inner_web_x - 55.0, PANEL["right"][0]["y_mm"] - 11.0, 43.0)),
    "low_sp13_upper_turn": Part.makeBox(30.0, 22.0, 14.0,
        Vector(inner_web_x - 55.0, PANEL["right"][1]["y_mm"] - 11.0, 43.0)),
    "power_rear": Part.makeBox(25.0, 18.5, 18.5,
        Vector(inner_web_x - 25.0, PANEL["right"][2]["y_mm"] - 9.25,
               PANEL["right"][2]["z_mm"] - 9.25)),
    "power_upper_turn": Part.makeBox(30.0, 18.5, 10.0,
        Vector(inner_web_x - 55.0, PANEL["right"][2]["y_mm"] - 9.25, 29.0)),
    "usb_rear": Part.makeBox(34.0, 26.0, 26.0,
        Vector(PANEL["front"][0]["x_mm"] - 17.0, WALL, PANEL["front"][0]["z_mm"] - 13.0)),
    "usb_upper_turn": Part.makeBox(34.0, 26.0, 12.0,
        Vector(PANEL["front"][0]["x_mm"] - 17.0, WALL + 26.0, 43.0)),
    "vent_rear": Part.makeBox(16.0, 8.0, 16.0,
        Vector(PANEL["rear"][0]["x_mm"] - 8.0, W - WALL - 8.0,
               PANEL["rear"][0]["z_mm"] - 8.0)),
    "microsd_front_extraction": Part.makeBox(25.4, 25.0, 7.0,
        Vector(LAYOUT["adafruit_microsd_4682"]["origin_mm"][0], 12.0,
               LAYOUT["adafruit_microsd_4682"]["origin_mm"][2] - 1.0)),
    "sht40_lead_service": Part.makeBox(25.4, 8.0, 8.0,
        Vector(LAYOUT["adafruit_sht40_4885"]["origin_mm"][0], 60.0,
               LAYOUT["adafruit_sht40_4885"]["origin_mm"][2] - 1.0)),
}
external_keepouts = {
    "high_sp13_mated_external_provisional": Part.makeCylinder(12.0, 55.0,
        Vector(L, PANEL["right"][0]["y_mm"], PANEL["right"][0]["z_mm"]), Vector(1, 0, 0)),
    "low_sp13_mated_external_provisional": Part.makeCylinder(12.0, 55.0,
        Vector(L, PANEL["right"][1]["y_mm"], PANEL["right"][1]["z_mm"]), Vector(1, 0, 0)),
}

collision_checks = []
names = list(component_shapes)
for index, first in enumerate(names):
    for second in names[index + 1:]:
        overlap = component_shapes[first].common(component_shapes[second]).Volume
        passed = overlap < 1.0e-5
        collision_checks.append({"pair": [first, second], "overlap_mm3": overlap, "pass": passed})
        if not passed:
            die("component overlap: %s / %s" % (first, second))
for component_name, component_shape in component_shapes.items():
    for keepout_name, keepout in keepouts.items():
        overlap = component_shape.common(keepout).Volume
        passed = overlap < 1.0e-5
        collision_checks.append({"pair": [component_name, keepout_name],
                                 "overlap_mm3": overlap, "pass": passed})
        if not passed:
            die("component/route overlap: %s / %s = %.6f" %
                (component_name, keepout_name, overlap))
    overlap = component_shape.common(body).Volume
    passed = overlap < 1.0e-5
    collision_checks.append({"pair": [component_name, "body"],
                             "overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("component/body overlap: %s" % component_name)
for keepout_name, keepout in keepouts.items():
    overlap = keepout.common(cap_installed).Volume
    passed = overlap < 1.0e-5
    collision_checks.append({"pair": [keepout_name, "right_io_panel"],
                             "overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("connector/route keepout intersects reinforced right cap: %s = %.6f" %
            (keepout_name, overlap))
for keepout_name, keepout in external_keepouts.items():
    overlap = keepout.common(cap_installed).Volume
    passed = overlap < 1.0e-5
    collision_checks.append({"pair": [keepout_name, "right_io_panel"],
                             "overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("external connector keepout intersects right cap: %s = %.6f" %
            (keepout_name, overlap))
cap_body_overlap = cap_installed.common(body).Volume
collision_checks.append({"pair": ["right_io_panel", "body"],
                         "overlap_mm3": cap_body_overlap,
                         "pass": cap_body_overlap < 1.0e-5})
if cap_body_overlap >= 1.0e-5:
    die("right-cap locating tongue does not retain shell clearance")
if tray_installed.common(body).Volume >= 1.0e-5:
    die("electronics tray overlaps body rather than retaining rail clearance")
if guard_installed.common(component_shapes["waveshare_ups_hat_d"]).Volume >= 1.0e-5:
    die("UPS guard touches the UPS/cell envelope")
guard_body_overlap = guard_installed.common(body).Volume
collision_checks.append({"pair": ["ups_guard", "body"],
                         "overlap_mm3": guard_body_overlap,
                         "pass": guard_body_overlap < 1.0e-5})
if guard_body_overlap >= 1.0e-5:
    die("UPS guard intersects enclosure body")
for keepout_name, keepout in keepouts.items():
    overlap = guard_installed.common(keepout).Volume
    passed = overlap < 1.0e-5
    collision_checks.append({"pair": ["ups_guard", keepout_name],
                             "overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("UPS guard/route overlap: %s = %.6f" % (keepout_name, overlap))
if guard_installed.BoundBox.ZMax > H - 5.0:
    die("UPS guard lacks 5 mm lid/service clearance")
clamp_body_overlap = clamp_bar_installed.common(body).Volume
collision_checks.append({"pair": ["cable_clamp_bar", "body"],
                         "overlap_mm3": clamp_body_overlap,
                         "pass": clamp_body_overlap < 1.0e-5})
if clamp_body_overlap >= 1.0e-5:
    die("cable clamp bar intersects enclosure body")
for component_name, component_shape in component_shapes.items():
    overlap = clamp_bar_installed.common(component_shape).Volume
    passed = overlap < 1.0e-5
    collision_checks.append({"pair": ["cable_clamp_bar", component_name],
                             "overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("cable clamp bar blocks component: %s" % component_name)
clamp_engagement = []
for turn_name in ("high_sp13_upper_turn", "low_sp13_upper_turn"):
    overlap = clamp_bar_installed.common(keepouts[turn_name]).Volume
    passed = overlap > 1.0e-5
    clamp_engagement.append({"route": turn_name, "engagement_mm3": overlap,
                             "pass": passed})
    if not passed:
        die("cable clamp bar misses intended route: %s" % turn_name)

# Prove the populated sled can be lifted off its four removed M3 screws and
# extracted continuously toward the open right side. The lid, cap, screws,
# and detachable internal service loops are removed first.
service_parts = [tray_installed, carrier_installed, guard_installed] + list(component_shapes.values())
service_lift = FIXED["tray_service_lift_mm"]
lifted_parts = []
for lift_fraction in (0.5, 1.0):
    lift_check_parts = []
    for shape in service_parts:
        moved = shape.copy()
        moved.translate(Vector(0.0, 0.0, service_lift * lift_fraction))
        lift_check_parts.append(moved)
        if lift_fraction == 1.0:
            lifted_parts.append(moved)
    if Part.makeCompound(lift_check_parts).common(body).Volume >= 1.0e-5:
        die("populated tray cannot lift clear of its support rails")
lifted = Part.makeCompound(lifted_parts)
extraction_delta = CAP_X - tray_x
extraction_step_max = 2.0
extraction_samples = int(math.ceil(extraction_delta / extraction_step_max)) + 1
max_extraction_overlap = 0.0
minimum_receiver_clearance = None
minimum_body_clearance = None
receiver_compound = Part.makeCompound(receivers)
for sample_index in range(extraction_samples):
    dx = extraction_delta * sample_index / (extraction_samples - 1)
    sample = lifted.copy()
    sample.translate(Vector(dx, 0.0, 0.0))
    overlap = sample.common(body).Volume
    max_extraction_overlap = max(max_extraction_overlap, overlap)
    if overlap >= 1.0e-5:
        die("populated tray extraction intersects body at X travel %.3f mm" % dx)
    body_clearance = sample.distToShape(body)[0]
    if minimum_body_clearance is None:
        minimum_body_clearance = body_clearance
    else:
        minimum_body_clearance = min(minimum_body_clearance, body_clearance)
    receiver_clearance = sample.distToShape(receiver_compound)[0]
    if minimum_receiver_clearance is None:
        minimum_receiver_clearance = receiver_clearance
    else:
        minimum_receiver_clearance = min(minimum_receiver_clearance,
                                         receiver_clearance)
if (minimum_receiver_clearance is None or
        minimum_receiver_clearance + 1.0e-5 < FIXED["tray_service_min_clearance_mm"]):
    die("populated tray extraction lacks %.1f mm receiver clearance (%.3f mm)" %
        (FIXED["tray_service_min_clearance_mm"], minimum_receiver_clearance or 0.0))
if (minimum_body_clearance is None or
        minimum_body_clearance + 1.0e-5 < FIXED["tray_service_min_clearance_mm"]):
    die("populated tray extraction lacks %.1f mm body clearance (%.3f mm)" %
        (FIXED["tray_service_min_clearance_mm"], minimum_body_clearance or 0.0))

# Flush-X lid, printed exterior-face-down so the gasket groove faces upward.
lid_local = Part.makeBox(L, W + 2.0 * FLANGE_OVERHANG, LID_T,
                         Vector(0.0, -FLANGE_OVERHANG, 0.0))
groove_outer = rounded_prism(L - 6.0, W + 2.0 * SEAL_OVERHANG - 6.0,
                              GROOVE_D + 0.1, 6.0,
                              3.0, -SEAL_OVERHANG + 3.0, -0.1)
groove_inner = rounded_prism(L - 6.0 - 2.0 * GROOVE_W,
                              W + 2.0 * SEAL_OVERHANG - 6.0 - 2.0 * GROOVE_W,
                              GROOVE_D + 2.0, max(0.5, 6.0 - GROOVE_W),
                              3.0 + GROOVE_W, -SEAL_OVERHANG + 3.0 + GROOVE_W, -1.0)
groove = groove_outer.cut(groove_inner).removeSplitter()
gasket_screw_checks = []
for x, y in lid_screw_centers:
    test_hole = Part.makeCylinder(FIXED["m3_lid_clearance_d_mm"] / 2.0,
                                  LID_T + 2.0, Vector(x, y, -1.0))
    overlap = test_hole.common(groove).Volume
    passed = overlap < 1.0e-5
    gasket_screw_checks.append({"center_xy_mm": [x, y],
                                "groove_overlap_mm3": overlap, "pass": passed})
    if not passed:
        die("lid screw at %.3f, %.3f intersects gasket groove" % (x, y))
lid_local = lid_local.cut(groove).removeSplitter()
lid_holes = [Part.makeCylinder(FIXED["m3_lid_clearance_d_mm"] / 2.0,
                               LID_T + 2.0, Vector(x, y, -1.0))
             for x, y in lid_screw_centers]
lid_local = lid_local.cut(Part.makeCompound(lid_holes)).removeSplitter()
assert_solid("lid", lid_local)
lid_installed = lid_local.copy()
lid_installed.translate(Vector(0.0, 0.0, H))
export_shape(lid_installed, "reference_lid_installed")
lid_print = lid_local.copy()
lid_print.rotate(Vector(0, 0, 0), Vector(1, 0, 0), 180.0)
lid_print.translate(Vector(0.0, W + FLANGE_OVERHANG, LID_T))
assert_solid("print-oriented lid", lid_print)
export_shape(lid_print, "lid")

# Mount-interface gauge only: corrected 20.2 mm axis offset, one round datum
# and one short longitudinal slot.  The production vehicle adapter should be
# metal after the exact vehicle plane/depth is measured.
gauge_w = FIXED["mount_gauge_width_mm"]
gauge_d = FIXED["mount_gauge_depth_mm"]
gauge_t = 7.5
mount_gauge = rounded_prism(gauge_w, gauge_d, gauge_t, 3.0)
mount_gauge = mount_gauge.fuse(Part.makeBox(gauge_w, 3.0, 20.0,
                                            Vector(0.0, -3.0, 0.0))).removeSplitter()
mx1 = (gauge_w - P["mount_hole_spacing_mm"]) / 2.0
mx2 = mx1 + P["mount_hole_spacing_mm"]
my = FIXED["mount_axis_offset_mm"]
round_hole = Part.makeCylinder(P["mount_hole_d_mm"] / 2.0, gauge_t + 2.0,
                               Vector(mx1, my, -1.0))
slot_travel = 3.0
slot = (Part.makeCylinder(P["mount_hole_d_mm"] / 2.0, gauge_t + 2.0,
                          Vector(mx2 - slot_travel / 2.0, my, -1.0))
        .fuse(Part.makeCylinder(P["mount_hole_d_mm"] / 2.0, gauge_t + 2.0,
                                Vector(mx2 + slot_travel / 2.0, my, -1.0)))
        .fuse(Part.makeBox(slot_travel, P["mount_hole_d_mm"], gauge_t + 2.0,
                           Vector(mx2 - slot_travel / 2.0,
                                  my - P["mount_hole_d_mm"] / 2.0, -1.0)))
        .removeSplitter())
mount_gauge = mount_gauge.cut(round_hole.fuse(slot)).removeSplitter()
assert_solid("vehicle mount fit gauge", mount_gauge)
export_shape(mount_gauge, "vehicle_mount_fit_gauge")

# Exact 3.0 mm process coupon: nominal/+0.2/+0.4 for every hole family.
coupon_t = PANEL_WEB
coupon = rounded_prism(166.0, 58.0, coupon_t, 3.0)
coupon_mapping = []
coupon_cutters = []
groups = [("SP13", [18.0, 41.0, 64.0], 16.0),
          ("USB", [100.0, 124.0, 148.0], 16.0),
          ("POWER", [18.0, 41.0, 64.0], 42.0),
          ("VENT", [100.0, 124.0, 148.0], 42.0)]
nominal = {"SP13": P["sp13_hole_d_mm"], "USB": P["usb_cutout_d_mm"],
           "POWER": P["power_cutout_d_mm"], "VENT": P["vent_cutout_d_mm"]}
for family, xs, cy in groups:
    for variant, (cx, allowance) in enumerate(zip(xs, (0.0, 0.2, 0.4))):
        d = nominal[family] + allowance
        if family == "SP13":
            af = P["sp13_flat_mm"] + allowance
            cutter = panel_opposing_flats(cx, cy, d, af, -1.0, coupon_t + 2.0)
            detail = {"diameter_mm": d, "across_flats_mm": af}
        elif family == "POWER":
            span = FIXED["power_flat_to_edge_mm"] + allowance
            cutter = panel_d_flat(cx, cy, d, span, -1.0, coupon_t + 2.0)
            detail = {"diameter_mm": d, "flat_to_opposite_edge_mm": span}
        else:
            cutter = panel_round_hole(cx, cy, d, -1.0, coupon_t + 2.0)
            detail = {"diameter_mm": d}
        coupon_cutters.append(cutter)
        coupon_mapping.append({"family": family, "variant": variant,
                               "allowance_mm": allowance, "center_mm": [cx, cy], **detail})
coupon = coupon.cut(Part.makeCompound(coupon_cutters)).removeSplitter()
assert_solid("panel fit coupon", coupon)
export_shape(coupon, "panel_fit_coupon")

# Upright process coupon reproduces the actual horizontal USB/vent tunnels and
# their one-perimeter sacrificial membranes in the standing-body orientation.
wall_coupon_w = 70.0
wall_coupon_h = 35.0
wall_coupon = (Part.makeBox(wall_coupon_w, WALL, wall_coupon_h)
               .fuse(Part.makeBox(wall_coupon_w, 14.0, 2.4)).removeSplitter())
wall_coupon_features = [
    {"name": "USB", "x_mm": 20.0, "z_mm": 18.0,
     "diameter_mm": P["usb_cutout_d_mm"]},
    {"name": "VENT", "x_mm": 51.0, "z_mm": 18.0,
     "diameter_mm": P["vent_cutout_d_mm"]},
]
wall_coupon_cutters = [Part.makeCylinder(
    feature["diameter_mm"] / 2.0, WALL + 1.0,
    Vector(feature["x_mm"], membrane, feature["z_mm"]), Vector(0, 1, 0))
    for feature in wall_coupon_features]
wall_coupon = wall_coupon.cut(Part.makeCompound(wall_coupon_cutters)).removeSplitter()
assert_solid("standing wall-hole coupon", wall_coupon)
export_shape(wall_coupon, "standing_wall_hole_coupon")

# Mount/process coupon: the upright rail sample reproduces the body's actual
# floor-plus-5 mm rail section and prints its Ø4 x 5.3 mm insert pilot on a
# horizontal axis. The separate 3.2 mm plate reproduces the tray clearance
# hole and screw-head bearing land. A second upright rail reproduces the deeper
# 6.7 mm lid insert with only 1.5 mm backing. This qualifies the selected
# insert/screw process, not full-length tray warp or sliding friction.
rail_sample = (Part.makeBox(14.0, 18.0, 2.4)
               .fuse(Part.makeBox(FLOOR + 5.0, FIXED["tray_rail_width_mm"], 30.0,
                                  Vector(2.9, 3.0, 0.0)))
               .removeSplitter())
rail_sample = rail_sample.cut(Part.makeCylinder(
    FIXED["m3_insert_pocket_d_mm"] / 2.0,
    FIXED["tray_mount_insert_depth_mm"] + 0.3,
    Vector(2.6, 11.0, 15.0), Vector(1, 0, 0))).removeSplitter()
slider_sample = Part.makeBox(
    40.0, 18.0, FIXED["tray_thickness_mm"], Vector(20.0, 24.0, 0.0))
coupon_cx, coupon_cy = 40.0, 33.0
slider_sample = slider_sample.cut(Part.makeCylinder(
    FIXED["tray_mount_clearance_d_mm"] / 2.0,
    FIXED["tray_thickness_mm"] + 2.0,
    Vector(coupon_cx, coupon_cy, -1.0))).removeSplitter()
lid_rail_sample = (Part.makeBox(14.0, 18.0, 2.4, Vector(0.0, 24.0, 0.0))
                   .fuse(Part.makeBox(8.2, 12.0, 30.0,
                                      Vector(2.9, 27.0, 0.0)))
                   .removeSplitter())
lid_rail_sample = lid_rail_sample.cut(Part.makeCylinder(
    FIXED["m3_insert_pocket_d_mm"] / 2.0,
    FIXED["m3_insert_depth_mm"] + 0.3,
    Vector(2.6, 35.0, 15.0), Vector(1, 0, 0))).removeSplitter()
assert_solid("tray rail insert coupon", rail_sample)
assert_solid("tray screw plate coupon", slider_sample)
assert_solid("lid rail insert coupon", lid_rail_sample)
rail_coupon = Part.makeCompound([rail_sample, slider_sample, lid_rail_sample])
export_shape(rail_coupon, "tray_rail_fit_coupon")

# Closed reference assembly; intentional touching faces are allowed, volume
# overlaps are not.
assembly_parts = [body, cap_installed, clamp_bar_installed, lid_installed,
                  tray_installed, carrier_installed,
                  guard_installed] + list(component_shapes.values())
assembly = Part.makeCompound(assembly_parts)
if not assembly.isValid():
    die("reference assembly is invalid")
assembly.exportStep(os.path.join(OUT, "assembly.step"))
assembly_mesh = MeshPart.meshFromShape(Shape=assembly, LinearDeflection=0.08,
                                       AngularDeflection=0.25, Relative=False)
assembly_mesh.write(os.path.join(OUT, "assembly.stl"))

doc = App.newDocument("AC_Diagnostic_Enclosure_Standing_V2")
add_feature(doc, "Body", "Standing-print axial shell", body, (0.13, 0.29, 0.53))
add_feature(doc, "RightIOPanel", "Removable right I/O cap", cap_installed, (0.24, 0.45, 0.68))
add_feature(doc, "CableClamp", "Removable right-cap cable clamp bar", clamp_bar_installed,
            (0.30, 0.55, 0.78))
add_feature(doc, "Lid", "Flush-X gasketed lid", lid_installed, (0.90, 0.31, 0.08), 12)
add_feature(doc, "ElectronicsTray", "Removable electronics sled", tray_installed, (0.72, 0.72, 0.76), 10)
add_feature(doc, "InterfaceCarrier", "Future-drill interface carrier", carrier_installed, (0.65, 0.22, 0.75), 25)
add_feature(doc, "UPSGuard", "UPS clearance guard on metal standoffs", guard_installed, (0.94, 0.78, 0.12), 15)
palette = [(0.12, 0.55, 0.20), (0.65, 0.22, 0.75), (0.08, 0.45, 0.72),
           (0.85, 0.65, 0.08), (0.12, 0.70, 0.68)]
for index, (name, shape) in enumerate(component_shapes.items()):
    add_feature(doc, "Reference_" + name, name, shape, palette[index], 55)
for name, shape in keepouts.items():
    add_feature(doc, "Keepout_" + name, name, shape, (0.85, 0.10, 0.10), 82)
for name, shape in external_keepouts.items():
    add_feature(doc, "Keepout_" + name, name, shape, (0.90, 0.20, 0.10), 86)
doc.recompute()
doc.saveAs(os.path.join(OUT, "assembly.FCStd"))

result = {
    "freecad_version": App.Version(),
    "shape_validation": {
        "body": {"valid": body.isValid(), "solids": len(body.Solids), "bbox": bbox(body), "volume_mm3": body.Volume},
        "body_standing": {"valid": body_standing.isValid(), "solids": len(body_standing.Solids), "bbox": bbox(body_standing)},
        "right_io_panel": {"valid": cap_print.isValid(), "solids": len(cap_print.Solids), "bbox": bbox(cap_print), "volume_mm3": cap_print.Volume},
        "cable_strain_relief_bar": {"valid": clamp_bar.isValid(), "solids": len(clamp_bar.Solids), "bbox": bbox(clamp_bar), "volume_mm3": clamp_bar.Volume},
        "electronics_tray": {"valid": tray.isValid(), "solids": len(tray.Solids), "bbox": bbox(tray), "volume_mm3": tray.Volume},
        "lid": {"valid": lid_print.isValid(), "solids": len(lid_print.Solids), "bbox": bbox(lid_print), "volume_mm3": lid_print.Volume},
        "panel_fit_coupon": {"valid": coupon.isValid(), "solids": len(coupon.Solids), "bbox": bbox(coupon)},
        "standing_wall_hole_coupon": {"valid": wall_coupon.isValid(), "solids": len(wall_coupon.Solids), "bbox": bbox(wall_coupon)},
        "cap_interface_body_coupon": {"valid": body_interface_coupon.isValid(), "solids": len(body_interface_coupon.Solids), "bbox": bbox(body_interface_coupon)},
        "cap_interface_panel_coupon": {"valid": cap_interface_coupon.isValid(), "solids": len(cap_interface_coupon.Solids), "bbox": bbox(cap_interface_coupon)},
        "tray_mount_process_coupon": {"valid": rail_coupon.isValid(), "solids": len(rail_coupon.Solids), "bbox": bbox(rail_coupon)},
        "interface_pcb_carrier_blank": {"valid": carrier.isValid(), "solids": len(carrier.Solids), "bbox": bbox(carrier)},
        "ups_clearance_guard": {"valid": guard.isValid(), "solids": len(guard.Solids), "bbox": bbox(guard)},
        "vehicle_mount_fit_gauge": {"valid": mount_gauge.isValid(), "solids": len(mount_gauge.Solids), "bbox": bbox(mount_gauge)},
        "assembly": {"valid": assembly.isValid(), "solids": len(assembly.Solids), "bbox": bbox(assembly)},
    },
    "collision_checks": collision_checks,
    "panel_screw_centers_yz_mm": panel_screw_centers,
    "lid_screw_centers_xy_mm": lid_screw_centers,
    "tray_mount_centers_xy_mm": tray_mount_centers,
    "carrier_mount_centers_xy_mm": carrier_mounts,
    "guard": {"bottom_z_mm": guard_z, "top_z_mm": guard_z + guard_t,
              "frame_width_mm": guard_frame_w,
              "mount_pad_radius_mm": guard_pad_r,
              "mount_pad_radial_wall_mm": guard_pad_r - 1.35,
              "support": "four upper M2.5 metal spacers above the UPS; long screws terminate in inserts inside the tray's 6 mm printed bosses"},
    "tray_service_motion": {"remove_screws": 4,
                            "lift_direction": "+Z",
                            "lift_mm": service_lift,
                            "extraction_direction": "+X",
                            "full_extraction_delta_mm": extraction_delta,
                            "sweep_step_max_mm": extraction_step_max,
                            "sweep_samples": extraction_samples,
                            "max_body_overlap_mm3": max_extraction_overlap,
                            "minimum_body_clearance_mm": minimum_body_clearance,
                            "minimum_receiver_clearance_mm": minimum_receiver_clearance,
                            "required_receiver_clearance_mm": FIXED["tray_service_min_clearance_mm"]},
    "tray_rail": {"width_mm": tray_rail_w,
                  "insert_pocket_d_mm": FIXED["m3_insert_pocket_d_mm"],
                  "minimum_radial_wall_mm": (
                      tray_rail_w - 8.0 - FIXED["m3_insert_pocket_d_mm"] / 2.0)},
    "gasket_screw_checks": gasket_screw_checks,
    "cable_strain_relief": {"mount_centers_yz_mm": [[y, clamp_mount_z] for y in clamp_mount_ys],
                              "bar_installed_bbox": bbox(clamp_bar_installed),
                              "tie_slot_mm": [FIXED["cable_tie_slot_width_mm"],
                                              FIXED["cable_tie_slot_height_mm"]],
                              "boss_depth_mm": clamp_boss_depth,
                              "boss_side_ribs": True,
                              "print_transform_volume_delta_mm3": clamp_transform_volume_delta,
                              "route_engagement": clamp_engagement,
                              "service": "unplug internal pigtails; cap, bar, ties, and pigtails remove together"},
    "right_panel": {"installed_inner_web_x_mm": inner_web_x,
                    "body_cap_interface_x_mm": CAP_X,
                    "receiver_taper_mm": receiver_taper,
                    "receiver_wall_at_insert_bottom_mm": (
                        FIXED["panel_receiver_root_r_mm"]
                        + (receiver_r - FIXED["panel_receiver_root_r_mm"])
                        * (receiver_taper - FIXED["m3_insert_depth_mm"])
                        / receiver_taper
                        - FIXED["m3_insert_pocket_d_mm"] / 2.0),
                    "locating_tongue_depth_mm": tongue_depth,
                    "locating_tongue_min_clearance_mm": tongue_clear,
                    "locating_tongue_side_wall_float_mm": tongue_side_wall_float,
                    "print_transform_volume_delta_mm3": cap_transform_volume_delta,
                    "three_piece_seal_status": "splash-resistant prototype pending face-gasket and leak testing"},
    "lid_insert_rail": {"rail_thickness_mm": screw_rail_t,
                        "insert_depth_mm": FIXED["m3_insert_depth_mm"],
                        "solid_backing_mm": screw_rail_t - FIXED["m3_insert_depth_mm"]},
    "mount_gauge": {"hole_centers_mm": [[mx1, my], [mx2, my]],
                    "round_d_mm": P["mount_hole_d_mm"],
                    "slot_overall_mm": [P["mount_hole_d_mm"] + slot_travel, P["mount_hole_d_mm"]],
                    "production_adapter": "metal recommended; gauge is not a vehicle-load bracket"},
    "coupon_mapping": coupon_mapping,
    "standing_wall_coupon": {"features": wall_coupon_features,
                              "sacrificial_membrane_mm": membrane,
                              "print_orientation": "upright, holes horizontal"},
    "cap_interface_coupon": {"parts": ["cap_interface_body_coupon",
                                         "cap_interface_panel_coupon"],
                              "production_geometry": "exact cropped solids",
                              "installed_crop_y_mm": [interface_y_min,
                                                       interface_y_min + interface_y_span],
                              "installed_crop_z_mm": [interface_z_min,
                                                       interface_z_min + interface_z_span],
                              "locator_clearance_mm": tongue_clear,
                              "receiver_center_yz_mm": [0.0, FIXED["panel_screw_low_z_mm"]],
                              "body_print_orientation": "same +X-to-printer-+Z transform as full shell",
                              "panel_print_orientation": "same exterior-face-down transform as full cap"},
    "tray_mount_coupon": {"insert_pocket_d_mm": FIXED["m3_insert_pocket_d_mm"],
                           "insert_pocket_depth_mm": FIXED["tray_mount_insert_depth_mm"] + 0.3,
                           "insert_print_axis": "horizontal",
                           "rail_section_thickness_mm": FLOOR + 5.0,
                           "rail_width_mm": FIXED["tray_rail_width_mm"],
                           "minimum_radial_wall_mm": 2.0,
                           "solid_backing_mm": FLOOR,
                           "opening_breakout_mm": 0.3,
                           "tray_clearance_d_mm": FIXED["tray_mount_clearance_d_mm"],
                           "lid_insert_pocket_depth_mm": FIXED["m3_insert_depth_mm"],
                           "lid_insert_solid_backing_mm": 8.2 - FIXED["m3_insert_depth_mm"],
                           "scope": "insert/screw process only; not full-length tray warp"},
}
with open(os.path.join(OUT, "freecad_result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, indent=2, sort_keys=True)
print("CAD_OK standing_v2 body=%.3f panel=%.3f tray=%.3f checks=%d" %
      (body.Volume, cap_print.Volume, tray.Volume, len(collision_checks)), flush=True)


import bpy, math, os
from mathutils import Vector

OUT = 'out'
H = 60.0

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x = 1280
    scene.render.resolution_y = 800
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.display.shading.light = "STUDIO"
    scene.display.shading.studio_light = "paint.sl"
    scene.display.shading.color_type = "OBJECT"
    scene.display.shading.show_shadows = True
    scene.display.shading.show_cavity = True
    scene.display.shading.cavity_type = "WORLD"
    if scene.world is None:
        scene.world = bpy.data.worlds.new("Standing enclosure preview world")
    scene.world.color = (0.045, 0.052, 0.065)
    return scene

def import_stl(filename, name, color, alpha=1.0):
    path = os.path.join(OUT, filename)
    before = set(bpy.data.objects)
    try:
        bpy.ops.wm.stl_import(filepath=path)
    except Exception:
        bpy.ops.import_mesh.stl(filepath=path)
    created = [obj for obj in bpy.data.objects if obj not in before]
    if not created:
        raise RuntimeError("STL import made no object: " + path)
    obj = created[0]
    obj.name = name
    obj.color = (*color, alpha)
    return obj

def frame(scene, objects, azimuth=34.0, elevation=29.0, scale=1.34):
    bpy.context.view_layer.update()
    points = []
    for obj in objects:
        if not obj.hide_render:
            points.extend([obj.matrix_world @ Vector(corner) for corner in obj.bound_box])
    lo = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    hi = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    center = (lo + hi) / 2.0
    extent = max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z)
    cam_data = bpy.data.cameras.new("PreviewCamera")
    cam_data.type = "ORTHO"
    cam_data.ortho_scale = extent * scale
    cam = bpy.data.objects.new("PreviewCamera", cam_data)
    bpy.context.collection.objects.link(cam)
    az, el = math.radians(azimuth), math.radians(elevation)
    distance = extent * 2.6
    cam.location = center + Vector((distance * math.sin(az) * math.cos(el),
                                    -distance * math.cos(az) * math.cos(el),
                                    distance * math.sin(el)))
    cam.rotation_euler = (center - cam.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = cam

def render(scene, filename):
    scene.render.filepath = os.path.join(OUT, filename)
    bpy.ops.render.render(write_still=True)

scene = reset()
body = import_stl("body.stl", "Axial shell", (0.12, 0.30, 0.56))
cap = import_stl("reference_right_io_panel_installed.stl", "Right connector cap", (0.16, 0.48, 0.76))
clamp = import_stl("reference_cable_strain_relief_bar_installed.stl", "Cable clamp bar", (0.28, 0.58, 0.82))
lid = import_stl("reference_lid_installed.stl", "Lid", (0.91, 0.30, 0.07))
tray = import_stl("reference_electronics_tray_installed.stl", "Electronics sled", (0.71, 0.72, 0.76))
carrier = import_stl("reference_interface_pcb_carrier_installed.stl", "Interface carrier", (0.62, 0.20, 0.74))
guard = import_stl("reference_ups_clearance_guard_installed.stl", "UPS guard", (0.95, 0.76, 0.10))
palette = [(0.12, 0.62, 0.24), (0.62, 0.20, 0.74), (0.06, 0.52, 0.84),
           (0.91, 0.62, 0.06), (0.08, 0.72, 0.68)]
component_files = ['reference_waveshare_ups_hat_d.stl', 'reference_interface_pcb_reserved.stl', 'reference_dfrobot_dfr0975.stl', 'reference_adafruit_microsd_4682.stl', 'reference_adafruit_sht40_4885.stl']
components = [import_stl(filename, filename[10:-4], palette[index % len(palette)])
              for index, filename in enumerate(component_files)]
all_objects = [body, cap, clamp, lid, tray, carrier, guard] + components
frame(scene, all_objects, azimuth=34.0, elevation=32.0)
render(scene, "preview_assembly.png")

# Service/exploded state: cap clears along +X; sled, boards, carrier, and guard
# move together.  The lid lifts straight up.
cap.location.x += 38.0
clamp.location.x += 38.0
lid.location.z += 42.0
lid.location.y += 10.0
for obj in [tray, carrier, guard] + components:
    obj.location.x += 31.0
frame(scene, all_objects, azimuth=31.0, elevation=36.0, scale=1.42)
render(scene, "preview_service.png")

for obj in all_objects:
    obj.hide_render = True
standing = import_stl("body_standing.stl", "V400 standing orientation", (0.12, 0.30, 0.56))
frame(scene, [standing], azimuth=42.0, elevation=18.0, scale=2.40)
render(scene, "preview_standing.png")
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "workbench.blend"))
print("BLENDER_OK preview_assembly.png preview_service.png preview_standing.png", flush=True)

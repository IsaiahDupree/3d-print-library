# FLSUN V400 hood-flange V4 print and first-fit order

This package is a measurement-gated fit study, not an approved engine-bay
installation. Do not scale or auto-orient the supplied print STL files.
`assembly.stl`, `body.stl`, `right_pigtail_cap.stl`, and every `reference_*.stl`
are installed-coordinate inspection references and must not be sliced.

## Print in this order

1. `standing_wall_hole_coupon.stl` — qualify the horizontal gland membrane/process.
2. `pigtail_gland_coupon.stl` — select the purchased gland's actual cutout.
3. `standing_bridge_coupon.stl` — qualify the full-height painted
   support-on-model column and interface for the conservative
   66.4 mm terminal span at
   159.8 mm overall height.
4. `vehicle_bolt_coupon.stl` — test the provisional 50.53
   mm round-plus-slot pattern by hand, engine off. Never force a vehicle bolt.
5. Optionally print `adapter_drill_template.stl` only as a non-structural
   pattern after the bolt coupon passes; it is not a vehicle bracket.
6. `depth_feeler_45_55_65.stl` and `right_io_60mm_witness.stl` — record the
   stamped-panel space and 60 mm working
   cable clearance after seating the 5 mm heel.
7. `slot_clearance_cage.stl` — empty/inert fit only. Its terminal end is open to
   eliminate a 78.0 mm terminal print bridge. Its envelope is
   175.0 x 83.0
   x 110.0 mm. Close the hood slowly against soft
   witnesses; never slam it and never start or drive with a loose gauge.
8. Only after those pass: `body_standing.stl`, `right_pigtail_cap_print.stl`,
   `front_lid.stl`, and `electronics_backplane.stl`.

## Preserved orientations

| File | Preserved print orientation | Brim starting point |
| --- | --- | ---: |
| `body_standing.stl` | Flat 60.0 x 88.0 mm short side; height 159.8 mm | 12 mm |
| `right_pigtail_cap_print.stl` | Installed Z-bottom; 16.7 x 60.0 mm footprint; no locator tabs | 8 mm |
| `front_lid.stl` | Solid exterior face down; gasket groove opens upward | 6 mm |
| `electronics_backplane.stl` | Flat; countersinks open upward | 6 mm |
| `slot_clearance_cage.stl` | 110.0 x 83.0 mm footprint; 175.0 mm high; top-flange end included and terminal end open | 12 mm |
| `vehicle_bolt_coupon.stl` | Saved flat orientation; 90 x 32 x 4 mm | 6 mm |
| `adapter_drill_template.stl` | Saved flat T-profile; 175.0 x 110.0 x 3 mm | 6 mm |
| `depth_feeler_45_55_65.stl` | Connected heel on bed; 32 x 65 mm footprint | 6 mm |
| `right_io_60mm_witness.stl` | Datum heel and arm flat; 65.0 x 24 mm footprint | 6 mm |
| `pigtail_gland_coupon.stl` | Saved flat orientation; three vertical cutout samples | 6 mm |
| `standing_wall_hole_coupon.stl` | Saved standing orientation; horizontal bore and membrane | 6 mm |
| `standing_bridge_coupon.stl` | Saved full-height orientation; 76.4 x 12 mm footprint, 159.8 mm high | 6 mm |

The open cage has four 3 mm diagonal anti-sway braces. For that fit gauge, start
with outer walls no faster than 40 mm/s and no more than 1000 mm/s² acceleration;
stop if the towers oscillate or a layer shifts. These are conservative prototype
starting caps, not a material qualification.

Use the printer/filament manufacturer's calibrated V400 profile. A conservative
prototype starting point is 0.20 mm layers, at least five perimeters on the shell
and cap, and six top/bottom layers. Use support-everywhere/support-on-model and
paint it only under the body's terminal service-throat rail and the cap's top
rim/horizontal gland roofs. The closed bed-end walls block conventional straight
build-plate-only columns; use support blockers to protect every gasket seat.
Start with a 0.20 mm support-interface gap and tune it on
`standing_bridge_coupon.stl`. Confirm in the sliced layer preview that the support
actually reaches the painted roof before printing. Inspect
the sliced layer preview around every horizontal gland, sleeve, insert, and
sacrificial membrane. Open and ream functional holes only after measuring the
purchased hardware; all three cap gland membranes stay closed until the gland
coupon passes. Center each part on the circular bed. The first layer and brim
must be continuous before allowing
either tall standing print to continue.

PLA and PETG are fit-check materials only here. Do not install electronics,
refrigerant-pressure parts, or lithium cells during fit trials. Do not heat-set
inserts until the bolt coupon, 83.0 mm cage,
purchased glands, and component boards have all been physically checked.
`manifest.json` is the authoritative file/hash
record for this run. `stl_mesh_audit.json` records the exact emitted print-STL
binary/topology/bed-contact checks; it does not replace slicer-preview inspection.

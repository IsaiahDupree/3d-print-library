
import bpy, math, os
from mathutils import Vector

OUT = 'out12'
COMPONENT_FILES = ['reference_interface_pcb_reserved.stl', 'reference_dfrobot_dfr0975.stl', 'reference_adafruit_microsd_4682.stl', 'reference_adafruit_sht40_4885.stl']
P = {'case_width_mm': 175.0, 'case_height_mm': 88.0, 'case_depth_mm': 60.0, 'wall_mm': 3.2, 'back_wall_mm': 4.0, 'lid_thickness_mm': 5.0, 'mount_hole_spacing_mm': 50.53, 'mount_hole_d_mm': 9.2, 'mount_slot_length_mm': 14.0, 'mount_datum_x_mm': 115.0, 'case_top_to_head_bottom_mm': 3.0, 'hood_clearance_above_head_mm': 5.0, 'clearance_below_head_mm': 150.0, 'adapter_gap_mm': 12.0, 'gasket_cord_d_mm': 2.5, 'pigtail_gland_d_mm': 12.5}
MECH = {'coordinate_system': {'origin': 'lower-left corner of enclosure rear face', 'x': 'positive toward fuse/relay boxes', 'y': 'positive toward engine/camera', 'z': 'positive toward cowl', 'photo_bolt_midpoint_xz_mm': [115.0, 101.0]}, 'body_cap_interface_x_mm': 159.8, 'right_panel_face_x_mm': 163.0, 'lid_width_mm': 175.0, 'mount_centers_xz_mm': [[89.735, 101.0], [140.265, 101.0]], 'mount_features': ['round', 'horizontal_slot'], 'mount_datum_relative_envelope_mm': {'left': -115.0, 'right': 60.0, 'below': -101.0, 'above': 9.0}, 'bolt_head_envelope_mm': {'diameter': 20.0, 'lower_z': 91.0, 'upper_z': 111.0}, 'adapter_crossbar_x_mm': [71.65, 158.35], 'adapter_top_z_mm': 110.0, 'bolt_plane_hood_datum_z_mm': 116.0, 'lower_obstruction_z_mm': -59.0, 'case_drop_below_head_mm': 91.0, 'lower_clearance_reserve_mm': 59.0, 'adapter_case_centers_xz_mm': [[30.0, 15.0], [120.0, 15.0], [30.0, 73.0], [120.0, 73.0]], 'face_flange_width_mm': 10.8, 'service_throat_xz_mm': [10.8, 156.60000000000002, 10.8, 77.2], 'cap_screw_centers_yz_mm': [[6.0, 6.0], [54.0, 6.0], [6.0, 82.0], [54.0, 82.0]], 'cap_seam_gasket': {'path': 'closed rectangle', 'seat_width_mm': 1.6, 'seat_depth_mm': 0.75, 'nominal_stock_thickness_mm': 1.0, 'target_compression_percent': 25.0}, 'backplane_origin_mm': [11.3, 10.0, 11.700000000000001], 'backplane_size_mm': [144.8, 3.0, 64.6], 'backplane_mount_centers_xz_mm': [[45.0, 25.0], [110.0, 25.0], [45.0, 63.0], [110.0, 63.0]], 'backplane_cable_tie_slot_centers_xz_mm': [[110.0, 32.0], [145.0, 32.0], [110.0, 55.0], [145.0, 55.0]], 'gasket': {'cord_d_mm': 2.5, 'groove_width_mm': 3.3, 'groove_depth_mm': 1.875, 'land_inset_mm': 7.5, 'target_compression_percent': 25.0}, 'standing_footprint_mm': [60.0, 88.0], 'standing_body_height_mm': 159.8, 'right_cap_print_footprint_mm': [16.69999999999999, 60.0], 'standing_bridge_coupon_span_mm': 66.4, 'standing_bridge_coupon_support_height_mm': 156.60000000000002, 'full_case_width_mm': 175.0, 'v400_body_required_radius_mm': 65.2541078227774, 'installed_projection_mm': 79.5, 'installed_hardware_projection_mm': 81.5, 'fit_cage_envelope_mm': [175.0, 83.0, 110.0], 'photo_envelope_basis': 'owner-measured hood/drop envelope; 50.53 mm remains a slotted bolt-pitch candidate and exact hood slope across depth remains gated'}
FIXED = {'right_recess_depth_mm': 12.0, 'right_panel_web_mm': 3.2, 'cap_receiver_length_mm': 8.0, 'cap_receiver_radius_mm': 6.3, 'cap_receiver_root_radius_mm': 4.5, 'cap_screw_clearance_d_mm': 3.6, 'm3_insert_pocket_d_mm': 4.0, 'm3_insert_depth_mm': 6.0, 'cap_pilot_od_mm': 6.8, 'cap_pilot_length_mm': 1.5, 'cap_pilot_counterbore_d_mm': 7.2, 'cap_pilot_counterbore_depth_mm': 1.7, 'cap_driver_keepout_d_mm': 11.0, 'cap_seal_width_mm': 1.6, 'cap_seal_stock_thickness_mm': 1.0, 'cap_seal_depth_mm': 0.75, 'cap_seal_inset_mm': 1.6, 'front_right_seal_rail_mm': 3.2, 'backplane_thickness_mm': 3.0, 'backplane_standoff_mm': 6.0, 'backplane_boss_d_mm': 8.0, 'backplane_boss_length_mm': 6.0, 'backplane_insert_depth_mm': 4.5, 'backplane_countersink_d_mm': 6.4, 'backplane_countersink_depth_mm': 1.8, 'component_standoff_mm': 3.0, 'controller_standoff_od_mm': 6.0, 'controller_hole_d_mm': 2.4, 'gasket_groove_extra_width_mm': 0.8, 'gasket_land_extra_mm': 5.0, 'gland_keepout_d_mm': 16.0, 'gland_keepout_length_mm': 14.0, 'cable_tie_slot_width_mm': 3.2, 'cable_tie_slot_height_mm': 5.0, 'wall_sacrificial_membrane_mm': 0.45, 'adapter_plate_thickness_mm': 2.5, 'adapter_crossbar_width_mm': 86.7, 'adapter_top_inset_mm': 1.0, 'adapter_tab_overlap_mm': 5.0, 'adapter_case_hole_d_mm': 4.5, 'adapter_case_pattern_center_x_mm': 75.0, 'adapter_case_pattern_width_mm': 90.0, 'adapter_case_pattern_height_mm': 58.0, 'adapter_spacer_d_mm': 10.0, 'adapter_body_passage_d_mm': 10.4, 'adapter_sleeve_proud_mm': 0.1, 'minimum_sleeve_passage_ligament_mm': 8.0, 'minimum_mount_feature_clearance_mm': 2.0, 'vehicle_head_envelope_d_mm': 20.0, 'minimum_lower_clearance_reserve_mm': 20.0, 'rear_load_rib_width_mm': 3.2, 'rear_load_rib_depth_mm': 2.4, 'sleeve_collar_od_mm': 16.0, 'cap_lid_screw_edge_offset_mm': 3.5, 'minimum_lid_hole_ligament_mm': 1.5, 'lid_head_allowance_mm': 2.0, 'fit_cage_depth_margin_mm': 1.5, 'fit_cage_rail_mm': 5.0, 'fit_cage_brace_d_mm': 3.0, 'fit_static_clearance_mm': 10.0, 'fit_moving_clearance_mm': 20.0, 'external_pigtail_service_mm': 60.0, 'io_witness_datum_heel_mm': 5.0, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0, 'standing_body_brim_mm': 12.0, 'flat_part_brim_mm': 6.0}

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x = 1280
    scene.render.resolution_y = 800
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.display.shading.light = "STUDIO"
    scene.display.shading.studio_light = "paint.sl"
    scene.display.shading.color_type = "OBJECT"
    scene.display.shading.show_shadows = True
    scene.display.shading.show_cavity = True
    scene.display.shading.cavity_type = "WORLD"
    if scene.world is None:
        scene.world = bpy.data.worlds.new("Firewall slot preview world")
    scene.world.color = (0.045, 0.052, 0.065)
    return scene

def import_stl(filename, name, color, alpha=1.0):
    path = os.path.join(OUT, filename)
    before = set(bpy.data.objects)
    try:
        bpy.ops.wm.stl_import(filepath=path)
    except Exception:
        bpy.ops.import_mesh.stl(filepath=path)
    created = [obj for obj in bpy.data.objects if obj not in before]
    if not created:
        raise RuntimeError("STL import made no object: " + path)
    obj = created[0]
    obj.name = name
    obj.color = (*color, alpha)
    return obj

def add_box(name, size, location, color, alpha=1.0):
    bpy.ops.mesh.primitive_cube_add(location=location)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    obj.color = (*color, alpha)
    return obj

def add_cylinder(name, radius, depth, location, color):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=64, radius=radius, depth=depth, location=location,
        rotation=(math.radians(90.0), 0.0, 0.0),
    )
    obj = bpy.context.object
    obj.name = name
    obj.color = (*color, 1.0)
    return obj

def add_label(name, text, location, size=4.5):
    bpy.ops.object.text_add(
        location=location,
        rotation=(math.radians(90.0), 0.0, math.radians(180.0)),
    )
    obj = bpy.context.object
    obj.name = name
    obj.data.body = text
    obj.data.align_x = "LEFT"
    obj.data.size = size
    obj.data.extrude = 0.12
    obj.color = (0.96, 0.97, 1.0, 1.0)
    return obj

def frame(scene, objects, azimuth=34.0, elevation=26.0, scale=1.36):
    bpy.context.view_layer.update()
    points = []
    for obj in objects:
        if not obj.hide_render:
            points.extend([obj.matrix_world @ Vector(corner) for corner in obj.bound_box])
    lo = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    hi = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    center = (lo + hi) / 2.0
    extent = max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z)
    data = bpy.data.cameras.new("PreviewCamera")
    data.type = "ORTHO"
    data.ortho_scale = extent * scale
    camera = bpy.data.objects.new("PreviewCamera", data)
    bpy.context.collection.objects.link(camera)
    az = math.radians(azimuth)
    el = math.radians(elevation)
    distance = extent * 2.7
    camera.location = center + Vector((
        distance * math.sin(az) * math.cos(el),
        distance * math.cos(az) * math.cos(el),
        distance * math.sin(el),
    ))
    camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = camera

def frame_explicit(scene, center, extent, azimuth=0.0, elevation=0.0, scale=1.2):
    data = bpy.data.cameras.new("ExplicitPreviewCamera")
    data.type = "ORTHO"
    data.ortho_scale = extent * scale
    camera = bpy.data.objects.new("ExplicitPreviewCamera", data)
    bpy.context.collection.objects.link(camera)
    az = math.radians(azimuth)
    el = math.radians(elevation)
    distance = extent * 2.7
    center = Vector(center)
    camera.location = center + Vector((
        distance * math.sin(az) * math.cos(el),
        distance * math.cos(az) * math.cos(el),
        distance * math.sin(el),
    ))
    camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = camera

def render(scene, filename):
    scene.render.filepath = os.path.join(OUT, filename)
    bpy.ops.render.render(write_still=True)

scene = reset()
body = import_stl("body.stl", "Compact shell", (0.10, 0.30, 0.56))
cap = import_stl(
    "reference_right_pigtail_cap_installed.stl",
    "Recessed pigtail cap", (0.16, 0.48, 0.76),
)
lid = import_stl(
    "reference_front_lid_installed.stl",
    "Front service lid", (0.91, 0.30, 0.07),
)
backplane = import_stl(
    "reference_electronics_backplane_installed.stl",
    "Vertical backplane", (0.70, 0.72, 0.76),
)
adapter = import_stl(
    "reference_adapter_concept.stl",
    "Top-flange metal adapter concept", (0.55, 0.58, 0.63),
)
palette = [
    (0.12, 0.62, 0.24), (0.64, 0.22, 0.76),
    (0.06, 0.52, 0.84), (0.91, 0.62, 0.06), (0.08, 0.72, 0.68),
]
components = [
    import_stl(filename, filename[10:-4], palette[index % len(palette)])
    for index, filename in enumerate(COMPONENT_FILES)
]
assembly_objects = [adapter, body, cap, lid, backplane] + components
frame(scene, assembly_objects, azimuth=32.0, elevation=24.0, scale=1.40)
render(scene, "preview_assembly.png")

# Installed interior with the engine-facing service lid removed.  The shallow
# camera angle preserves the relationship between the backplane, shell rails,
# and recessed right cap without inventing wiring or populated PCB detail.
lid.hide_render = True
interior_objects = [adapter, body, cap, backplane] + components
frame(scene, interior_objects, azimuth=8.0, elevation=10.0, scale=1.28)
render(scene, "preview_interior_lid_removed.png")

# Isolate the complete single backplane so the component zones and board
# service layout are readable rather than hidden behind the shell.
adapter.hide_render = True
body.hide_render = True
cap.hide_render = True
frame(scene, [backplane] + components, azimuth=0.0, elevation=0.0, scale=1.18)
render(scene, "preview_backplane_front.png")

# Show the three reserved right-side gland envelopes from an interior angle.
# These translucent-colored reference solids are clearance volumes, not final
# glands, cables, connectors, or released component geometry.
gland_palette = [(0.10, 0.75, 0.95), (0.95, 0.28, 0.18), (0.95, 0.76, 0.10)]
gland_files = [
    "reference_low_gland_keepout.stl",
    "reference_high_gland_keepout.stl",
    "reference_power_gland_keepout.stl",
]
gland_refs = [
    import_stl(filename, filename[10:-4], gland_palette[index])
    for index, filename in enumerate(gland_files)
]
body.hide_render = True
cap.hide_render = True
backplane.hide_render = False
for component in components:
    component.hide_render = False
io_frame = [
    add_box("I/O frame bottom", (1.2, P["case_depth_mm"], 2.0),
            (MECH["body_cap_interface_x_mm"], P["case_depth_mm"] / 2.0, 1.0),
            (0.16, 0.48, 0.76)),
    add_box("I/O frame top", (1.2, P["case_depth_mm"], 2.0),
            (MECH["body_cap_interface_x_mm"], P["case_depth_mm"] / 2.0,
             P["case_height_mm"] - 1.0),
            (0.16, 0.48, 0.76)),
    add_box("I/O frame rear", (1.2, 2.0, P["case_height_mm"]),
            (MECH["body_cap_interface_x_mm"], 1.0, P["case_height_mm"] / 2.0),
            (0.16, 0.48, 0.76)),
    add_box("I/O frame front", (1.2, 2.0, P["case_height_mm"]),
            (MECH["body_cap_interface_x_mm"], P["case_depth_mm"] - 1.0,
             P["case_height_mm"] / 2.0),
            (0.16, 0.48, 0.76)),
]
frame(scene, [backplane] + components + gland_refs + io_frame,
      azimuth=82.0, elevation=10.0, scale=1.28)
render(scene, "preview_interior_right_io.png")
for obj in io_frame:
    obj.hide_render = True

# Installed-coordinate clearance datum.  Unlike the printable cage view, this
# image explicitly shows the conservative bolt heads, measured bolt-plane hood
# datum, measured lower plane, and the case/flange relationship.  The broad
# amber surface is a visualization extension only; it does not model hood slope.
for obj in [cap, lid, backplane] + components + gland_refs:
    obj.hide_render = True
body.hide_render = False
adapter.hide_render = False
adapter_y = -P["adapter_gap_mm"] - FIXED["adapter_plate_thickness_mm"]
datum_depth = MECH["fit_cage_envelope_mm"][1]
hood_datum_visual = add_box(
    "Bolt-plane hood datum visual extension",
    (P["case_width_mm"], datum_depth, 3.0),
    (P["case_width_mm"] / 2.0, adapter_y + datum_depth / 2.0,
     MECH["bolt_plane_hood_datum_z_mm"] + 1.5),
    (0.95, 0.68, 0.08),
)
lower_plane = add_box(
    "Measured lower obstruction plane",
    (P["case_width_mm"], datum_depth, 3.0),
    (P["case_width_mm"] / 2.0, adapter_y + datum_depth / 2.0,
     MECH["lower_obstruction_z_mm"] - 1.5),
    (0.80, 0.16, 0.12),
)
head_depth = min(P["adapter_gap_mm"], 8.0)
heads = [
    add_cylinder(
        "Conservative bolt head %d" % (index + 1),
        MECH["bolt_head_envelope_mm"]["diameter"] / 2.0,
        head_depth,
        (center[0], adapter_y + 2.5 + head_depth / 2.0, center[1]),
        (0.94, 0.22, 0.14),
    )
    for index, center in enumerate(MECH["mount_centers_xz_mm"])
]
label_y = adapter_y + datum_depth + 2.0
label_x = P["case_width_mm"] - 5.0
labels = [
    add_label(
        "Hood gap label",
        "HOOD DATUM AT BOLT PLANE: %.1f mm ABOVE HEAD"
        % P["hood_clearance_above_head_mm"],
        (label_x, label_y, MECH["bolt_plane_hood_datum_z_mm"] + 2.0),
    ),
    add_label(
        "Head label",
        "%.1f mm HEAD ENVELOPE" % MECH["bolt_head_envelope_mm"]["diameter"],
        (label_x, label_y, MECH["mount_centers_xz_mm"][0][1] + 2.0),
    ),
    add_label(
        "Case gap label",
        "CASE: %.1f mm BELOW HEAD" % P["case_top_to_head_bottom_mm"],
        (label_x, label_y, P["case_height_mm"] - 4.0),
    ),
    add_label(
        "Drop label",
        "MEASURED DROP: %.1f mm" % P["clearance_below_head_mm"],
        (label_x, label_y,
         (MECH["bolt_head_envelope_mm"]["lower_z"]
          + MECH["lower_obstruction_z_mm"]) / 2.0),
    ),
    add_label(
        "Reserve label",
        "%.1f mm CLEAR BELOW CASE" % MECH["lower_clearance_reserve_mm"],
        (label_x, label_y, MECH["lower_obstruction_z_mm"] + 10.0),
    ),
]
datum_z_min = MECH["lower_obstruction_z_mm"] - 3.0
datum_z_max = MECH["bolt_plane_hood_datum_z_mm"] + 3.0
frame_explicit(
    scene,
    (P["case_width_mm"] / 2.0, adapter_y + datum_depth / 2.0,
     (datum_z_min + datum_z_max) / 2.0),
    max(
        P["case_width_mm"],
        (datum_z_max - datum_z_min)
        * scene.render.resolution_x / scene.render.resolution_y,
    ),
    azimuth=0.0, elevation=0.0, scale=1.10,
)
render(scene, "preview_mount_clearance.png")
for obj in [hood_datum_visual, lower_plane] + heads + labels:
    obj.hide_render = True

# Presentation-only exploded service view.  The lid is moved down/left so it
# cannot mask the opening; the populated backplane follows its real +Y removal
# direction and the right cap moves laterally after its four screws are removed.
for obj in gland_refs:
    obj.hide_render = True
adapter.hide_render = False
body.hide_render = False
cap.location.x += 40.0
cap.hide_render = False
lid.hide_render = False
lid.location.x -= 42.0
lid.location.z -= 100.0
backplane.location.y += 28.0
backplane.hide_render = False
for component in components:
    component.location.y += 28.0
    component.hide_render = False
frame(scene, assembly_objects, azimuth=24.0, elevation=23.0, scale=1.36)
render(scene, "preview_service.png")

for obj in assembly_objects:
    obj.hide_render = True
fit = import_stl(
    "slot_clearance_cage.stl", "Hood/drop clearance cage", (0.95, 0.58, 0.08)
)
# The STL is bed-oriented for printing; rotate it back for an installed-view
# preview so the bolt pair reads horizontally as it does on the firewall.
fit.rotation_euler[1] = math.radians(90.0)
frame(scene, [fit], azimuth=30.0, elevation=17.0, scale=1.58)
render(scene, "preview_fit_gauge.png")
fit.hide_render = True

standing = import_stl(
    "body_standing.stl", "FLSUN V400 standing body", (0.16, 0.48, 0.78)
)
frame(scene, [standing], azimuth=42.0, elevation=20.0, scale=1.48)
render(scene, "preview_standing.png")
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "workbench.blend"))
print(
    "BLENDER_OK preview_assembly.png preview_interior_lid_removed.png "
    "preview_backplane_front.png preview_interior_right_io.png preview_service.png "
    "preview_mount_clearance.png preview_fit_gauge.png preview_standing.png",
    flush=True,
)

# Hood-flange V4 measurement worksheet

The photographs establish orientation and an approximate envelope only. Fill every
blank before changing this fit-study into a vehicle-installable part.

| Measurement | Provisional CAD value | Measured value |
| --- | ---: | --- |
| Bolt center distance | 50.53 mm slotted candidate | confirm with both contacts visible: ______ |
| Caliper Photo 1 endpoints | display 50.53 mm; endpoints not visible | ______ to ______ |
| Bolt flange / washer OD | photo display approximately 18.4x mm; not thread diameter | ______ |
| Caliper Photo 3 endpoints | display 132.92 mm; depth rod visibly free | ______ to ______ |
| Thread diameter and pitch | likely M8 x 1.25, unconfirmed | ______ |
| Original bolt length | unknown | ______ |
| Usable thread engagement / rear clearance | unknown | ______ |
| Left bolt-land stand-off from straightedge | unknown | ______ |
| Right bolt-land stand-off from straightedge | unknown | ______ |
| Clear left from bolt midpoint | 115.0 mm candidate | ______ |
| Clear right from bolt midpoint | 60.0 mm candidate | ______ |
| Case top below bolt-head lower tangent | 3.0 mm | verify: ______ |
| Hood above bolt-head upper tangent | 5.0 mm resolved datum within reported 5-7 mm | verify across depth: ______ |
| Clear below bolt-head lower tangent | 150.0 mm owner measured | verify: ______ |
| Remaining clearance below case | 59.0 mm | verify: ______ |
| Package projection, adapter rear to lid exterior | 79.5 mm | ______ |
| Projection including low-profile lid heads | 81.5 mm | ______ |
| Empty clearance-gauge depth | 83.0 mm | pass/fail: ______ |
| Other hood / hinge / strut sweeps away from the measured bolt-head datum | >= 20 mm target | ______ |
| Fixed-part and harness clearance | >= 10 mm target | ______ |
| Fuse-box lid and latch service sweep | unknown | ______ |
| Brake-reservoir cap and hand access | unknown | ______ |
| Pigtail gland thread/body/nut | Ø12.5 coupon | ______ |
| Inline plug length and cable bend radius | 60 mm working witness after 5 mm heel | ______ |
| Vehicle-structure P-clamp locations and fasteners | not represented by adapter concept | ______ |
| Worst running temperature | unknown | ______ |
| 30-60 minute parked hot-soak temperature | unknown | ______ |
| Cowl water path | unknown | ______ |

## Safe fit sequence

1. Identify the OEM purpose and torque of both bolts. Confirm pitch by hand; never force a fastener.
2. Remeasure bolt pitch with both opposed contacts visible. Name both endpoints of the 132.92 mm setting.
3. Print and test vehicle_bolt_coupon.stl without driving or running the engine.
4. Qualify the full-height painted support-on-model column and interface with standing_bridge_coupon.stl before either tall enclosure part; verify in the slicer preview that support reaches the roof.
5. Print slot_clearance_cage.stl. Install its open-ended down-hanging frame empty, with the planned rigid spacers.
6. Place soft modeling clay or crushable foam at the cage corners. Close the hood slowly by hand; never slam it.
7. Exercise the fuse-box latch/lid, reservoir cap, hood hinge, and gas strut through their full service/swept paths.
8. Seat the witness's 5 mm heel on the right datum. Verify 60 mm working clearance, downward drip loops, and separately measured vehicle-structure P-clamps for all three dummy pigtails.
9. Record underhood running and parked hot-soak temperatures before selecting material. Batteries and UPS boards remain prohibited underhood.

Do not run or drive the vehicle with a loose printed gauge. Remove all clay, foam,
tools, and temporary hardware before starting the engine.


import json, math, os
import FreeCAD as App
import Part
import MeshPart
from FreeCAD import Vector

P = {'case_width_mm': 175.0, 'case_height_mm': 88.0, 'case_depth_mm': 60.0, 'wall_mm': 3.2, 'back_wall_mm': 4.0, 'lid_thickness_mm': 5.0, 'mount_hole_spacing_mm': 50.53, 'mount_hole_d_mm': 9.2, 'mount_slot_length_mm': 14.0, 'mount_datum_x_mm': 115.0, 'case_top_to_head_bottom_mm': 3.0, 'hood_clearance_above_head_mm': 5.0, 'clearance_below_head_mm': 150.0, 'adapter_gap_mm': 12.0, 'gasket_cord_d_mm': 2.5, 'pigtail_gland_d_mm': 12.5}
FIXED = {'right_recess_depth_mm': 12.0, 'right_panel_web_mm': 3.2, 'cap_receiver_length_mm': 8.0, 'cap_receiver_radius_mm': 6.3, 'cap_receiver_root_radius_mm': 4.5, 'cap_screw_clearance_d_mm': 3.6, 'm3_insert_pocket_d_mm': 4.0, 'm3_insert_depth_mm': 6.0, 'cap_pilot_od_mm': 6.8, 'cap_pilot_length_mm': 1.5, 'cap_pilot_counterbore_d_mm': 7.2, 'cap_pilot_counterbore_depth_mm': 1.7, 'cap_driver_keepout_d_mm': 11.0, 'cap_seal_width_mm': 1.6, 'cap_seal_stock_thickness_mm': 1.0, 'cap_seal_depth_mm': 0.75, 'cap_seal_inset_mm': 1.6, 'front_right_seal_rail_mm': 3.2, 'backplane_thickness_mm': 3.0, 'backplane_standoff_mm': 6.0, 'backplane_boss_d_mm': 8.0, 'backplane_boss_length_mm': 6.0, 'backplane_insert_depth_mm': 4.5, 'backplane_countersink_d_mm': 6.4, 'backplane_countersink_depth_mm': 1.8, 'component_standoff_mm': 3.0, 'controller_standoff_od_mm': 6.0, 'controller_hole_d_mm': 2.4, 'gasket_groove_extra_width_mm': 0.8, 'gasket_land_extra_mm': 5.0, 'gland_keepout_d_mm': 16.0, 'gland_keepout_length_mm': 14.0, 'cable_tie_slot_width_mm': 3.2, 'cable_tie_slot_height_mm': 5.0, 'wall_sacrificial_membrane_mm': 0.45, 'adapter_plate_thickness_mm': 2.5, 'adapter_crossbar_width_mm': 86.7, 'adapter_top_inset_mm': 1.0, 'adapter_tab_overlap_mm': 5.0, 'adapter_case_hole_d_mm': 4.5, 'adapter_case_pattern_center_x_mm': 75.0, 'adapter_case_pattern_width_mm': 90.0, 'adapter_case_pattern_height_mm': 58.0, 'adapter_spacer_d_mm': 10.0, 'adapter_body_passage_d_mm': 10.4, 'adapter_sleeve_proud_mm': 0.1, 'minimum_sleeve_passage_ligament_mm': 8.0, 'minimum_mount_feature_clearance_mm': 2.0, 'vehicle_head_envelope_d_mm': 20.0, 'minimum_lower_clearance_reserve_mm': 20.0, 'rear_load_rib_width_mm': 3.2, 'rear_load_rib_depth_mm': 2.4, 'sleeve_collar_od_mm': 16.0, 'cap_lid_screw_edge_offset_mm': 3.5, 'minimum_lid_hole_ligament_mm': 1.5, 'lid_head_allowance_mm': 2.0, 'fit_cage_depth_margin_mm': 1.5, 'fit_cage_rail_mm': 5.0, 'fit_cage_brace_d_mm': 3.0, 'fit_static_clearance_mm': 10.0, 'fit_moving_clearance_mm': 20.0, 'external_pigtail_service_mm': 60.0, 'io_witness_datum_heel_mm': 5.0, 'v400_bed_diameter_mm': 300.0, 'v400_height_mm': 410.0, 'standing_body_brim_mm': 12.0, 'flat_part_brim_mm': 6.0}
MECH = {'coordinate_system': {'origin': 'lower-left corner of enclosure rear face', 'x': 'positive toward fuse/relay boxes', 'y': 'positive toward engine/camera', 'z': 'positive toward cowl', 'photo_bolt_midpoint_xz_mm': [115.0, 101.0]}, 'body_cap_interface_x_mm': 159.8, 'right_panel_face_x_mm': 163.0, 'lid_width_mm': 175.0, 'mount_centers_xz_mm': [[89.735, 101.0], [140.265, 101.0]], 'mount_features': ['round', 'horizontal_slot'], 'mount_datum_relative_envelope_mm': {'left': -115.0, 'right': 60.0, 'below': -101.0, 'above': 9.0}, 'bolt_head_envelope_mm': {'diameter': 20.0, 'lower_z': 91.0, 'upper_z': 111.0}, 'adapter_crossbar_x_mm': [71.65, 158.35], 'adapter_top_z_mm': 110.0, 'bolt_plane_hood_datum_z_mm': 116.0, 'lower_obstruction_z_mm': -59.0, 'case_drop_below_head_mm': 91.0, 'lower_clearance_reserve_mm': 59.0, 'adapter_case_centers_xz_mm': [[30.0, 15.0], [120.0, 15.0], [30.0, 73.0], [120.0, 73.0]], 'face_flange_width_mm': 10.8, 'service_throat_xz_mm': [10.8, 156.60000000000002, 10.8, 77.2], 'cap_screw_centers_yz_mm': [[6.0, 6.0], [54.0, 6.0], [6.0, 82.0], [54.0, 82.0]], 'cap_seam_gasket': {'path': 'closed rectangle', 'seat_width_mm': 1.6, 'seat_depth_mm': 0.75, 'nominal_stock_thickness_mm': 1.0, 'target_compression_percent': 25.0}, 'backplane_origin_mm': [11.3, 10.0, 11.700000000000001], 'backplane_size_mm': [144.8, 3.0, 64.6], 'backplane_mount_centers_xz_mm': [[45.0, 25.0], [110.0, 25.0], [45.0, 63.0], [110.0, 63.0]], 'backplane_cable_tie_slot_centers_xz_mm': [[110.0, 32.0], [145.0, 32.0], [110.0, 55.0], [145.0, 55.0]], 'gasket': {'cord_d_mm': 2.5, 'groove_width_mm': 3.3, 'groove_depth_mm': 1.875, 'land_inset_mm': 7.5, 'target_compression_percent': 25.0}, 'standing_footprint_mm': [60.0, 88.0], 'standing_body_height_mm': 159.8, 'right_cap_print_footprint_mm': [16.69999999999999, 60.0], 'standing_bridge_coupon_span_mm': 66.4, 'standing_bridge_coupon_support_height_mm': 156.60000000000002, 'full_case_width_mm': 175.0, 'v400_body_required_radius_mm': 65.2541078227774, 'installed_projection_mm': 79.5, 'installed_hardware_projection_mm': 81.5, 'fit_cage_envelope_mm': [175.0, 83.0, 110.0], 'photo_envelope_basis': 'owner-measured hood/drop envelope; 50.53 mm remains a slotted bolt-pitch candidate and exact hood slope across depth remains gated'}
LAYOUT = {'interface_pcb_reserved': {'origin_mm': [50.0, 16.0, 16.5], 'size_mm': [55.0, 15.0, 55.0], 'tier': 'single_backplane', 'mount': 'future-drill right-side backplane zone'}, 'dfrobot_dfr0975': {'origin_mm': [14.0, 16.0, 13.265], 'size_mm': [25.4, 15.35, 61.47], 'tier': 'single_backplane', 'mount': 'rotated 90 degrees on removable backplane'}, 'adafruit_microsd_4682': {'origin_mm': [115.0, 16.0, 19.0], 'size_mm': [25.4, 6.8, 22.86], 'tier': 'single_backplane', 'mount': 'future-drill/cable-tie zone; card edge toward front lid'}, 'adafruit_sht40_4885': {'origin_mm': [115.0, 16.0, 49.0], 'size_mm': [25.4, 6.5, 17.78], 'tier': 'single_backplane', 'mount': 'future-drill/cable-tie zone with thermal isolation'}}
IO = {'pigtail_glands': [{'id': 'LOW', 'center_yz_mm': [36.0, 16.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'HIGH', 'center_yz_mm': [36.0, 64.0], 'cutout_d_mm': 12.5, 'route': 'right, then down through external P-clamp and drip loop'}, {'id': 'POWER', 'center_yz_mm': [36.0, 40.0], 'cutout_d_mm': 12.5, 'route': 'right, then down to a fused sealed vehicle disconnect'}], 'power': {'installed_cutout': True, 'entry': 'POWER pigtail gland on removable right cap', 'requirement': 'source fuse, transient/reverse-polarity protection, and sealed disconnect'}, 'vent': {'installed_cutout': False, 'reason': 'no penetration until a purchased membrane vent is measured and qualified'}, 'external_connector_policy': 'short sealed pigtails; keyed inline disconnects outside enclosure; panel SP13 option requires separately measured doghouse'}
OUT = 'out12'
os.makedirs(OUT, exist_ok=True)

def die(message):
    print("CAD_ERROR " + message, flush=True)
    raise RuntimeError(message)

def bbox(shape):
    b = shape.BoundBox
    return {
        "min_mm": [b.XMin, b.YMin, b.ZMin],
        "max_mm": [b.XMax, b.YMax, b.ZMax],
        "size_mm": [b.XLength, b.YLength, b.ZLength],
    }

def assert_single(name, shape):
    if shape.isNull() or not shape.isValid() or len(shape.Solids) != 1 or shape.Volume <= 0:
        die("%s is not one valid positive-volume solid (solids=%d)" %
            (name, len(shape.Solids)))

def assert_valid(name, shape):
    if shape.isNull() or not shape.isValid():
        die("%s is null or invalid" % name)

def export_pair(shape, stem):
    shape.exportStep(os.path.join(OUT, stem + ".step"))
    mesh = MeshPart.meshFromShape(
        Shape=shape, LinearDeflection=0.08,
        AngularDeflection=0.25, Relative=False,
    )
    mesh.write(os.path.join(OUT, stem + ".stl"))

def add_feature(doc, name, label, shape, color, transparency=0):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = shape
    try:
        obj.ViewObject.ShapeColor = color
        obj.ViewObject.Transparency = transparency
    except Exception:
        pass
    return obj

def bed_orient(shape, rotation):
    result = shape.copy()
    result.Placement = App.Placement(Vector(0, 0, 0), rotation)
    b = result.BoundBox
    result.translate(Vector(-b.XMin, -b.YMin, -b.ZMin))
    return result

def hole_y(cx, cz, diameter, y0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(cx, y0, cz), Vector(0, 1, 0)
    )

def hole_x(cy, cz, diameter, x0, depth):
    return Part.makeCylinder(
        diameter / 2.0, depth, Vector(x0, cy, cz), Vector(1, 0, 0)
    )

def capsule_y(cx, cz, overall, diameter, y0, depth):
    travel = overall - diameter
    left = hole_y(cx - travel / 2.0, cz, diameter, y0, depth)
    right = hole_y(cx + travel / 2.0, cz, diameter, y0, depth)
    bridge = Part.makeBox(
        travel, depth, diameter,
        Vector(cx - travel / 2.0, y0, cz - diameter / 2.0),
    )
    return left.fuse(right).fuse(bridge).removeSplitter()

def cylinder_between(start, end, radius):
    direction = Vector(
        end[0] - start[0], end[1] - start[1], end[2] - start[2]
    )
    return Part.makeCylinder(radius, direction.Length, Vector(*start), direction)

def standing_open_frame(width, depth, height, rail, y0=0.0):
    # The X=max side is intentionally open.  After the -90 degree Y rotation,
    # this removes the otherwise unsupported long terminal bridge while the
    # two full-length X rails still mark the complete configured fit height.
    parts = [
        Part.makeBox(width, depth, rail, Vector(0, y0, 0)),
        Part.makeBox(width, depth, rail, Vector(0, y0, height - rail)),
        Part.makeBox(rail, depth, height - 2.0 * rail, Vector(0, y0, rail)),
    ]
    return parts[0].multiFuse(parts[1:]).removeSplitter()

L = P["case_width_mm"]
H = P["case_height_mm"]
D = P["case_depth_mm"]
WALL = P["wall_mm"]
BACK = P["back_wall_mm"]
LID_T = P["lid_thickness_mm"]
BODY_X = MECH["body_cap_interface_x_mm"]
PANEL_WEB = FIXED["right_panel_web_mm"]
PANEL_FACE_X = MECH["right_panel_face_x_mm"]
LID_W = MECH["lid_width_mm"]
LAND = MECH["gasket"]["land_inset_mm"]
GROOVE_W = MECH["gasket"]["groove_width_mm"]
GROOVE_D = MECH["gasket"]["groove_depth_mm"]
FACE_FLANGE = MECH["face_flange_width_mm"]
MEMBRANE = FIXED["wall_sacrificial_membrane_mm"]

# Main shell: an X-constant U-channel with a flat left build face.  The front
# and right faces remain open during the standing print.
outer = Part.makeBox(BODY_X, D, H)
cavity = Part.makeBox(
    BODY_X - WALL + 2.0,
    D - BACK + 2.0,
    H - 2.0 * WALL,
    Vector(WALL, BACK, WALL),
)
body = outer.cut(cavity).removeSplitter()

# Widen the front top, bottom, and left lands to the OUTSIDE of the complete
# groove band.  A narrow full-height right rail supports the closed cap-seam
# gasket and leaves a measured service throat for the populated backplane.
rail_depth = FIXED["m3_insert_depth_mm"] + 2.0
front_y = D - rail_depth
front_bottom = Part.makeBox(BODY_X, rail_depth, FACE_FLANGE, Vector(0, front_y, 0))
front_top = Part.makeBox(
    BODY_X, rail_depth, FACE_FLANGE, Vector(0, front_y, H - FACE_FLANGE)
)
front_left = Part.makeBox(
    FACE_FLANGE, rail_depth, H - 2.0 * FACE_FLANGE,
    Vector(0, front_y, FACE_FLANGE)
)
front_right = Part.makeBox(
    FIXED["front_right_seal_rail_mm"], rail_depth, H,
    Vector(BODY_X - FIXED["front_right_seal_rail_mm"], front_y, 0),
)
body = body.multiFuse(
    [front_bottom, front_top, front_left, front_right]
).removeSplitter()

# Four axial receiver cones support the removable right cap.  Constant-X
# corner ribs connect every receiver to an existing wall so no receiver begins
# as a late, unsupported island in the V400 standing orientation.
cap_screws = MECH["cap_screw_centers_yz_mm"]
receiver_ribs = []
for cy, cz in cap_screws:
    rib_y0 = 0.0 if cy < D / 2.0 else cy
    rib_y1 = cy if cy < D / 2.0 else D
    receiver_ribs.append(Part.makeBox(
        BODY_X, rib_y1 - rib_y0, 3.0,
        Vector(0, rib_y0, cz - 1.5),
    ))
body = body.multiFuse(receiver_ribs).removeSplitter()

receiver_len = FIXED["cap_receiver_length_mm"]
receivers = []
receiver_pockets = []
pilot_counterbores = []
for cy, cz in cap_screws:
    receiver = Part.makeCone(
        FIXED["cap_receiver_root_radius_mm"],
        FIXED["cap_receiver_radius_mm"],
        receiver_len,
        Vector(BODY_X - receiver_len, cy, cz),
        Vector(1, 0, 0),
    )
    receiver_clip = Part.makeBox(
        receiver_len + 0.2, D, H,
        Vector(BODY_X - receiver_len - 0.1, 0, 0),
    )
    receivers.append(receiver.common(receiver_clip).removeSplitter())
    receiver_pockets.append(Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["m3_insert_depth_mm"] + 0.25,
        Vector(BODY_X - FIXED["m3_insert_depth_mm"], cy, cz),
        Vector(1, 0, 0),
    ))
    pilot_counterbores.append(Part.makeCylinder(
        FIXED["cap_pilot_counterbore_d_mm"] / 2.0,
        FIXED["cap_pilot_counterbore_depth_mm"] + 0.1,
        Vector(BODY_X - FIXED["cap_pilot_counterbore_depth_mm"], cy, cz),
        Vector(1, 0, 0),
    ))
body = body.multiFuse(receivers).removeSplitter()
body = body.cut(
    Part.makeCompound(receiver_pockets + pilot_counterbores)
).removeSplitter()

# Eight body-side lid insert pockets enter from the front.  Two more cap-side
# screws are added below so all four sides of the full-width face seal clamp.
body_lid_screws = [
    [30.0, 4.0], [85.0, 4.0], [140.0, 4.0],
    [30.0, H - 4.0], [85.0, H - 4.0], [140.0, H - 4.0],
    [4.0, 30.0], [4.0, H - 30.0],
]
lid_insert_cuts = [
    hole_y(cx, cz, FIXED["m3_insert_pocket_d_mm"],
           D - FIXED["m3_insert_depth_mm"], FIXED["m3_insert_depth_mm"] + 0.25)
    for cx, cz in body_lid_screws
]
body = body.cut(Part.makeCompound(lid_insert_cuts)).removeSplitter()

# A shallow rear load-path grid ties all four sleeve nodes into the shell walls
# before the passages are cut.  Annular collars spread local bearing load; the
# grid stays behind the removable backplane and is aligned with the standing
# print rather than appearing as isolated late-layer features.
rear_rib_w = FIXED["rear_load_rib_width_mm"]
rear_rib_d = FIXED["rear_load_rib_depth_mm"]
rear_rib_y = BACK - 0.1
sleeve_nodes = MECH["adapter_case_centers_xz_mm"]
rear_load_ribs = []
for z_level in sorted(set(cz for _, cz in sleeve_nodes)):
    rear_load_ribs.append(Part.makeBox(
        BODY_X, rear_rib_d, rear_rib_w,
        Vector(0, rear_rib_y, z_level - rear_rib_w / 2.0),
    ))
for x_level in sorted(set(cx for cx, _ in sleeve_nodes)):
    rear_load_ribs.append(Part.makeBox(
        rear_rib_w, rear_rib_d, H,
        Vector(x_level - rear_rib_w / 2.0, rear_rib_y, 0),
    ))
sleeve_collars = [
    Part.makeCylinder(
        FIXED["sleeve_collar_od_mm"] / 2.0,
        rear_rib_d,
        Vector(cx, rear_rib_y, cz), Vector(0, 1, 0),
    )
    for cx, cz in sleeve_nodes
]
body = body.multiFuse(rear_load_ribs + sleeve_collars).removeSplitter()

# Four oversized rear passages let the metal compression sleeves continue
# through the complete polymer back wall and reinforced collars.  The M4 clamp
# load is metal-to-metal.
adapter_holes = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_holes.append(hole_y(
        cx, cz, FIXED["adapter_body_passage_d_mm"], -0.5,
        BACK + rear_rib_d + 1.0,
    ))
body = body.cut(Part.makeCompound(adapter_holes)).removeSplitter()

# Matching bosses make the single electronics backplane a real screwed
# interface rather than a floating reference.  Inserts open from the front;
# the remaining 1.5 mm root stays joined to the rear wall.
bp_y = MECH["backplane_origin_mm"][1]
backplane_mounts = MECH["backplane_mount_centers_xz_mm"]
backplane_bosses = [
    Part.makeCylinder(
        FIXED["backplane_boss_d_mm"] / 2.0,
        FIXED["backplane_boss_length_mm"] + 0.2,
        Vector(cx, BACK - 0.2, cz), Vector(0, 1, 0),
    )
    for cx, cz in backplane_mounts
]
backplane_boss_gussets = [
    Part.makeBox(
        FIXED["backplane_boss_d_mm"] + 4.0,
        rear_rib_d,
        3.0,
        Vector(
            cx - (FIXED["backplane_boss_d_mm"] + 4.0) / 2.0,
            rear_rib_y,
            cz - FIXED["backplane_boss_d_mm"] / 2.0,
        ),
    )
    for cx, cz in backplane_mounts
]
body = body.multiFuse(backplane_bosses + backplane_boss_gussets).removeSplitter()
backplane_insert_cuts = [
    Part.makeCylinder(
        FIXED["m3_insert_pocket_d_mm"] / 2.0,
        FIXED["backplane_insert_depth_mm"] + 0.1,
        Vector(cx, bp_y + 0.1, cz), Vector(0, -1, 0),
    )
    for cx, cz in backplane_mounts
]
body = body.cut(Part.makeCompound(backplane_insert_cuts)).removeSplitter()

# Two broad floor shelves carry the backplane's weight while the four rear M3
# screws retain it against vibration.  The board can still slide straight out
# toward +Y after its screws and pigtails are removed; a bottom-only cantilever
# is deliberately avoided.
bp_z = MECH["backplane_origin_mm"][2]
bp_t = MECH["backplane_size_mm"][1]
floor_shelf_y0 = BACK - 0.1
floor_shelf_depth = bp_y + bp_t - floor_shelf_y0
floor_shelf_z0 = WALL - 0.1
floor_shelves = [
    Part.makeBox(
        20.0,
        floor_shelf_depth,
        bp_z - floor_shelf_z0,
        Vector(cx - 10.0, floor_shelf_y0, floor_shelf_z0),
    )
    for cx in (60.0, 100.0)
]
body = body.multiFuse(floor_shelves).removeSplitter()

# Recessed right cap.  The small pigtail glands replace bulky SP13 panel
# barrels inside this constrained shell.  The open recess drains downward.
cap_web = Part.makeBox(PANEL_WEB, D, H, Vector(BODY_X, 0, 0))
recess_x = PANEL_FACE_X
recess_depth = FIXED["right_recess_depth_mm"]
rim = [
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, 0, 0)),
    Part.makeBox(recess_depth, WALL, H, Vector(recess_x, D - WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, 0)),
    Part.makeBox(recess_depth, D - 2.0 * WALL, WALL,
                 Vector(recess_x, WALL, H - WALL)),
]
cap = cap_web.multiFuse(rim).removeSplitter()

# Two cap-side face-lid bosses finish the ten-point compression pattern.  They
# are local to the removable cap and do not bridge into the main body.
cap_lid_screws = [
    [L - FIXED["cap_lid_screw_edge_offset_mm"], 30.0],
    [L - FIXED["cap_lid_screw_edge_offset_mm"], H - 30.0],
]
cap_clip = Part.makeBox(L - BODY_X, D, H, Vector(BODY_X, 0, 0))
cap_lid_bosses = [
    Part.makeCylinder(
        5.0, rail_depth,
        Vector(cx, D - rail_depth, cz), Vector(0, 1, 0),
    ).common(cap_clip).removeSplitter()
    for cx, cz in cap_lid_screws
]
cap = cap.multiFuse(cap_lid_bosses).removeSplitter()

# A closed, shallow gasket seat seals the removable cap-to-body seam.  Its
# rear/front and lower/upper legs are supported by the body walls and the
# dedicated front-right rail.  Qualification still requires physical leak and
# thermal-cycle tests; this geometry makes no IP claim.
cap_seal_w = FIXED["cap_seal_width_mm"]
cap_seal_d = FIXED["cap_seal_depth_mm"]
cap_seal_inset = FIXED["cap_seal_inset_mm"]
cap_seal_outer = Part.makeBox(
    cap_seal_d + 0.1,
    D - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.1,
        cap_seal_inset - cap_seal_w / 2.0,
        cap_seal_inset - cap_seal_w / 2.0,
    ),
)
cap_seal_inner = Part.makeBox(
    cap_seal_d + 0.3,
    D - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.2,
        cap_seal_inset + cap_seal_w / 2.0,
        cap_seal_inset + cap_seal_w / 2.0,
    ),
)
cap_seal_groove = cap_seal_outer.cut(cap_seal_inner).removeSplitter()
cap = cap.cut(cap_seal_groove).removeSplitter()

# Annular pilots register the cap with diametral and axial clearance in the
# matching body counterbores.  The old overlapping box tabs are intentionally
# absent.
cap_pilots = []
for cy, cz in cap_screws:
    pilot_outer = Part.makeCylinder(
        FIXED["cap_pilot_od_mm"] / 2.0,
        FIXED["cap_pilot_length_mm"] + 0.1,
        Vector(BODY_X - FIXED["cap_pilot_length_mm"], cy, cz),
        Vector(1, 0, 0),
    )
    pilot_bore = Part.makeCylinder(
        FIXED["cap_screw_clearance_d_mm"] / 2.0,
        FIXED["cap_pilot_length_mm"] + 0.3,
        Vector(BODY_X - FIXED["cap_pilot_length_mm"] - 0.1, cy, cz),
        Vector(1, 0, 0),
    )
    cap_pilots.append(pilot_outer.cut(pilot_bore).removeSplitter())
cap = cap.multiFuse(cap_pilots).removeSplitter()

gland_holes = []
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_holes.append(hole_x(
        cy, cz, gland["cutout_d_mm"], BODY_X - 0.5,
        PANEL_WEB + 0.5 - MEMBRANE,
    ))
cap_holes = [
    hole_x(cy, cz, FIXED["cap_screw_clearance_d_mm"],
           BODY_X - FIXED["cap_pilot_length_mm"] - 0.2,
           PANEL_WEB + FIXED["cap_pilot_length_mm"] + 0.4)
    for cy, cz in cap_screws
]
cap_lid_insert_cuts = [
    hole_y(
        cx, cz, FIXED["m3_insert_pocket_d_mm"],
        D - FIXED["m3_insert_depth_mm"], FIXED["m3_insert_depth_mm"] + 0.25,
    )
    for cx, cz in cap_lid_screws
]
cap = cap.cut(
    Part.makeCompound(gland_holes + cap_holes + cap_lid_insert_cuts)
).removeSplitter()
# Corner scallops preserve an Ø11 mm driver path to the four cap screws.  They
# affect only the drained outer eyebrow/rims; the closed seam gasket remains on
# the protected body-facing web.
driver_reliefs = [
    Part.makeCylinder(
        FIXED["cap_driver_keepout_d_mm"] / 2.0 + 0.2,
        recess_depth + 0.2,
        Vector(PANEL_FACE_X - 0.1, cy, cz), Vector(1, 0, 0),
    )
    for cy, cz in cap_screws
]
cap = cap.cut(Part.makeCompound(driver_reliefs)).removeSplitter()
drain_slot = Part.makeBox(
    recess_depth + 1.0, 12.0, WALL + 1.0,
    Vector(recess_x - 0.5, D - 18.0, -0.5),
)
cap = cap.cut(drain_slot).removeSplitter()

# Front service lid.  Its installed position is in front of the body.  The
# compact face gland uses a square-bottom groove and 25 percent target squeeze.
lid_blank = Part.makeBox(LID_W, LID_T, H, Vector(0, D, 0))
lid_installed = lid_blank.copy()
groove_outer = Part.makeBox(
    LID_W - 2.0 * LAND, GROOVE_D + 0.1, H - 2.0 * LAND,
    Vector(LAND, D - 0.1, LAND),
)
groove_inner = Part.makeBox(
    LID_W - 2.0 * (LAND + GROOVE_W),
    GROOVE_D + 0.3,
    H - 2.0 * (LAND + GROOVE_W),
    Vector(LAND + GROOVE_W, D - 0.2, LAND + GROOVE_W),
)
groove = groove_outer.cut(groove_inner).removeSplitter()
groove_plan_area = (
    (LID_W - 2.0 * LAND) * (H - 2.0 * LAND)
    - (LID_W - 2.0 * (LAND + GROOVE_W))
    * (H - 2.0 * (LAND + GROOVE_W))
)
actual_front_groove_depth = lid_blank.common(groove).Volume / groove_plan_area
if abs(actual_front_groove_depth - GROOVE_D) > 0.01:
    die("front gasket groove actual depth differs from its declaration")
lid_installed = lid_installed.cut(groove).removeSplitter()
lid_screws = body_lid_screws + cap_lid_screws
lid_clearance_holes = [
    hole_y(cx, cz, FIXED["cap_screw_clearance_d_mm"], D - 0.5, LID_T + 1.0)
    for cx, cz in lid_screws
]
lid_installed = lid_installed.cut(
    Part.makeCompound(lid_clearance_holes)
).removeSplitter()

# One removable vertical backplane.  Its four countersunk holes match the four
# shell bosses above; flush heads preserve the component plane.  The ESP32 has
# four modeled printed standoffs from its documented hole pattern.  The small
# modules use measured-after-purchase cable-tie slots instead of invented holes.
bp = MECH["backplane_origin_mm"]
bs = MECH["backplane_size_mm"]
backplane_installed = Part.makeBox(bs[0], bs[1], bs[2], Vector(*bp))
esp = LAYOUT["dfrobot_dfr0975"]["origin_mm"]
controller_mounts = [
    [esp[0] + local_x, esp[2] + local_z]
    for local_x, local_z in (
        [1.7, 1.7], [1.7, 58.3], [23.7, 1.7], [23.7, 58.3]
    )
]
controller_standoffs = [
    Part.makeCylinder(
        FIXED["controller_standoff_od_mm"] / 2.0,
        FIXED["component_standoff_mm"] + 0.1,
        Vector(cx, bp[1] + bs[1] - 0.1, cz), Vector(0, 1, 0),
    )
    for cx, cz in controller_mounts
]
backplane_installed = backplane_installed.multiFuse(
    controller_standoffs
).removeSplitter()
bp_cuts = [
    hole_y(cx, cz, 3.6, bp[1] - 0.2, bs[1] + 0.4)
    for cx, cz in backplane_mounts
]
for cx, cz in backplane_mounts:
    bp_cuts.append(Part.makeCone(
        FIXED["backplane_countersink_d_mm"] / 2.0,
        3.6 / 2.0,
        FIXED["backplane_countersink_depth_mm"] + 0.1,
        Vector(cx, bp[1] + bs[1] + 0.1, cz), Vector(0, -1, 0),
    ))

for cx, cz in controller_mounts:
    bp_cuts.append(hole_y(
        cx, cz, FIXED["controller_hole_d_mm"], bp[1] - 0.2,
        bs[1] + FIXED["component_standoff_mm"] + 0.5,
    ))
for cx, cz in MECH["backplane_cable_tie_slot_centers_xz_mm"]:
    bp_cuts.append(Part.makeBox(
        FIXED["cable_tie_slot_width_mm"], bs[1] + 0.4,
        FIXED["cable_tie_slot_height_mm"],
        Vector(
            cx - FIXED["cable_tie_slot_width_mm"] / 2.0,
            bp[1] - 0.2,
            cz - FIXED["cable_tie_slot_height_mm"] / 2.0,
        ),
    ))
backplane_installed = backplane_installed.cut(
    Part.makeCompound(bp_cuts)
).removeSplitter()

# Component and gland reference envelopes.
component_shapes = {}
for name, item in LAYOUT.items():
    component_shapes[name] = Part.makeBox(
        item["size_mm"][0], item["size_mm"][1], item["size_mm"][2],
        Vector(*item["origin_mm"]),
    )
gland_keepouts = {}
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    gland_keepouts[gland["id"]] = Part.makeCylinder(
        FIXED["gland_keepout_d_mm"] / 2.0,
        FIXED["gland_keepout_length_mm"],
        Vector(BODY_X - FIXED["gland_keepout_length_mm"], cy, cz),
        Vector(1, 0, 0),
    )

# External nut and driver cylinders verify that the recessed cap remains
# wrenchable without clipping its eyebrow/rims.
external_gland_keepouts = {}
for gland in IO["pigtail_glands"]:
    cy, cz = gland["center_yz_mm"]
    external_gland_keepouts[gland["id"]] = Part.makeCylinder(
        FIXED["gland_keepout_d_mm"] / 2.0,
        FIXED["right_recess_depth_mm"],
        Vector(PANEL_FACE_X, cy, cz), Vector(1, 0, 0),
    )
cap_driver_keepouts = {}
for index, (cy, cz) in enumerate(cap_screws, start=1):
    cap_driver_keepouts["CAP_%d" % index] = Part.makeCylinder(
        FIXED["cap_driver_keepout_d_mm"] / 2.0,
        FIXED["right_recess_depth_mm"],
        Vector(PANEL_FACE_X, cy, cz), Vector(1, 0, 0),
    )

# Thin contact probes are analytic audit geometry, not exported seals.  The
# face probe must be supported by body+cap; the cap probe must be supported by
# the body rear/top/bottom/front-right rails.
face_probe_outer = Part.makeBox(
    LID_W - 2.0 * LAND, 0.1, H - 2.0 * LAND,
    Vector(LAND, D - 0.1, LAND),
)
face_probe_inner = Part.makeBox(
    LID_W - 2.0 * FACE_FLANGE, 0.2, H - 2.0 * FACE_FLANGE,
    Vector(FACE_FLANGE, D - 0.15, FACE_FLANGE),
)
face_seal_probe = face_probe_outer.cut(face_probe_inner).removeSplitter()
cap_probe_outer = Part.makeBox(
    0.1,
    D - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset - cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.1,
        cap_seal_inset - cap_seal_w / 2.0,
        cap_seal_inset - cap_seal_w / 2.0,
    ),
)
cap_probe_inner = Part.makeBox(
    0.2,
    D - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    H - 2.0 * (cap_seal_inset + cap_seal_w / 2.0),
    Vector(
        BODY_X - 0.15,
        cap_seal_inset + cap_seal_w / 2.0,
        cap_seal_inset + cap_seal_w / 2.0,
    ),
)
cap_seal_probe = cap_probe_outer.cut(cap_probe_inner).removeSplitter()

# Unreleased flat T-shaped load-path concept.  The broad lower plane carries
# the four case sleeves while a narrow V1-style upper flange reaches only to
# the bolt-head silhouette.  It is exported as inspection STEP/STL; a production metal
# part still needs formed returns or equivalent stiffness and direct land
# measurements.  The printable template below is never a load path.
adapter_t = FIXED["adapter_plate_thickness_mm"]
adapter_y = -P["adapter_gap_mm"] - adapter_t
adapter_tab_x0, adapter_tab_x1 = MECH["adapter_crossbar_x_mm"]
adapter_tab_z0 = H - FIXED["adapter_tab_overlap_mm"]
adapter_lower = Part.makeBox(L, adapter_t, H, Vector(0, adapter_y, 0))
adapter_tab = Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    adapter_t,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, adapter_y, adapter_tab_z0),
)
adapter_blank = adapter_lower.fuse(adapter_tab).removeSplitter()
mounts = MECH["mount_centers_xz_mm"]
adapter_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"],
           adapter_y - 0.5, adapter_t + 1.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    adapter_cutters.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"],
        adapter_y - 0.5, adapter_t + 1.0,
    ))
adapter_plate = adapter_blank.cut(Part.makeCompound(adapter_cutters)).removeSplitter()
spacers = []
adapter_head_keepouts = []
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    sleeve_length = (
        P["adapter_gap_mm"] + BACK + FIXED["adapter_sleeve_proud_mm"]
    )
    sleeve = Part.makeCylinder(
        FIXED["adapter_spacer_d_mm"] / 2.0,
        sleeve_length,
        Vector(cx, -P["adapter_gap_mm"], cz),
        Vector(0, 1, 0),
    )
    bore = Part.makeCylinder(
        FIXED["adapter_case_hole_d_mm"] / 2.0,
        sleeve_length + 0.2,
        Vector(cx, -P["adapter_gap_mm"] - 0.1, cz),
        Vector(0, 1, 0),
    )
    spacers.append(sleeve.cut(bore).removeSplitter())
    adapter_head_keepouts.append(Part.makeCylinder(
        4.0, FIXED["lid_head_allowance_mm"],
        Vector(cx, BACK + FIXED["adapter_sleeve_proud_mm"], cz),
        Vector(0, 1, 0),
    ))
adapter_reference = Part.makeCompound([adapter_plate] + spacers)

# Measured-envelope reference geometry.  These are inspection STEP shapes, not
# print parts.  Bolt heads use a conservative envelope.  The thin hood datum is
# confined to the bolt plane because the hood slope across case depth remains
# unknown; the lower plane records the reported drop.
vehicle_bolt_head_keepouts = [
    Part.makeCylinder(
        FIXED["vehicle_head_envelope_d_mm"] / 2.0,
        min(P["adapter_gap_mm"], 8.0),
        Vector(mx, adapter_y + adapter_t, mz), Vector(0, 1, 0),
    )
    for mx, mz in mounts
]
bolt_head_reference = Part.makeCompound(vehicle_bolt_head_keepouts)
bolt_plane_hood_datum = Part.makeBox(
    L,
    adapter_t,
    3.0,
    Vector(0, adapter_y, MECH["bolt_plane_hood_datum_z_mm"]),
)
lower_obstruction_keepout = Part.makeBox(
    L,
    MECH["fit_cage_envelope_mm"][1],
    3.0,
    Vector(0, adapter_y, MECH["lower_obstruction_z_mm"] - 3.0),
)

# Flat printed drill template uses the exact adapter holes, but is explicitly
# too thin and too creep-prone to become a vehicle bracket.
adapter_template_blank = Part.makeBox(L, 3.0, H)
adapter_template_blank = adapter_template_blank.fuse(Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    3.0,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, 0, adapter_tab_z0),
)).removeSplitter()
template_cuts = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
]
for cx, cz in MECH["adapter_case_centers_xz_mm"]:
    template_cuts.append(hole_y(
        cx, cz, FIXED["adapter_case_hole_d_mm"], -0.5, 4.0
    ))
adapter_template = adapter_template_blank.cut(
    Part.makeCompound(template_cuts)
).removeSplitter()

# Low-material installed-envelope cage.  Its default depth includes the
# adapter-back-to-lid package span, low-profile lid heads, and an extra fit margin.
cage_depth = MECH["fit_cage_envelope_mm"][1]
rail = FIXED["fit_cage_rail_mm"]
rear_frame = standing_open_frame(L, 3.0, H, rail, 0.0)
front_frame = standing_open_frame(L, 3.0, H, rail, cage_depth - 3.0)
long_rails = [
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, 0)),
    Part.makeBox(rail, cage_depth, rail, Vector(0, 0, H - rail)),
]
cage_brace_r = FIXED["fit_cage_brace_d_mm"] / 2.0
cage_x0 = rail / 2.0
cage_x1 = L - rail / 2.0
cage_y0 = 1.5
cage_y1 = cage_depth - 1.5
cage_braces = [
    cylinder_between(
        [cage_x0, cage_y0, rail / 2.0],
        [cage_x1, cage_y1, rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y1, rail / 2.0],
        [cage_x1, cage_y0, rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y0, H - rail / 2.0],
        [cage_x1, cage_y1, H - rail / 2.0],
        cage_brace_r,
    ),
    cylinder_between(
        [cage_x0, cage_y1, H - rail / 2.0],
        [cage_x1, cage_y0, H - rail / 2.0],
        cage_brace_r,
    ),
]
crossbar = Part.makeBox(
    adapter_tab_x1 - adapter_tab_x0,
    3.0,
    MECH["adapter_top_z_mm"] - adapter_tab_z0,
    Vector(adapter_tab_x0, 0, adapter_tab_z0),
)
fit_cage_blank = rear_frame.multiFuse(
    [front_frame, crossbar] + long_rails + cage_braces
).removeSplitter()
fit_cage = fit_cage_blank.cut(Part.makeCompound([
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 4.0),
])).removeSplitter()
cage_terminal_probe = Part.makeBox(
    1.0,
    cage_depth - 2.0 * rail,
    H - 2.0 * rail,
    Vector(L - 0.5, rail, rail),
)
cage_terminal_overlap = fit_cage.common(cage_terminal_probe).Volume
if cage_terminal_overlap > 0.01:
    die("fit cage terminal opening is obstructed")

# Compact bolt coupon with the same round + horizontal-slot datum.
coupon_w = 90.0
coupon_h = 32.0
coupon_center = coupon_w / 2.0
coupon_left_x = coupon_center - P["mount_hole_spacing_mm"] / 2.0
coupon_right_x = coupon_center + P["mount_hole_spacing_mm"] / 2.0
bolt_coupon_blank = Part.makeBox(coupon_w, 4.0, coupon_h)
bolt_coupon = bolt_coupon_blank.cut(Part.makeCompound([
    hole_y(coupon_left_x, coupon_h / 2.0, P["mount_hole_d_mm"], -0.5, 5.0),
    capsule_y(coupon_right_x, coupon_h / 2.0, P["mount_slot_length_mm"],
              P["mount_hole_d_mm"], -0.5, 5.0),
])).removeSplitter()

# Materially inspect the mount cuts after each Boolean operation.  Comparing
# the actual material removed from the blank against the intended cutter catches
# a missing, shifted, undersized, or oversized round/slot cut instead of merely
# echoing the requested parameters into the result report.
mount_feature_geometry_checks = []
def check_mount_feature(part_name, feature_name, blank, cut_part, cutter):
    cutter_box = cutter.BoundBox
    blank_box = blank.BoundBox
    margin = 1.0
    window = Part.makeBox(
        cutter_box.XLength + 2.0 * margin,
        blank_box.YLength + 2.0,
        cutter_box.ZLength + 2.0 * margin,
        Vector(
            cutter_box.XMin - margin,
            blank_box.YMin - 1.0,
            cutter_box.ZMin - margin,
        ),
    )
    actual = blank.cut(cut_part).common(window).removeSplitter()
    expected = blank.common(cutter).common(window).removeSplitter()
    extra = actual.cut(expected).Volume
    missing = expected.cut(actual).Volume
    actual_box = actual.BoundBox
    expected_box = expected.BoundBox
    actual_center = [
        (actual_box.XMin + actual_box.XMax) / 2.0,
        (actual_box.ZMin + actual_box.ZMax) / 2.0,
    ]
    expected_center = [
        (expected_box.XMin + expected_box.XMax) / 2.0,
        (expected_box.ZMin + expected_box.ZMax) / 2.0,
    ]
    actual_size = [actual_box.XLength, actual_box.ZLength]
    expected_size = [expected_box.XLength, expected_box.ZLength]
    max_center_error = max(
        abs(actual_center[index] - expected_center[index]) for index in range(2)
    )
    max_size_error = max(
        abs(actual_size[index] - expected_size[index]) for index in range(2)
    )
    passed = (
        not actual.isNull()
        and not expected.isNull()
        and extra <= 0.0001
        and missing <= 0.0001
        and max_center_error <= 0.001
        and max_size_error <= 0.001
    )
    row = {
        "part": part_name,
        "feature": feature_name,
        "actual_center_xz_mm": actual_center,
        "expected_center_xz_mm": expected_center,
        "actual_size_xz_mm": actual_size,
        "expected_size_xz_mm": expected_size,
        "extra_removed_mm3": extra,
        "missing_removed_mm3": missing,
        "pass": passed,
    }
    mount_feature_geometry_checks.append(row)
    if not passed:
        die("%s %s mount-cut geometry drifted" % (part_name, feature_name))

installed_mount_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"], P["mount_hole_d_mm"], adapter_y - 0.5, adapter_t + 1.0),
]
template_mount_cutters = [
    hole_y(mounts[0][0], mounts[0][1], P["mount_hole_d_mm"], -0.5, 4.0),
    capsule_y(mounts[1][0], mounts[1][1], P["mount_slot_length_mm"], P["mount_hole_d_mm"], -0.5, 4.0),
]
coupon_mount_cutters = [
    hole_y(coupon_left_x, coupon_h / 2.0, P["mount_hole_d_mm"], -0.5, 5.0),
    capsule_y(coupon_right_x, coupon_h / 2.0, P["mount_slot_length_mm"], P["mount_hole_d_mm"], -0.5, 5.0),
]
for part_name, blank, cut_part, cutters in (
    ("metal_adapter_concept", adapter_blank, adapter_plate, installed_mount_cutters),
    ("adapter_drill_template", adapter_template_blank, adapter_template, template_mount_cutters),
    ("slot_clearance_cage", fit_cage_blank, fit_cage, template_mount_cutters),
    ("vehicle_bolt_coupon", bolt_coupon_blank, bolt_coupon, coupon_mount_cutters),
):
    check_mount_feature(part_name, "round", blank, cut_part, cutters[0])
    check_mount_feature(part_name, "horizontal_slot", blank, cut_part, cutters[1])

# 45/55/65 mm comb for measuring depth at several points on the stamped
# firewall.  The connected heel keeps it one printable solid.
depth_comb = Part.makeBox(32.0, 5.0, 5.0)
for index, length in enumerate((45.0, 55.0, 65.0)):
    depth_comb = depth_comb.fuse(
        Part.makeBox(6.0, length, 6.0, Vector(2.0 + index * 11.0, 0, 0))
    )
depth_comb = depth_comb.removeSplitter()

# A 5 mm datum heel plus 60 mm exposed arm makes the right-side pigtail and
# inline-connector service zone measurable during the static fit test.
io_witness_overall = (
    FIXED["io_witness_datum_heel_mm"] + FIXED["external_pigtail_service_mm"]
)
io_witness = Part.makeBox(io_witness_overall, 8.0, 8.0)
io_witness = io_witness.fuse(
    Part.makeBox(FIXED["io_witness_datum_heel_mm"], 24.0, 8.0, Vector(0, 0, 0))
).removeSplitter()

# Conservative full-height support-process coupon for both standing parts.  Its
# 12 mm-deep, 3.2 mm-thick roof spans the body's larger terminal-rail opening
# at the same height, qualifying both the support column and interface.  The
# shorter cap rim is bounded by the same settings.
bridge_span = MECH["standing_bridge_coupon_span_mm"]
bridge_pier = 5.0
bridge_depth = 12.0
bridge_height = MECH["standing_bridge_coupon_support_height_mm"]
bridge_coupon_width = bridge_span + 2.0 * bridge_pier
bridge_coupon = Part.makeBox(bridge_coupon_width, bridge_depth, 3.0)
bridge_coupon = bridge_coupon.multiFuse([
    Part.makeBox(bridge_pier, bridge_depth, bridge_height),
    Part.makeBox(
        bridge_pier, bridge_depth, bridge_height,
        Vector(bridge_pier + bridge_span, 0, 0),
    ),
    Part.makeBox(
        bridge_coupon_width, bridge_depth, FIXED["front_right_seal_rail_mm"],
        Vector(0, 0, bridge_height),
    ),
]).removeSplitter()

# Exact web-thickness coupons for purchased gland measurement and for the
# standing shell's horizontal-hole membrane process.
gland_coupon = Part.makeBox(72.0, PANEL_WEB, 30.0)
coupon_features = []
for index, delta in enumerate((0.0, 0.2, 0.4)):
    cx = 14.0 + 22.0 * index
    diameter = P["pigtail_gland_d_mm"] + delta
    gland_coupon = gland_coupon.cut(hole_y(
        cx, 15.0, diameter, -0.5, PANEL_WEB + 1.0
    ))
    coupon_features.append({"x_mm": cx, "diameter_mm": diameter})
wall_coupon = Part.makeBox(30.0, 12.0, 28.0)
wall_hole = hole_y(
    15.0, 14.0, P["pigtail_gland_d_mm"],
    MEMBRANE, 12.0 - MEMBRANE + 1.0,
)
wall_coupon = wall_coupon.cut(wall_hole).removeSplitter()

# Production print transforms.
body_standing = bed_orient(
    body, App.Rotation(Vector(0, 1, 0), -90.0)
)
cap_print = bed_orient(
    cap, App.Rotation(Vector(0, 0, 1), 0.0)
)
lid_print = bed_orient(
    lid_installed, App.Rotation(Vector(1, 0, 0), -90.0)
)
backplane_print = bed_orient(
    backplane_installed, App.Rotation(Vector(1, 0, 0), 90.0)
)
adapter_template_print = bed_orient(
    adapter_template, App.Rotation(Vector(1, 0, 0), 90.0)
)
bolt_coupon_print = bed_orient(
    bolt_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)
fit_cage_standing = bed_orient(
    fit_cage, App.Rotation(Vector(0, 1, 0), -90.0)
)
gland_coupon_print = bed_orient(
    gland_coupon, App.Rotation(Vector(1, 0, 0), 90.0)
)

if abs(cap_print.BoundBox.ZLength - H) > 0.01:
    die("right cap is not upright on its installed Z-bottom print face")
if abs(lid_print.BoundBox.ZLength - LID_T) > 0.01:
    die("front lid is not exterior-face-down with the gasket groove opening up")

shapes = {
    "body": body,
    "body_standing": body_standing,
    "right_pigtail_cap": cap,
    "right_pigtail_cap_print": cap_print,
    "front_lid": lid_print,
    "electronics_backplane": backplane_print,
    "slot_clearance_cage": fit_cage_standing,
    "vehicle_bolt_coupon": bolt_coupon_print,
    "adapter_drill_template": adapter_template_print,
    "depth_feeler_45_55_65": depth_comb,
    "right_io_60mm_witness": io_witness,
    "pigtail_gland_coupon": gland_coupon_print,
    "standing_wall_hole_coupon": wall_coupon,
    "standing_bridge_coupon": bridge_coupon,
    "reference_right_pigtail_cap_installed": cap,
    "reference_front_lid_installed": lid_installed,
    "reference_electronics_backplane_installed": backplane_installed,
}
for name, shape in shapes.items():
    assert_single(name, shape)
    export_pair(shape, name)
for name, shape in component_shapes.items():
    assert_single("reference_" + name, shape)
    export_pair(shape, "reference_" + name)
for name, shape in gland_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_gland_keepout")
for name, shape in external_gland_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_gland_tool_keepout")
for name, shape in cap_driver_keepouts.items():
    export_pair(shape, "reference_" + name.lower() + "_driver_keepout")

assert_valid("adapter_reference", adapter_reference)
export_pair(adapter_reference, "reference_adapter_concept")
assert_valid("bolt_head_reference", bolt_head_reference)
bolt_head_reference.exportStep(os.path.join(OUT, "reference_bolt_head_keepouts.step"))
assert_single("bolt_plane_hood_datum", bolt_plane_hood_datum)
bolt_plane_hood_datum.exportStep(
    os.path.join(OUT, "reference_bolt_plane_hood_datum.step")
)
assert_single("lower_obstruction_keepout", lower_obstruction_keepout)
lower_obstruction_keepout.exportStep(
    os.path.join(OUT, "reference_lower_obstruction_keepout.step")
)

assembly_parts = [
    body, cap, lid_installed, backplane_installed,
] + list(component_shapes.values()) + [adapter_reference]
assembly = Part.makeCompound(assembly_parts)
assert_valid("assembly", assembly)
if abs(assembly.BoundBox.YLength - MECH["installed_projection_mm"]) > 0.01:
    die("assembly Y span does not equal the adapter-back-to-lid package projection")
if abs(fit_cage.BoundBox.YLength - MECH["fit_cage_envelope_mm"][1]) > 0.01:
    die("fit-cage Y span does not equal its conservative clearance envelope")
if (
    assembly.BoundBox.XLength > L + 0.01
    or assembly.BoundBox.ZMin < -0.01
    or assembly.BoundBox.ZMax > MECH["adapter_top_z_mm"] + 0.01
):
    die("assembly exceeds the declared X/Z vehicle envelope")
assembly.exportStep(os.path.join(OUT, "assembly.step"))
assembly_mesh = MeshPart.meshFromShape(
    Shape=assembly, LinearDeflection=0.08,
    AngularDeflection=0.25, Relative=False,
)
assembly_mesh.write(os.path.join(OUT, "assembly.stl"))

collision_checks = []
def no_overlap(left_name, left_shape, right_name, right_shape, limit=0.01):
    volume = left_shape.common(right_shape).Volume
    row = {
        "left": left_name, "right": right_name,
        "overlap_mm3": volume, "limit_mm3": limit,
        "pass": volume <= limit,
    }
    collision_checks.append(row)
    if not row["pass"]:
        die("%s overlaps %s by %.6f mm^3" % (left_name, right_name, volume))

# Core removable-interface and structural-load-path checks.
no_overlap("body", body, "right_cap", cap)
no_overlap("body", body, "front_lid", lid_installed)
no_overlap("right_cap", cap, "front_lid", lid_installed)
no_overlap("body", body, "metal_adapter", adapter_reference)
for index, head in enumerate(vehicle_bolt_head_keepouts, start=1):
    no_overlap("body", body, "vehicle_bolt_head_%d" % index, head)
no_overlap("body", body, "bolt_plane_hood_datum", bolt_plane_hood_datum)
no_overlap(
    "metal_adapter", adapter_reference,
    "bolt_plane_hood_datum", bolt_plane_hood_datum,
)
no_overlap("body", body, "lower_obstruction_keepout", lower_obstruction_keepout)
no_overlap("body", body, "electronics_backplane", backplane_installed)
no_overlap("right_cap", cap, "electronics_backplane", backplane_installed)
for index, head in enumerate(adapter_head_keepouts, start=1):
    no_overlap(
        "adapter_head_%d" % index, head,
        "electronics_backplane", backplane_installed,
    )
for name, keepout in external_gland_keepouts.items():
    no_overlap(name + "_gland_tool_keepout", keepout, "right_cap", cap)
for name, keepout in cap_driver_keepouts.items():
    no_overlap(name + "_driver_keepout", keepout, "right_cap", cap)

support_checks = []
shell_without_lid = body.fuse(cap)
for support_name, probe, support in (
    ("front_face_gasket", face_seal_probe, shell_without_lid),
    ("closed_cap_seam_gasket", cap_seal_probe, body),
):
    supported = probe.common(support).Volume
    coverage = supported / probe.Volume if probe.Volume else 0.0
    row = {
        "interface": support_name,
        "probe_mm3": probe.Volume,
        "supported_mm3": supported,
        "coverage_percent": 100.0 * coverage,
        "minimum_percent": 99.9,
        "pass": coverage >= 0.999,
    }
    support_checks.append(row)
    if not row["pass"]:
        die("%s support coverage is %.5f percent" %
            (support_name, row["coverage_percent"]))

# Verify service removal as actual solids at 1 mm increments.  The complete
# populated backplane must pass the face throat.  With the lid
# removed, the cap must withdraw toward +X.
service_sweep_checks = []
loaded_backplane = Part.makeCompound([
    backplane_installed,
    *component_shapes.values(),
])
for travel in range(1, int(D + 6.0)):
    moving = loaded_backplane.copy()
    moving.translate(Vector(0, float(travel), 0))
    overlap = moving.common(shell_without_lid).Volume
    service_sweep_checks.append({
        "interface": "loaded_backplane_+Y",
        "travel_mm": travel,
        "overlap_mm3": overlap,
        "pass": overlap <= 0.01,
    })
    if overlap > 0.01:
        die("loaded backplane removal collides at +Y=%d mm" % travel)
for travel in range(1, 21):
    moving = cap.copy()
    moving.translate(Vector(float(travel), 0, 0))
    overlap = moving.common(body).Volume
    service_sweep_checks.append({
        "interface": "right_cap_+X",
        "travel_mm": travel,
        "overlap_mm3": overlap,
        "pass": overlap <= 0.01,
    })
    if overlap > 0.01:
        die("right cap removal collides at +X=%d mm" % travel)

component_names = list(component_shapes)
for index, left_name in enumerate(component_names):
    for right_name in component_names[index + 1:]:
        no_overlap(
            left_name, component_shapes[left_name],
            right_name, component_shapes[right_name],
        )
for name, shape in component_shapes.items():
    no_overlap(name, shape, "body", body)
    no_overlap(name, shape, "right_cap", cap)
    no_overlap(name, shape, "front_lid", lid_installed)
    no_overlap(name, shape, "electronics_backplane", backplane_installed)
    for gland_name, gland_shape in gland_keepouts.items():
        no_overlap(name, shape, gland_name + "_gland_keepout", gland_shape)

doc = App.newDocument("AC_Diagnostic_Enclosure_Hood_Flange_V4")
add_feature(doc, "Body", "Standing-print compact shell", body, (0.10, 0.28, 0.52))
add_feature(doc, "RightPigtailCap", "Recessed right pigtail cap", cap, (0.18, 0.46, 0.72))
add_feature(doc, "FrontLid", "Engine-facing service lid", lid_installed, (0.92, 0.34, 0.08), 12)
add_feature(doc, "Backplane", "Vertical electronics backplane", backplane_installed, (0.72, 0.72, 0.76), 15)
add_feature(doc, "MetalAdapterConcept", "UNRELEASED adapter measurement concept", adapter_reference, (0.58, 0.60, 0.64), 10)
add_feature(doc, "BoltHeadKeepouts", "Conservative bolt-head envelopes", bolt_head_reference, (0.75, 0.75, 0.78), 55)
add_feature(
    doc, "BoltPlaneHoodDatum",
    "Reported hood datum at bolt plane; full-depth slope unknown",
    bolt_plane_hood_datum, (0.88, 0.10, 0.10), 82,
)
add_feature(
    doc, "LowerObstructionKeepout",
    "Reported %.1f mm lower obstruction plane" % P["clearance_below_head_mm"],
    lower_obstruction_keepout, (0.95, 0.55, 0.05), 85,
)
palette = [
    (0.12, 0.62, 0.24), (0.65, 0.22, 0.75),
    (0.06, 0.52, 0.84), (0.91, 0.62, 0.06), (0.08, 0.72, 0.68),
]
for index, (name, shape) in enumerate(component_shapes.items()):
    add_feature(doc, "Reference_" + name, name, shape, palette[index], 50)
for name, shape in gland_keepouts.items():
    add_feature(doc, "Keepout_" + name, name + " gland keepout", shape, (0.9, 0.1, 0.1), 82)
for name, shape in external_gland_keepouts.items():
    add_feature(doc, "ToolKeepout_" + name, name + " gland tool keepout", shape, (0.95, 0.35, 0.08), 82)
for name, shape in cap_driver_keepouts.items():
    add_feature(doc, "DriverKeepout_" + name, name + " cap driver keepout", shape, (0.96, 0.72, 0.08), 82)
doc.recompute()
doc.saveAs(os.path.join(OUT, "assembly.FCStd"))

shape_validation = {}
for name, shape in shapes.items():
    shape_validation[name] = {
        "valid": shape.isValid(),
        "solids": len(shape.Solids),
        "volume_mm3": shape.Volume,
        "bbox": bbox(shape),
    }
shape_validation["assembly"] = {
    "valid": assembly.isValid(),
    "solids": len(assembly.Solids),
    "bbox": bbox(assembly),
}

print_brims = {
    "body_standing": 12.0,
    "right_pigtail_cap_print": 8.0,
    "front_lid": 6.0,
    "electronics_backplane": 6.0,
    "slot_clearance_cage": 12.0,
    "vehicle_bolt_coupon": 6.0,
    "adapter_drill_template": 6.0,
    "depth_feeler_45_55_65": 6.0,
    "right_io_60mm_witness": 6.0,
    "pigtail_gland_coupon": 6.0,
    "standing_wall_hole_coupon": 6.0,
    "standing_bridge_coupon": 6.0,
}
print_volume_checks = []
for name, brim in print_brims.items():
    b = shapes[name].BoundBox
    required_radius = math.hypot(b.XLength, b.YLength) / 2.0 + brim
    passed = (
        abs(b.ZMin) <= 0.01
        and required_radius <= FIXED["v400_bed_diameter_mm"] / 2.0 + 0.01
        and b.ZLength <= FIXED["v400_height_mm"] + 0.01
        and shapes[name].isValid()
        and len(shapes[name].Solids) == 1
        and shapes[name].Volume > 0.0
    )
    row = {
        "part": name,
        "footprint_mm": [b.XLength, b.YLength],
        "height_mm": b.ZLength,
        "brim_mm": brim,
        "required_radius_mm": required_radius,
        "bed_seated_zmin_mm": b.ZMin,
        "pass": passed,
    }
    print_volume_checks.append(row)
    if not passed:
        die("%s exceeds the declared FLSUN V400 print gate" % name)

result = {
    "freecad_version": App.Version(),
    "shape_validation": shape_validation,
    "collision_checks": collision_checks,
    "seal_support_checks": support_checks,
    "service_sweep_checks": service_sweep_checks,
    "print_volume_checks": print_volume_checks,
    "mount_feature_geometry_checks": mount_feature_geometry_checks,
    "actual_front_groove_depth_mm": actual_front_groove_depth,
    "cap_pilot_annular_wall_mm": (
        FIXED["cap_pilot_od_mm"] - FIXED["cap_screw_clearance_d_mm"]
    ) / 2.0,
    "cap_insert_effective_seat_depth_mm": (
        FIXED["m3_insert_depth_mm"] - FIXED["cap_pilot_counterbore_depth_mm"]
    ),
    "cap_fastener_count": len(cap_screws),
    "controller_standoff_centers_xz_mm": controller_mounts,
    "mount": {
        "datum": "derived top-flange bolt midpoint above the enclosure",
        "centers_xz_mm": mounts,
        "round_d_mm": P["mount_hole_d_mm"],
        "slot_overall_mm": [P["mount_slot_length_mm"], P["mount_hole_d_mm"]],
        "adapter_material": "measurement-gated metal fabrication concept; material and bends not released",
        "printed_template_load_bearing": False,
        "case_top_to_head_bottom_mm": P["case_top_to_head_bottom_mm"],
        "head_lower_upper_z_mm": [
            MECH["bolt_head_envelope_mm"]["lower_z"],
            MECH["bolt_head_envelope_mm"]["upper_z"],
        ],
        "adapter_top_z_mm": MECH["adapter_top_z_mm"],
        "bolt_plane_hood_datum_z_mm": MECH["bolt_plane_hood_datum_z_mm"],
        "clearance_below_head_mm": P["clearance_below_head_mm"],
        "lower_obstruction_z_mm": MECH["lower_obstruction_z_mm"],
        "lower_clearance_reserve_mm": MECH["lower_clearance_reserve_mm"],
    },
    "fit_cage": {
        "envelope_mm": MECH["fit_cage_envelope_mm"],
        "package_projection_mm": MECH["installed_projection_mm"],
        "hardware_projection_mm": MECH["installed_hardware_projection_mm"],
        "static_use_only": True,
        "engine_off": True,
        "hood_close_instruction": "close slowly with soft clay/foam witnesses; never slam",
        "standing_terminal_bridge": cage_terminal_overlap > 0.01,
        "terminal_opening_probe_overlap_mm3": cage_terminal_overlap,
        "terminal_opening_mm": [
            cage_depth - 2.0 * rail,
            H - 2.0 * rail,
        ],
        "anti_sway_diagonal_braces": len(cage_braces),
    },
    "standing_print": {
        "body_footprint_mm": MECH["standing_footprint_mm"],
        "body_height_mm": MECH["standing_body_height_mm"],
        "body_required_radius_with_brim_mm": MECH["v400_body_required_radius_mm"],
        "v400_bed_radius_mm": FIXED["v400_bed_diameter_mm"] / 2.0,
        "v400_height_mm": FIXED["v400_height_mm"],
        "right_cap_orientation": "installed Z-bottom; no late-layer locator tabs",
        "front_lid_orientation": "solid exterior face down; gasket groove opens upward",
        "localized_support_required_for": [
            "body terminal service-throat rail",
            "right-cap top rim and horizontal gland openings",
        ],
        "required_support_mode": (
            "support-everywhere/support-on-model, painted only beneath the "
            "listed roofs; protect gasket seats with blockers"
        ),
        "slicer_preview_gate": (
            "support must visibly reach every painted roof before printing"
        ),
        "support_coupon_span_mm": MECH["standing_bridge_coupon_span_mm"],
        "support_coupon_height_mm": (
            MECH["standing_bridge_coupon_support_height_mm"]
            + FIXED["front_right_seal_rail_mm"]
        ),
    },
    "gland_coupon": {
        "panel_web_mm": PANEL_WEB,
        "sacrificial_membrane_mm": MEMBRANE,
        "features": coupon_features,
    },
    "service": {
        "lid_direction": "+Y toward engine",
        "backplane_direction": "+Y after disconnecting the three pigtails",
        "battery_installation": "prohibited underhood; no UPS or cell geometry is present",
        "structural_harness_relief": (
            "required external rubber-lined metal-backed P-clamps on separately "
            "verified vehicle-structure points; locations remain pending measurements"
        ),
        "backplane_mount": "four countersunk M3 screws into four shell bosses",
        "backplane_floor_support": "two broad printed shelves; rear screws provide retention",
        "component_mount": "ESP32 on four printed M2 standoffs; remaining holes drill only after measurement",
        "adapter_load_path": "OD10 metal sleeves continue through the polymer rear wall",
        "rear_load_path_reinforcement": {
            "sleeve_collars": len(sleeve_collars),
            "grid_ribs": len(rear_load_ribs),
            "backplane_boss_gussets": len(backplane_boss_gussets),
            "backplane_floor_shelves": len(floor_shelves),
        },
        "right_io_witness": {
            "working_length_mm": FIXED["external_pigtail_service_mm"],
            "datum_heel_mm": FIXED["io_witness_datum_heel_mm"],
            "overall_length_mm": io_witness_overall,
        },
    },
}
with open(os.path.join(OUT, "freecad_result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, indent=2, sort_keys=True)
print(
    "CAD_OK firewall_hood_flange_v4 body=%.3f cap=%.3f checks=%d" %
    (body.Volume, cap.Volume, len(collision_checks)),
    flush=True,
)

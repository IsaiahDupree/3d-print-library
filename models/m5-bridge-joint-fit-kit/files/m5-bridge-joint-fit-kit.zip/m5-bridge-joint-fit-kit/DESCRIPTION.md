This kit contains left and right joint blocks, a splice plate, and a five-hole M5 diameter gauge. The largest part measures 120 × 40 × 6 mm. The hole gauge runs from 5.0 to 5.8 mm in 0.2 mm steps.

Print the parts flat as supplied. Try the hole gauge first and measure the printed diameters with your intended material and settings. Butt the two blocks together and lay the splice over them. For a bench check, start with M5 × 30 mm through-bolts, washers, and nuts and verify thread engagement.

Orion checked the four STL files for closed meshes and reloaded all four STEP solids. The cover is a CAD render. These are unloaded bench parts. Physical fit, joint strength, and transport loads remain unverified.

Licence CC BY-NC-SA 4.0. Credit Isaiah Dupree when sharing or remixing.

# Print quantities and measurements

| Part | Quantity in example | XYZ in mm |
| --- | ---: | --- |
| tier-01 | 4 | 173 × 128 × 102.5 |
| tier-02 | 4 | 173 × 128 × 66.5 |
| tier-03 | 4 | 173 × 128 × 50.5 |
| sockets-deep-8-11 | 1 | 82.802 × 30.564 × 10.4 |
| sockets-deep-12-15 | 1 | 91.438 × 34.628 × 10.4 |
| sockets-deep-16-19 | 1 | 110.996 × 39.2 × 10.4 |
| sockets-shallow-8-11 | 1 | 83.056 × 30.564 × 10.4 |
| sockets-shallow-12-15 | 1 | 90.93 × 34.628 × 10.4 |
| sockets-shallow-16-19 | 1 | 110.996 × 39.2 × 10.4 |
| srh11503-holder | 1 | 94.7 × 31.2 × 10.4 |
| sha11103-holder | 1 | 82 × 23.58 × 10.4 |
| pliers-8700100 | 1 | 108.4 × 46.55 × 10.4 |
| pliers-8604100 | 1 | 108.4 × 46.55 × 10.4 |
| hex-keys-1p5-3 | 1 | 146.99 × 51.56 × 5.4 |
| bits-ph1-ph3 | 1 | 54 × 21.3 × 10.4 |
| registration-male | 1 | 24 × 24 × 8.5 |
| footprint-male | 1 | 173 × 128 × 8.5 |
| registration-female | 1 | 24 × 24 × 6 |
| footprint-female | 1 | 173 × 128 × 6 |

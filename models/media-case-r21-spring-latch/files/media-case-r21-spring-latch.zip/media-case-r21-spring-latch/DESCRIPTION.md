This spring clip pivots on the upper M3 screw and catches on the lower screw. Lift the downward-facing lip to release it. R21 uses a 4.8 mm spring section and a 4.45 mm inside bend radius.

Download one clip or the side-flat PLA pair, plus the editable single-clip STEP in the archive. These files fit the R21 media travel case geometry with a nominal 17.565 mm screw-axis spacing. Measure your assembly and hardware before printing. Check the build orientation in your slicer and trial-fit the clip with the case empty.

Orion checked the CAD motion and the exported pair for overhangs. The pictures are CAD renders. Physical fit, retention, fatigue life, and loaded transport remain unverified.

Licence CC BY-NC-SA 4.0. Credit Isaiah Dupree when sharing or remixing.

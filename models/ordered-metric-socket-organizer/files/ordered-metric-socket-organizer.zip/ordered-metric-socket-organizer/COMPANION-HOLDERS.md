# Companion holders

| Configuration | File stem | Tool reference | Outside dimensions in mm |
| --- | --- | --- | --- |
| DWST17805 | dwst17805-accessory-01 | SHA11106 | 162 × 36 × 24 |
| DWST17805 | dwst17805-accessory-02 | SRH11503 | 120 × 36 × 24 |
| DWST08165 | dwst08165-accessory-01 | SRH11503, SHA11103 | 246 × 36 × 28 |
| DWST08165 | dwst08165-accessory-02 | SHA11106 | 204 × 36 × 28 |

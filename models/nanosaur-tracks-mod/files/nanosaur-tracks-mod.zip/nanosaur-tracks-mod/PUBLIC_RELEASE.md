# Nanosaur Track Ring — Larger-Diameter Mod

A modified printable track ring for [nanosaur](https://nanosaur.ai/), the open-source NVIDIA Jetson robot by Raffaello Bonghi. It keeps the stock inner-tooth and outer-tread pattern but increases the ring's outer diameter.

## Credits

Modified from nanosaur's `track_print.stl` in the [nanosaur repository](https://github.com/rnanosaur/nanosaur) by **Raffaello Bonghi** — the STL meshes are CC BY-NC-SA 4.0. This mod uses the same license.

## Part

- `nanosaur_tracks_mod.stl` — 95.7 mm outer diameter × 14.8 mm wide. The stock `track_print.stl` is 89.7 mm × 15 mm.

## Printing

Follow nanosaur's own build guide for track material and settings. Print the ring flat, check that the teeth mesh with your sprocket and wheels, and compare track tension against a stock ring before replacing both sides.

## Status

Fit on an assembled nanosaur and track tension are not documented in this release.

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International. See [LICENSE.md](LICENSE.md).

Full source mirror and future revisions: https://github.com/IsaiahDupree/3d-print-library

Design requests: https://github.com/IsaiahDupree/3d-print-library/issues/new/choose

## Isaiah Dupree brand + GitHub QR coupon

`isaiah-dupree-github-qr-branding.stl` is an optional, separately printable process coupon. It carries the ISAIAH DUPREE block signature and a deterministic QR code for https://github.com/IsaiahDupree/3d-print-library. Keep it separate from fitted or load-bearing model surfaces; contrast-fill the recessed cells and verify the code scans before display.
